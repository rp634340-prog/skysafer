const express = require('express');
const http = require('http');
const { Server } = require('socket.io');

const PORT = process.env.SOCKET_PORT || 3001;
const app = express();
app.use(express.json({ limit: '200kb' }));

const server = http.createServer(app);
const io = new Server(server, {
    cors: { origin: '*', methods: ['GET', 'POST'] }
});

io.on('connection', (socket) => {
    socket.on('join', ({ userId, role }) => {
        if (userId) socket.join(`user:${userId}`);
        if (role) socket.join(`role:${role}`);
    });
    socket.on('joinSeatRoom', ({ flightId, classType }) => {
        if (!flightId || !classType) return;
        socket.join(`seat:${flightId}:${classType}`);
    });
    socket.on('leaveSeatRoom', ({ flightId, classType }) => {
        if (!flightId || !classType) return;
        socket.leave(`seat:${flightId}:${classType}`);
    });
});

app.get('/health', (_req, res) => {
    res.json({ ok: true });
});

app.post('/emit', (req, res) => {
    const payload = req.body || {};
    const recipientUserId = payload.recipientUserId;
    const targetRole = payload.targetRole || 'user';
    const eventName = payload.type === 'seat_update' ? 'seat_update' : 'notification';

    if (recipientUserId) {
        io.to(`user:${recipientUserId}`).emit(eventName, payload);
    }
    io.to(`role:${targetRole}`).emit(eventName, payload);

    if (payload.type === 'seat_update' && payload.payload && payload.payload.flightId && payload.payload.classType) {
        io.to(`seat:${payload.payload.flightId}:${payload.payload.classType}`).emit('seat_update', payload);
    }
    res.json({ ok: true });
});

server.listen(PORT, () => {
    console.log(`Socket server running on ${PORT}`);
});
