# SkySafer Setup Guide

## Quick Setup Instructions

### Step 1: Database Setup

1. **Create MySQL Database:**
   ```bash
   mysql -u root -p
   ```
   Then run:
   ```sql
   CREATE DATABASE skysafer_db;
   EXIT;
   ```

2. **Import Database Schema:**
   ```bash
   mysql -u root -p skysafer_db < database/schema.sql
   ```

   Or use phpMyAdmin:
   - Open phpMyAdmin
   - Select `skysafer_db` database
   - Click "Import" tab
   - Choose `database/schema.sql` file
   - Click "Go"

### Step 2: Configure Database Connection

Edit `config/database.php`:

```php
define('DB_HOST', 'localhost');      // Your MySQL host
define('DB_USER', 'root');           // Your MySQL username
define('DB_PASS', 'your_password');  // Your MySQL password
define('DB_NAME', 'skysafer_db');    // Database name
```

### Step 3: Set File Permissions

```bash
chmod 755 logs
touch logs/error.log
chmod 644 logs/error.log
```

### Step 4: Web Server Configuration

#### For Apache:
- Ensure `mod_rewrite` is enabled
- The `.htaccess` file is already included
- Point your document root to the project folder

#### For XAMPP:
1. Copy project to `htdocs/sky-safer/`
2. Access via: `http://localhost/sky-safer/`

#### For WAMP:
1. Copy project to `www/sky-safer/`
2. Access via: `http://localhost/sky-safer/`

#### For Nginx:
Add to your server block:
```nginx
location / {
    try_files $uri $uri/ /index.html;
}

location /api {
    try_files $uri $uri/ /api/$1;
}
```

### Step 5: Test the Installation

1. **Test Database Connection:**
   Create a test file `test-db.php`:
   ```php
   <?php
   require_once 'config/database.php';
   if (testDBConnection()) {
       echo "Database connection successful!";
   } else {
       echo "Database connection failed!";
   }
   ?>
   ```
   Access: `http://localhost/sky-safer/test-db.php`

2. **Test API:**
   - Open browser console
   - Go to `http://localhost/sky-safer/`
   - Check for any JavaScript errors

### Step 6: Create Your First Account

1. Go to `signup.html`
2. Fill in the registration form
3. Submit to create account
4. Login with your credentials

## Default Sample Data

The database schema includes sample data:
- **Airlines:** SkyJet Airways, Global Airlines, Express Air, etc.
- **Cities:** Mahesana, Surat, Mumbai, Delhi, and international cities
- **Flights:** 6 sample flights with different routes and prices

## Troubleshooting

### "Database connection failed"
- Check MySQL service is running
- Verify database credentials in `config/database.php`
- Ensure database `skysafer_db` exists

### "404 Not Found" for API calls
- Check `.htaccess` file exists
- Verify `mod_rewrite` is enabled (Apache)
- Check API file paths are correct

### "500 Internal Server Error"
- Check PHP error logs
- Verify file permissions
- Check `logs/error.log` for details

### "Call to undefined function"
- Ensure all PHP files are in correct directories
- Check `require_once` paths are correct
- Verify PHP version is 7.4+

## File Structure

```
sky safer/
├── api/              # API endpoints
│   ├── auth.php
│   ├── flights.php
│   ├── bookings.php
│   └── profile.php
├── config/           # Configuration files
│   ├── database.php
│   └── config.php
├── database/         # Database files
│   └── schema.sql
├── js/              # JavaScript files
│   ├── api.js
│   └── flights.js
├── logs/            # Log files
│   └── error.log
├── *.html           # HTML pages
├── script.js        # Main JavaScript
├── style.css        # Stylesheet
└── .htaccess        # Apache config
```

## Next Steps

1. Test user registration and login
2. Search for flights
3. Create a booking
4. View bookings in "My Bookings"
5. Update profile information

## Security Notes

- Change default database password
- Use HTTPS in production
- Regularly update PHP and MySQL
- Review and customize security settings in `config/config.php`

## Support

If you encounter issues:
1. Check `logs/error.log` for errors
2. Verify all file paths are correct
3. Ensure PHP extensions are installed (PDO, MySQL)
4. Check browser console for JavaScript errors
