#!/bin/bash
# Export Database Script
# This script exports the complete database with all data

echo "========================================="
echo "SkySafer Database Export"
echo "========================================="
echo ""

# Database credentials (update these)
DB_USER="root"
DB_PASS="Dip@mysql123"
DB_NAME="skysafer_db"
OUTPUT_FILE="database/complete-database.sql"

echo "Exporting database: $DB_NAME"
echo "Output file: $OUTPUT_FILE"
echo ""

# Export database with all data
mysqldump -u "$DB_USER" -p"$DB_PASS" \
    --single-transaction \
    --routines \
    --triggers \
    --events \
    --add-drop-database \
    --databases "$DB_NAME" > "$OUTPUT_FILE"

if [ $? -eq 0 ]; then
    echo ""
    echo "========================================="
    echo "✅ Database exported successfully!"
    echo "========================================="
    echo "File: $OUTPUT_FILE"
    echo "Size: $(du -h "$OUTPUT_FILE" | cut -f1)"
    echo ""
    echo "This file contains:"
    echo "- Complete database structure"
    echo "- All airports/cities data"
    echo "- All flights data"
    echo "- All airlines data"
    echo "- All users, bookings, and passengers data"
    echo ""
else
    echo ""
    echo "❌ Error: Database export failed!"
    echo "Please check:"
    echo "1. MySQL credentials are correct"
    echo "2. MySQL service is running"
    echo "3. Database '$DB_NAME' exists"
    exit 1
fi
