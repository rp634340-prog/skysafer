#!/bin/bash
# Setup Demo Data Script
# This script imports airports and generates flights for demo

echo "========================================="
echo "SkySafer Demo Data Setup"
echo "========================================="
echo ""

# Step 1: Import India Airports
echo "Step 1: Importing India Airports..."
php scripts/import-india-airports.php

if [ $? -ne 0 ]; then
    echo "Error: Failed to import airports"
    exit 1
fi

echo ""
echo "Step 2: Generating optimized flights for demo..."
echo "This will generate ~1000 flights and take 1-2 minutes..."
php scripts/generate-flights-optimized.php

if [ $? -ne 0 ]; then
    echo "Error: Failed to generate flights"
    exit 1
fi

echo ""
echo "========================================="
echo "Demo data setup complete!"
echo "========================================="
echo ""
echo "You can now:"
echo "1. Search for flights from any India airport"
echo "2. Find flights for any date in the next year"
echo "3. Book flights (login required)"
echo ""
