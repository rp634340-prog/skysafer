<?php
/**
 * Import India Airports from airports.json to database
 * Run this script once to populate cities table with India airports
 */

require_once __DIR__ . '/../config/database.php';

echo "Importing India Airports...\n";

// Read airports.json
$jsonFile = __DIR__ . '/../airports.json';
if (!file_exists($jsonFile)) {
    die("Error: airports.json file not found!\n");
}

$jsonData = file_get_contents($jsonFile);
$airports = json_decode($jsonData, true);

if (!$airports) {
    die("Error: Could not parse airports.json\n");
}

$pdo = getDBConnection();

// Filter for India airports
$indiaAirports = array_filter($airports, function($airport) {
    return isset($airport['iso']) && 
           $airport['iso'] === 'IN' && 
           isset($airport['status']) && 
           $airport['status'] === 1 &&
           isset($airport['type']) && 
           $airport['type'] === 'airport' &&
           isset($airport['iata']) && 
           strlen($airport['iata']) === 3;
});

echo "Found " . count($indiaAirports) . " active India airports\n";

$imported = 0;
$skipped = 0;
$errors = 0;

foreach ($indiaAirports as $airport) {
    $iata = strtoupper($airport['iata']);
    $name = $airport['name'] ?? '';
    
    // Extract city name from airport name
    $cityName = extractCityName($name);
    
    // Check if already exists
    $stmt = $pdo->prepare("SELECT id FROM cities WHERE code = ?");
    $stmt->execute([$iata]);
    if ($stmt->fetch()) {
        $skipped++;
        continue;
    }
    
    // Insert airport
    try {
        $stmt = $pdo->prepare("
            INSERT INTO cities (name, code, country) 
            VALUES (?, ?, 'India')
        ");
        $stmt->execute([$cityName, $iata]);
        $imported++;
        echo "Imported: $cityName ($iata)\n";
    } catch (Exception $e) {
        $errors++;
        echo "Error importing $cityName ($iata): " . $e->getMessage() . "\n";
    }
}

echo "\n=== Import Summary ===\n";
echo "Imported: $imported\n";
echo "Skipped (already exists): $skipped\n";
echo "Errors: $errors\n";
echo "Total processed: " . count($indiaAirports) . "\n";

/**
 * Extract city name from airport name
 */
function extractCityName($airportName) {
    if (empty($airportName)) return '';
    
    // Remove common suffixes
    $patterns = [
        '/\s+International\s+Airport.*$/i',
        '/\s+Airport.*$/i',
        '/\s+Air\s+Base.*$/i',
        '/\s+Airfield.*$/i',
        '/\s+Air\s+Force\s+Station.*$/i'
    ];
    
    $cityName = $airportName;
    foreach ($patterns as $pattern) {
        $cityName = preg_replace($pattern, '', $cityName);
    }
    
    // Remove common prefixes (person names)
    $cityName = preg_replace('/^(Sardar|Chhatrapati|Indira|Netaji|Rajiv|Chaudhary|Lal|Kempegowda)\s+/i', '', $cityName);
    $cityName = preg_replace('/\s+(Vallabhbhai|Shivaji|Gandhi|Subhash|Charan|Bahadur|Shastri|Maharaj).*$/i', '', $cityName);
    
    // Take first part if contains "/"
    if (strpos($cityName, '/') !== false) {
        $cityName = explode('/', $cityName)[0];
    }
    
    // Take first part if contains "-"
    if (strpos($cityName, '-') !== false) {
        $parts = explode('-', $cityName);
        $cityName = $parts[0];
    }
    
    $cityName = trim($cityName);
    
    // If still long, take first 2-3 words
    $words = explode(' ', $cityName);
    if (count($words) > 3) {
        $cityName = implode(' ', array_slice($words, 0, 2));
    }
    
    return $cityName ?: explode(' ', $airportName)[0];
}
