<?php
/**
 * Generate Flights - Optimized Version
 * Creates ~1000 flights for demo purposes
 * Focuses on popular routes and next 60 days
 */

require_once __DIR__ . '/../config/database.php';

echo "Generating optimized flights for demo...\n";

$pdo = getDBConnection();

// Get all India airports
$stmt = $pdo->query("SELECT id, code, name FROM cities WHERE country = 'India' ORDER BY name");
$airports = $stmt->fetchAll();

if (count($airports) < 2) {
    die("Error: Need at least 2 airports in database. Run import-india-airports.php first.\n");
}

echo "Found " . count($airports) . " airports\n";

// Get airlines
$stmt = $pdo->query("SELECT id, code FROM airlines");
$airlines = $stmt->fetchAll();

if (count($airlines) === 0) {
    die("Error: No airlines found. Please ensure airlines are inserted.\n");
}

// Focus on most popular routes for demo
// Gujarat airports
$gujaratAirports = ['AMD', 'STV', 'BDQ', 'BHJ', 'RAJ'];
// Major cities (most popular destinations)
$majorCities = ['BOM', 'DEL', 'BLR', 'MAA', 'HYD', 'PNQ', 'GOI', 'JAI'];

// Create popular routes only
$routes = [];

// Top routes: Gujarat to major cities (one way only, return will be added separately)
$popularGujaratRoutes = [
    ['AMD', 'BOM'], // Ahmedabad to Mumbai
    ['AMD', 'DEL'], // Ahmedabad to Delhi
    ['AMD', 'BLR'], // Ahmedabad to Bangalore
    ['STV', 'BOM'], // Surat to Mumbai
    ['STV', 'DEL'], // Surat to Delhi
    ['BDQ', 'BOM'], // Vadodara to Mumbai
    ['BDQ', 'DEL'], // Vadodara to Delhi
];

// Add return routes
foreach ($popularGujaratRoutes as $route) {
    $fromAirport = array_filter($airports, fn($a) => $a['code'] === $route[0]);
    $toAirport = array_filter($airports, fn($a) => $a['code'] === $route[1]);
    
    if (!empty($fromAirport) && !empty($toAirport)) {
        $routes[] = [
            'from' => reset($fromAirport),
            'to' => reset($toAirport)
        ];
        // Add return route
        $routes[] = [
            'from' => reset($toAirport),
            'to' => reset($fromAirport)
        ];
    }
}

// Popular inter-city routes (major cities)
$popularInterCityRoutes = [
    ['BOM', 'DEL'], // Mumbai to Delhi
    ['BOM', 'BLR'], // Mumbai to Bangalore
    ['BOM', 'HYD'], // Mumbai to Hyderabad
    ['DEL', 'BLR'], // Delhi to Bangalore
    ['DEL', 'MAA'], // Delhi to Chennai
    ['BLR', 'MAA'], // Bangalore to Chennai
];

foreach ($popularInterCityRoutes as $route) {
    $fromAirport = array_filter($airports, fn($a) => $a['code'] === $route[0]);
    $toAirport = array_filter($airports, fn($a) => $a['code'] === $route[1]);
    
    if (!empty($fromAirport) && !empty($toAirport)) {
        $routes[] = [
            'from' => reset($fromAirport),
            'to' => reset($toAirport)
        ];
        // Add return route
        $routes[] = [
            'from' => reset($toAirport),
            'to' => reset($fromAirport)
        ];
    }
}

echo "Created " . count($routes) . " popular routes\n";

// Generate flights for next 60 days only (optimized for demo)
$startDate = new DateTime();
$endDate = new DateTime('+60 days');

$flightNumber = 1;
$totalFlights = 0;
$errors = 0;

// Time slots throughout the day (fewer slots for optimization)
$timeSlots = [
    ['06:00', '07:30'], ['09:00', '10:30'], ['12:00', '13:30'],
    ['15:00', '16:30'], ['18:00', '19:30']
];

$currentDate = clone $startDate;

echo "Generating flights from " . $startDate->format('Y-m-d') . " to " . $endDate->format('Y-m-d') . "\n";
echo "This will generate approximately 1000-1500 flights...\n\n";

while ($currentDate <= $endDate) {
    $dateStr = $currentDate->format('Y-m-d');
    
    foreach ($routes as $route) {
        // Generate 1-2 flights per route per day (optimized)
        $flightsPerRoute = rand(1, 2);
        $selectedSlots = array_rand($timeSlots, min($flightsPerRoute, count($timeSlots)));
        
        if (!is_array($selectedSlots)) {
            $selectedSlots = [$selectedSlots];
        }
        
        foreach ($selectedSlots as $slotIndex) {
            $slot = $timeSlots[$slotIndex];
            
            // Add some randomness to times (±20 minutes)
            $departHour = (int)explode(':', $slot[0])[0];
            $departMin = (int)explode(':', $slot[0])[1] + rand(-20, 20);
            if ($departMin < 0) { $departMin += 60; $departHour--; }
            if ($departMin >= 60) { $departMin -= 60; $departHour++; }
            if ($departHour < 0) $departHour = 0;
            if ($departHour >= 24) $departHour = 23;
            
            $arriveHour = (int)explode(':', $slot[1])[0];
            $arriveMin = (int)explode(':', $slot[1])[1] + rand(-20, 20);
            if ($arriveMin < 0) { $arriveMin += 60; $arriveHour--; }
            if ($arriveMin >= 60) { $arriveMin -= 60; $arriveHour++; }
            if ($arriveHour < 0) $arriveHour = 0;
            if ($arriveHour >= 24) $arriveHour = 23;
            
            $departureTime = $dateStr . ' ' . str_pad($departHour, 2, '0', STR_PAD_LEFT) . ':' . str_pad($departMin, 2, '0', STR_PAD_LEFT) . ':00';
            $arrivalTime = $dateStr . ' ' . str_pad($arriveHour, 2, '0', STR_PAD_LEFT) . ':' . str_pad($arriveMin, 2, '0', STR_PAD_LEFT) . ':00';
            
            // Calculate duration in minutes
            $depart = new DateTime($departureTime);
            $arrive = new DateTime($arrivalTime);
            $duration = ($arrive->getTimestamp() - $depart->getTimestamp()) / 60;
            
            // Ensure positive duration
            if ($duration <= 0) {
                $duration = 90; // Default 90 minutes
            }
            
            // Random airline
            $airline = $airlines[array_rand($airlines)];
            
            // Random pricing (base on distance estimate)
            $basePrice = rand(200, 500);
            $economyPrice = $basePrice;
            $premiumPrice = $basePrice * 1.4;
            $businessPrice = $basePrice * 2.2;
            $firstClassPrice = $basePrice * 3.5;
            
            // Random stops (90% direct, 10% with stops)
            $stops = (rand(1, 10) <= 9) ? 0 : 1;
            $stopCityId = null;
            if ($stops > 0) {
                $stopAirports = array_filter($airports, function($a) use ($route) {
                    return $a['id'] != $route['from']['id'] && $a['id'] != $route['to']['id'];
                });
                if (!empty($stopAirports)) {
                    $stopAirportsArray = array_values($stopAirports);
                    $stopCityId = $stopAirportsArray[array_rand($stopAirportsArray)]['id'];
                }
            }
            
            // Generate flight number
            $flightNum = $airline['code'] . '-' . str_pad($flightNumber, 3, '0', STR_PAD_LEFT);
            
            try {
                $stmt = $pdo->prepare("
                    INSERT INTO flights (
                        flight_number, airline_id, departure_city_id, arrival_city_id,
                        departure_time, arrival_time, duration_minutes,
                        economy_price, premium_price, business_price, first_class_price,
                        stops, stop_city_id,
                        baggage_allowance_kg, cabin_baggage_kg,
                        economy_available, premium_available, business_available, first_class_available,
                        status
                    ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 'scheduled')
                ");
                
                $stmt->execute([
                    $flightNum,
                    $airline['id'],
                    $route['from']['id'],
                    $route['to']['id'],
                    $departureTime,
                    $arrivalTime,
                    $duration,
                    $economyPrice,
                    $premiumPrice,
                    $businessPrice,
                    $firstClassPrice,
                    $stops,
                    $stopCityId,
                    rand(15, 25), // baggage
                    rand(7, 10),  // cabin baggage
                    rand(40, 60), // economy seats
                    rand(8, 12),  // premium seats
                    rand(4, 8),   // business seats
                    rand(2, 5)   // first class seats
                ]);
                
                $totalFlights++;
                $flightNumber++;
                
                if ($totalFlights % 100 === 0) {
                    echo "Generated $totalFlights flights...\n";
                }
            } catch (Exception $e) {
                $errors++;
                if ($errors < 10) {
                    echo "Error: " . $e->getMessage() . "\n";
                }
            }
        }
    }
    
    $currentDate->modify('+1 day');
}

echo "\n=== Generation Summary ===\n";
echo "Total flights generated: $totalFlights\n";
echo "Errors: $errors\n";
echo "Routes: " . count($routes) . "\n";
echo "Date range: " . $startDate->format('Y-m-d') . " to " . $endDate->format('Y-m-d') . "\n";
echo "Done!\n";
