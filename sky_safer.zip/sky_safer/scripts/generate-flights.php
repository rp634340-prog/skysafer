<?php
/**
 * Generate Flights for All Days
 * Creates flights between India airports for the next 365 days
 * Run this script to populate flights table
 */

require_once __DIR__ . '/../config/database.php';

echo "Generating flights for all days...\n";

$pdo = getDBConnection();

// Get all India airports
$stmt = $pdo->query("SELECT id, code, name FROM cities WHERE country = 'India' ORDER BY name");
$airports = $stmt->fetchAll();

if (count($airports) < 2) {
    die("Error: Need at least 2 airports in database. Run import-india-airports.php first.\n");
}

echo "Found " . count($airports) . " airports\n";

// Get airlines
$stmt = $pdo->query("SELECT id, code FROM airlines");
$airlines = $stmt->fetchAll();

if (count($airlines) === 0) {
    die("Error: No airlines found. Please ensure airlines are inserted.\n");
}

// Focus on Gujarat and major Indian cities
$gujaratAirports = ['AMD', 'STV', 'BDQ', 'BHJ', 'IXY', 'JGA', 'RAJ', 'DIU'];
$majorCities = ['BOM', 'DEL', 'BLR', 'MAA', 'CCU', 'HYD', 'PNQ', 'GOI', 'JAI', 'COK', 'IXU', 'IXC', 'LKO', 'VNS'];

// Create routes (from Gujarat to major cities and vice versa)
$routes = [];

// From Gujarat airports to major cities
foreach ($gujaratAirports as $gujCode) {
    foreach ($majorCities as $cityCode) {
        $fromAirport = array_filter($airports, fn($a) => $a['code'] === $gujCode);
        $toAirport = array_filter($airports, fn($a) => $a['code'] === $cityCode);
        
        if (!empty($fromAirport) && !empty($toAirport)) {
            $routes[] = [
                'from' => reset($fromAirport),
                'to' => reset($toAirport)
            ];
        }
    }
}

// Between major cities
for ($i = 0; $i < count($majorCities); $i++) {
    for ($j = $i + 1; $j < count($majorCities); $j++) {
        $fromAirport = array_filter($airports, fn($a) => $a['code'] === $majorCities[$i]);
        $toAirport = array_filter($airports, fn($a) => $a['code'] === $majorCities[$j]);
        
        if (!empty($fromAirport) && !empty($toAirport)) {
            $routes[] = [
                'from' => reset($fromAirport),
                'to' => reset($toAirport)
            ];
            // Also add return route
            $routes[] = [
                'from' => reset($toAirport),
                'to' => reset($fromAirport)
            ];
        }
    }
}

echo "Created " . count($routes) . " routes\n";

// Generate flights for next 365 days (and past 30 days for testing)
$startDate = new DateTime('-30 days');
$endDate = new DateTime('+365 days');

$flightNumber = 1;
$totalFlights = 0;
$errors = 0;

// Time slots throughout the day
$timeSlots = [
    ['06:00', '07:30'], ['08:00', '09:30'], ['10:00', '11:30'],
    ['12:00', '13:30'], ['14:00', '15:30'], ['16:00', '17:30'],
    ['18:00', '19:30'], ['20:00', '21:30']
];

$currentDate = clone $startDate;

echo "Generating flights from " . $startDate->format('Y-m-d') . " to " . $endDate->format('Y-m-d') . "\n";

while ($currentDate <= $endDate) {
    $dateStr = $currentDate->format('Y-m-d');
    
    foreach ($routes as $route) {
        // Generate 2-3 flights per route per day
        $flightsPerRoute = rand(2, 3);
        $selectedSlots = array_rand($timeSlots, min($flightsPerRoute, count($timeSlots)));
        
        if (!is_array($selectedSlots)) {
            $selectedSlots = [$selectedSlots];
        }
        
        foreach ($selectedSlots as $slotIndex) {
            $slot = $timeSlots[$slotIndex];
            
            // Add some randomness to times (±30 minutes)
            $departHour = (int)explode(':', $slot[0])[0];
            $departMin = (int)explode(':', $slot[0])[1] + rand(-30, 30);
            if ($departMin < 0) { $departMin += 60; $departHour--; }
            if ($departMin >= 60) { $departMin -= 60; $departHour++; }
            if ($departHour < 0) $departHour = 0;
            if ($departHour >= 24) $departHour = 23;
            
            $arriveHour = (int)explode(':', $slot[1])[0];
            $arriveMin = (int)explode(':', $slot[1])[1] + rand(-30, 30);
            if ($arriveMin < 0) { $arriveMin += 60; $arriveHour--; }
            if ($arriveMin >= 60) { $arriveMin -= 60; $arriveHour++; }
            if ($arriveHour < 0) $arriveHour = 0;
            if ($arriveHour >= 24) $arriveHour = 23;
            
            $departureTime = $dateStr . ' ' . str_pad($departHour, 2, '0', STR_PAD_LEFT) . ':' . str_pad($departMin, 2, '0', STR_PAD_LEFT) . ':00';
            $arrivalTime = $dateStr . ' ' . str_pad($arriveHour, 2, '0', STR_PAD_LEFT) . ':' . str_pad($arriveMin, 2, '0', STR_PAD_LEFT) . ':00';
            
            // Calculate duration in minutes
            $depart = new DateTime($departureTime);
            $arrive = new DateTime($arrivalTime);
            $duration = ($arrive->getTimestamp() - $depart->getTimestamp()) / 60;
            
            // Random airline
            $airline = $airlines[array_rand($airlines)];
            
            // Random pricing (base on distance estimate)
            $basePrice = rand(200, 500);
            $economyPrice = $basePrice;
            $premiumPrice = $basePrice * 1.4;
            $businessPrice = $basePrice * 2.2;
            $firstClassPrice = $basePrice * 3.5;
            
            // Random stops (80% direct, 20% with stops)
            $stops = (rand(1, 10) <= 8) ? 0 : 1;
            $stopCityId = null;
            if ($stops > 0) {
                $stopAirports = array_filter($airports, function($a) use ($route) {
                    return $a['id'] != $route['from']['id'] && $a['id'] != $route['to']['id'];
                });
                if (!empty($stopAirports)) {
                    $stopCityId = array_rand(array_values($stopAirports));
                    $stopCityId = array_values($stopAirports)[$stopCityId]['id'];
                }
            }
            
            // Generate flight number
            $flightNum = $airline['code'] . '-' . str_pad($flightNumber, 3, '0', STR_PAD_LEFT);
            
            try {
                $stmt = $pdo->prepare("
                    INSERT INTO flights (
                        flight_number, airline_id, departure_city_id, arrival_city_id,
                        departure_time, arrival_time, duration_minutes,
                        economy_price, premium_price, business_price, first_class_price,
                        stops, stop_city_id,
                        baggage_allowance_kg, cabin_baggage_kg,
                        economy_available, premium_available, business_available, first_class_available,
                        status
                    ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 'scheduled')
                ");
                
                $stmt->execute([
                    $flightNum,
                    $airline['id'],
                    $route['from']['id'],
                    $route['to']['id'],
                    $departureTime,
                    $arrivalTime,
                    $duration,
                    $economyPrice,
                    $premiumPrice,
                    $businessPrice,
                    $firstClassPrice,
                    $stops,
                    $stopCityId,
                    rand(15, 25), // baggage
                    rand(7, 10),  // cabin baggage
                    rand(40, 60), // economy seats
                    rand(8, 12),  // premium seats
                    rand(4, 8),   // business seats
                    rand(2, 5)   // first class seats
                ]);
                
                $totalFlights++;
                $flightNumber++;
                
                if ($totalFlights % 100 === 0) {
                    echo "Generated $totalFlights flights...\n";
                }
            } catch (Exception $e) {
                $errors++;
                if ($errors < 10) {
                    echo "Error: " . $e->getMessage() . "\n";
                }
            }
        }
    }
    
    $currentDate->modify('+1 day');
}

echo "\n=== Generation Summary ===\n";
echo "Total flights generated: $totalFlights\n";
echo "Errors: $errors\n";
echo "Routes: " . count($routes) . "\n";
echo "Date range: " . $startDate->format('Y-m-d') . " to " . $endDate->format('Y-m-d') . "\n";
echo "Done!\n";
