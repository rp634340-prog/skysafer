# SkySafer Flight Booking System

A complete flight booking system built with PHP and MySQL.

## Features

- User authentication (Signup/Login)
- Flight search and booking
- Booking management
- User profile management
- Secure password hashing
- Session management
- RESTful API

## Requirements

- PHP 7.4 or higher
- MySQL 5.7 or higher / MariaDB 10.3 or higher
- Apache web server with mod_rewrite enabled
- PDO MySQL extension

## Installation

### 1. Database Setup

1. Create a MySQL database:
```sql
CREATE DATABASE skysafer_db;
```

2. Import the database schema:
```bash
mysql -u root -p skysafer_db < database/schema.sql
```

Or use phpMyAdmin to import `database/schema.sql`

### 2. Configuration

Edit `config/database.php` and update database credentials:

```php
define('DB_HOST', 'localhost');
define('DB_USER', 'root');
define('DB_PASS', 'your_password');
define('DB_NAME', 'skysafer_db');
```

### 3. File Permissions

Ensure the logs directory is writable:
```bash
chmod 755 logs
chmod 644 logs/error.log
```

### 4. Web Server Setup

#### Apache
- Ensure mod_rewrite is enabled
- The `.htaccess` file is included

#### Nginx
Add this to your server block:
```nginx
location / {
    try_files $uri $uri/ /index.html;
}

location /api {
    try_files $uri $uri/ /api/$1;
}
```

## API Endpoints

### Authentication
- `POST /api/auth.php?action=signup` - User registration
- `POST /api/auth.php?action=login` - User login
- `POST /api/auth.php?action=logout` - User logout
- `GET /api/auth.php?action=check` - Check authentication status

### Flights
- `GET /api/flights.php?action=search&from=...&to=...&departDate=...` - Search flights
- `GET /api/flights.php?action=get&id=...` - Get flight details
- `GET /api/flights.php?action=list` - List all flights

### Bookings
- `POST /api/bookings.php?action=create` - Create booking
- `GET /api/bookings.php?action=list` - List user bookings
- `GET /api/bookings.php?action=get&id=...` - Get booking details
- `POST /api/bookings.php?action=cancel` - Cancel booking

### Profile
- `GET /api/profile.php?action=get` - Get user profile
- `POST /api/profile.php?action=update` - Update profile
- `POST /api/profile.php?action=updatePassword` - Update password
- `GET /api/profile.php?action=getPreferences` - Get preferences
- `POST /api/profile.php?action=updatePreferences` - Update preferences

## Frontend Integration

The frontend JavaScript files need to be updated to use AJAX calls to the API endpoints instead of localStorage. See the updated JavaScript files for examples.

## Security Features

- Password hashing using PHP's `password_hash()`
- Prepared statements to prevent SQL injection
- Session-based authentication
- Input sanitization
- CSRF token support (ready for implementation)

## Database Schema

The database includes:
- `users` - User accounts
- `airlines` - Airline information
- `cities` - City/airport information
- `flights` - Flight schedules and pricing
- `bookings` - User bookings
- `passengers` - Passenger details for bookings
- `user_preferences` - User preferences

## Troubleshooting

### Database Connection Error
- Check database credentials in `config/database.php`
- Ensure MySQL service is running
- Verify database exists

### 500 Internal Server Error
- Check PHP error logs
- Verify file permissions
- Ensure all required PHP extensions are installed

### API Returns 404
- Check `.htaccess` is working
- Verify mod_rewrite is enabled
- Check API file paths

## License

This project is for educational purposes.

## Support

For issues or questions, please check the error logs in the `logs/` directory.
