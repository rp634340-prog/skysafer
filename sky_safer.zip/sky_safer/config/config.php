<?php
/**
 * Application Configuration
 * SkySafer Flight Booking System
 */

// Start session if not already started
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

// Error reporting (disable in production)
error_reporting(E_ALL);
ini_set('display_errors', 1);

// Timezone
date_default_timezone_set('Asia/Kolkata');

// Application settings
define('APP_NAME', 'SkySafer');
define('APP_URL', 'http://localhost');
define('SESSION_LIFETIME', 3600 * 24); // 24 hours

// Security settings
define('PASSWORD_MIN_LENGTH', 6);
define('CSRF_TOKEN_NAME', 'csrf_token');
define('JWT_SECRET', 'change-this-jwt-secret-in-production');
define('RATE_LIMIT_DIR', __DIR__ . '/../storage/rate-limits');
define('SOCKET_SERVER_URL', 'http://127.0.0.1:3001');

// Include database configuration
require_once __DIR__ . '/database.php';

if (!is_dir(RATE_LIMIT_DIR)) {
    @mkdir(RATE_LIMIT_DIR, 0775, true);
}

/**
 * Generate CSRF token
 * @return string
 */
function generateCSRFToken() {
    if (empty($_SESSION[CSRF_TOKEN_NAME])) {
        $_SESSION[CSRF_TOKEN_NAME] = bin2hex(random_bytes(32));
    }
    return $_SESSION[CSRF_TOKEN_NAME];
}

/**
 * Verify CSRF token
 * @param string $token
 * @return bool
 */
function verifyCSRFToken($token) {
    return isset($_SESSION[CSRF_TOKEN_NAME]) && hash_equals($_SESSION[CSRF_TOKEN_NAME], $token);
}

/**
 * Check if user is logged in
 * @return bool
 */
function isLoggedIn() {
    return isset($_SESSION['user_id']) && isset($_SESSION['username']);
}

/**
 * Get current user ID
 * @return int|null
 */
function getCurrentUserId() {
    return $_SESSION['user_id'] ?? null;
}

/**
 * Get current username
 * @return string|null
 */
function getCurrentUsername() {
    return $_SESSION['username'] ?? null;
}

/**
 * Require login - redirect if not logged in
 */
function requireLogin() {
    if (!isLoggedIn()) {
        http_response_code(401);
        echo json_encode(['error' => 'Authentication required']);
        exit;
    }
}

/**
 * Sanitize input
 * @param mixed $data
 * @return mixed
 */
function sanitizeInput($data) {
    if (is_array($data)) {
        return array_map('sanitizeInput', $data);
    }
    return htmlspecialchars(strip_tags(trim($data)), ENT_QUOTES, 'UTF-8');
}

/**
 * Validate email
 * @param string $email
 * @return bool
 */
function validateEmail($email) {
    return filter_var($email, FILTER_VALIDATE_EMAIL) !== false;
}

/**
 * Validate departure / return travel dates for search and booking.
 *
 * @return string|null Error message or null when valid
 */
function validateTravelDates($tripType, $departureDate, $returnDate = null) {
    $tripType = strtolower(trim((string) $tripType));
    $depart = trim((string) $departureDate);
    $return = trim((string) ($returnDate ?? ''));
    $today = date('Y-m-d');

    if ($depart === '') {
        return 'Departure date is required.';
    }
    if (!preg_match('/^\d{4}-\d{2}-\d{2}$/', $depart)) {
        return 'Invalid departure date format.';
    }
    if ($depart < $today) {
        return 'Departure date cannot be in the past.';
    }

    $isRoundTrip = in_array($tripType, ['round_trip', 'round-trip', 'roundtrip'], true);
    if ($isRoundTrip) {
        if ($return === '') {
            return 'Return date is required for a round trip.';
        }
        if (!preg_match('/^\d{4}-\d{2}-\d{2}$/', $return)) {
            return 'Invalid return date format.';
        }
        if ($return <= $depart) {
            return 'Return date must be after departure date.';
        }
    }

    return null;
}

/**
 * Generate booking reference
 * @return string
 */
function generateBookingReference() {
    return 'SKY' . strtoupper(substr(md5(uniqid(rand(), true)), 0, 9));
}

/**
 * Send JSON response
 * @param mixed $data
 * @param int $statusCode
 */
function sendJSONResponse($data, $statusCode = 200) {
    while (ob_get_level() > 0) {
        ob_end_clean();
    }
    http_response_code($statusCode);
    applySecurityHeaders();
    header('Content-Type: application/json; charset=utf-8');
    $json = json_encode($data, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
    if ($json === false) {
        $json = '{"success":false,"message":"Failed to encode JSON response"}';
    }
    echo $json;
    exit;
}

/**
 * Log error
 * @param string $message
 */
function logError($message) {
    error_log(date('Y-m-d H:i:s') . ' - ' . $message . PHP_EOL, 3, __DIR__ . '/../logs/error.log');
}

/**
 * Apply common security headers.
 */
function applySecurityHeaders() {
    header('X-Content-Type-Options: nosniff');
    header('X-Frame-Options: DENY');
    header('Referrer-Policy: strict-origin-when-cross-origin');
    header('X-XSS-Protection: 1; mode=block');
    header("Content-Security-Policy: default-src 'self'; img-src 'self' data: https:; style-src 'self' 'unsafe-inline' https:; script-src 'self' 'unsafe-inline' https:;");
}

/**
 * Enforce lightweight file-based rate limiting per key.
 */
function enforceRateLimit($key, $maxRequests = 120, $windowSeconds = 60) {
    $safeKey = preg_replace('/[^a-zA-Z0-9_\-]/', '_', $key);
    $file = RATE_LIMIT_DIR . '/' . $safeKey . '.json';
    $now = time();
    $data = ['window_start' => $now, 'count' => 0];

    if (file_exists($file)) {
        $existing = json_decode(file_get_contents($file), true);
        if (is_array($existing) && isset($existing['window_start'], $existing['count'])) {
            $data = $existing;
        }
    }

    if (($now - intval($data['window_start'])) >= $windowSeconds) {
        $data = ['window_start' => $now, 'count' => 0];
    }

    $data['count'] = intval($data['count']) + 1;
    file_put_contents($file, json_encode($data));

    if ($data['count'] > $maxRequests) {
        sendJSONResponse(['success' => false, 'message' => 'Too many requests'], 429);
    }
}

/**
 * Verify CSRF token for state-changing requests.
 */
function requireCSRFToken() {
    if ($_SERVER['REQUEST_METHOD'] === 'GET') {
        return;
    }

    $headers = function_exists('getallheaders') ? getallheaders() : [];
    $token = $headers['X-CSRF-Token'] ?? $headers['x-csrf-token'] ?? '';
    if (!$token || !verifyCSRFToken($token)) {
        sendJSONResponse(['error' => 'Invalid CSRF token'], 403);
    }
}

/**
 * Basic role lookup with session fallback.
 */
function getCurrentUserRole() {
    if (!empty($_SESSION['role'])) {
        return $_SESSION['role'];
    }
    return deriveRoleFromIdentity(getCurrentUsername(), $_SESSION['email'] ?? '');
}

/**
 * Require role in allowed list.
 */
function requireRole($allowedRoles = ['admin']) {
    $role = getCurrentUserRole();
    if (!in_array($role, $allowedRoles, true)) {
        sendJSONResponse(['error' => 'Forbidden'], 403);
    }
}

/**
 * Validate JWT from Authorization Bearer header.
 * Returns payload array when valid, null otherwise.
 */
function validateJWTFromHeader() {
    $headers = function_exists('getallheaders') ? getallheaders() : [];
    $auth = $headers['Authorization'] ?? $headers['authorization'] ?? '';
    if (!preg_match('/^Bearer\s+(.+)$/', $auth, $matches)) {
        return null;
    }

    $token = $matches[1];
    $parts = explode('.', $token);
    if (count($parts) !== 3) {
        return null;
    }

    [$encodedHeader, $encodedPayload, $encodedSig] = $parts;
    $header = json_decode(base64_decode(strtr($encodedHeader, '-_', '+/')), true);
    $payload = json_decode(base64_decode(strtr($encodedPayload, '-_', '+/')), true);
    if (!is_array($header) || !is_array($payload)) {
        return null;
    }

    if (($header['alg'] ?? '') !== 'HS256' || ($header['typ'] ?? '') !== 'JWT') {
        return null;
    }

    $expected = rtrim(strtr(base64_encode(hash_hmac('sha256', $encodedHeader . '.' . $encodedPayload, JWT_SECRET, true)), '+/', '-_'), '=');
    if (!hash_equals($expected, $encodedSig)) {
        return null;
    }

    $now = time();
    if (isset($payload['exp']) && intval($payload['exp']) < $now) {
        return null;
    }
    if (isset($payload['nbf']) && intval($payload['nbf']) > $now) {
        return null;
    }
    if (isset($payload['iat']) && intval($payload['iat']) > ($now + 60)) {
        return null;
    }

    return $payload;
}

/**
 * Session-first auth with optional JWT fallback.
 */
function requireAuth() {
    if (isLoggedIn()) {
        return;
    }

    $payload = validateJWTFromHeader();
    if (!$payload || empty($payload['sub'])) {
        sendJSONResponse(['error' => 'Authentication required'], 401);
    }

    $_SESSION['user_id'] = intval($payload['sub']);
    $_SESSION['username'] = sanitizeInput($payload['username'] ?? 'user');
    $_SESSION['role'] = sanitizeInput($payload['role'] ?? deriveRoleFromIdentity($_SESSION['username'], $payload['email'] ?? ''));
}

/**
 * Determine role from current identity without schema changes.
 */
function deriveRoleFromIdentity($username, $email = '') {
    $uname = strtolower(trim((string)$username));
    $mail = strtolower(trim((string)$email));
    $adminUsernames = ['admin', 'administrator', 'superadmin'];
    $adminEmails = ['admin@skysafer.com', 'admin@localhost'];

    if (in_array($uname, $adminUsernames, true) || in_array($mail, $adminEmails, true)) {
        return 'admin';
    }
    return 'user';
}

/**
 * Persist notification with standard payload schema.
 */
function createNotification($pdo, $recipientUserId, $targetRole, $notificationType, $title, $message, $payload = [], $priority = 'normal') {
    $stmt = $pdo->prepare("
        INSERT INTO notifications
        (recipient_user_id, target_role, notification_type, title, message, payload_json, priority)
        VALUES (?, ?, ?, ?, ?, ?, ?)
    ");
    $stmt->execute([
        $recipientUserId ? intval($recipientUserId) : null,
        sanitizeInput($targetRole),
        sanitizeInput($notificationType),
        sanitizeInput($title),
        sanitizeInput($message),
        json_encode($payload),
        sanitizeInput($priority)
    ]);

    return intval($pdo->lastInsertId());
}

/**
 * Push notification payload to Socket.IO bridge (best effort).
 */
function pushRealtimeNotification($payload) {
    $url = SOCKET_SERVER_URL . '/emit';
    $body = json_encode($payload);
    if ($body === false) {
        return;
    }

    if (function_exists('curl_init')) {
        $ch = curl_init($url);
        curl_setopt($ch, CURLOPT_POST, true);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_TIMEOUT_MS, 700);
        curl_setopt($ch, CURLOPT_HTTPHEADER, ['Content-Type: application/json']);
        curl_setopt($ch, CURLOPT_POSTFIELDS, $body);
        curl_exec($ch);
        curl_close($ch);
        return;
    }

    $context = stream_context_create([
        'http' => [
            'method' => 'POST',
            'header' => "Content-Type: application/json\r\n",
            'content' => $body,
            'timeout' => 1
        ]
    ]);
    @file_get_contents($url, false, $context);
}
