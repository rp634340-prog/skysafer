/**
 * Profile Page JavaScript
 * Loads and displays user profile data
 */

let currentUser = null;
let userPreferences = null;

document.addEventListener('DOMContentLoaded', async function() {
    // Load API if not loaded
    if (typeof ProfileAPI === 'undefined') {
        const script = document.createElement('script');
        script.src = 'js/api.js';
        document.head.appendChild(script);
        await new Promise(resolve => script.onload = resolve);
    }
    
    // Check authentication
    try {
        const authResponse = await AuthAPI.check();
        if (!authResponse.authenticated) {
            window.location.href = 'login.html';
            return;
        }
        
        // Load profile data
        await loadProfile();
        await loadPreferences();
        await loadBookingStats();
    } catch (error) {
        console.error('Error loading profile:', error);
        if (typeof showToast !== 'undefined') {
            showToast('Failed to load profile. Please login again.', 'error');
        }
        setTimeout(() => {
            window.location.href = 'login.html';
        }, 2000);
    }
});

/**
 * Generate initials from name
 */
function getInitials(firstName, lastName, username) {
    if (firstName && lastName) {
        return (firstName.charAt(0) + lastName.charAt(0)).toUpperCase();
    } else if (firstName) {
        return firstName.substring(0, 2).toUpperCase();
    } else if (lastName) {
        return lastName.substring(0, 2).toUpperCase();
    } else if (username) {
        return username.substring(0, 2).toUpperCase();
    }
    return 'U';
}

/**
 * Calculate member tier based on spending
 */
function calculateMemberTier(totalSpent) {
    if (totalSpent >= 10000) {
        return { tier: 'Platinum', icon: 'gem', color: '#9b59b6' };
    } else if (totalSpent >= 5000) {
        return { tier: 'Gold', icon: 'crown', color: '#FFD700' };
    } else if (totalSpent >= 2000) {
        return { tier: 'Silver', icon: 'medal', color: '#C0C0C0' };
    }
    return { tier: 'Basic', icon: 'user', color: '#6b7280' };
}

/**
 * Load user profile
 */
async function loadProfile() {
    try {
        const profile = await ProfileAPI.get();
        currentUser = profile;
        
        // Generate initials
        const initials = getInitials(profile.first_name, profile.last_name, profile.username);
        const fullName = `${profile.first_name || ''} ${profile.last_name || ''}`.trim() || profile.username;
        
        // Update profile avatar with initials
        const avatarDiv = document.getElementById('avatarInitials');
        if (avatarDiv) {
            avatarDiv.textContent = initials;
        }
        
        // Update profile header
        const nameElement = document.getElementById('profileName');
        if (nameElement) {
            nameElement.textContent = fullName;
        }
        
        const emailElement = document.getElementById('profileContact');
        if (emailElement) {
            emailElement.innerHTML = `
                <i class="fas fa-envelope"></i> ${profile.email || 'N/A'} • 
                <i class="fas fa-phone"></i> ${profile.phone || 'N/A'}
            `;
        }
        
        // Calculate and update member tier
        const totalSpent = parseFloat(profile.stats?.totalSpent || 0);
        const memberTier = calculateMemberTier(totalSpent);
        const memberTierElement = document.getElementById('memberTier');
        if (memberTierElement) {
            memberTierElement.innerHTML = `
                <i class="fas fa-${memberTier.icon}" style="color: ${memberTier.color};"></i>
                <span style="font-weight: 600;">${memberTier.tier} Member</span>
            `;
        }
        
        // Update personal info form
        const firstNameInput = document.querySelector('#personal input[placeholder*="first name"]');
        if (firstNameInput) firstNameInput.value = profile.first_name || '';
        
        const lastNameInput = document.querySelector('#personal input[placeholder*="last name"]');
        if (lastNameInput) lastNameInput.value = profile.last_name || '';
        
        const emailInput = document.querySelector('#personal input[type="email"]');
        if (emailInput) emailInput.value = profile.email || '';
        
        const phoneInput = document.querySelector('#personal input[type="tel"]');
        if (phoneInput) phoneInput.value = profile.phone || '';
        
        const dobInputs = document.querySelectorAll('#personal input[type="date"]');
        if (dobInputs[0] && profile.date_of_birth) dobInputs[0].value = profile.date_of_birth;
        
        const addressInput = document.querySelector('#personal input[placeholder*="address"]');
        if (addressInput) addressInput.value = profile.address || '';
        
        const passportInput = document.querySelector('#personal input[placeholder*="passport number"]');
        if (passportInput) passportInput.value = profile.passport_number || '';
        
        if (profile.passport_expiry && dobInputs[1]) {
            dobInputs[1].value = profile.passport_expiry;
        }
        
        // Update emergency contact
        const emergencyNameInput = document.getElementById('emergencyContactName');
        if (emergencyNameInput) emergencyNameInput.value = profile.emergency_contact_name || '';
        
        const emergencyPhoneInput = document.getElementById('emergencyContactPhone');
        if (emergencyPhoneInput) emergencyPhoneInput.value = profile.emergency_contact_phone || '';
        
        const emergencyRelationSelect = document.getElementById('emergencyContactRelation');
        if (emergencyRelationSelect) emergencyRelationSelect.value = profile.emergency_contact_relation || '';
        
        // Update stats
        updateProfileStats(profile.stats);
        
    } catch (error) {
        console.error('Error loading profile:', error);
        if (typeof showToast !== 'undefined') {
            showToast('Failed to load profile data', 'error');
        }
    }
}

/**
 * Update profile statistics
 */
function updateProfileStats(stats) {
    const totalBookings = stats?.totalBookings || 0;
    const totalSpent = parseFloat(stats?.totalSpent || 0);
    
    // Update stat cards
    const bookingsElement = document.getElementById('statTotalBookings');
    if (bookingsElement) bookingsElement.textContent = totalBookings;
    
    const spentElement = document.getElementById('statTotalSpent');
    if (spentElement) spentElement.textContent = `$${totalSpent.toFixed(0)}`;
    
    // Calculate reward points (1 point per dollar spent)
    const rewardPoints = Math.floor(totalSpent);
    const pointsElement = document.getElementById('statRewardPoints');
    if (pointsElement) pointsElement.textContent = rewardPoints;
    
    // Update member tier
    const memberTier = calculateMemberTier(totalSpent);
    const tierElement = document.getElementById('statMemberTier');
    if (tierElement) tierElement.textContent = memberTier.tier;
}

/**
 * Load user preferences
 */
async function loadPreferences() {
    try {
        userPreferences = await ProfileAPI.getPreferences();
        
        // Remove all active classes first
        document.querySelectorAll('#preferences .preference-tag').forEach(tag => {
            tag.classList.remove('active');
        });
        
        // Update seating preference
        const seatingPref = userPreferences.seating_preference || 'aisle';
        document.querySelectorAll('#preferences .preference-tag').forEach(tag => {
            const text = tag.textContent.trim().toLowerCase();
            if (seatingPref === 'aisle' && text.includes('aisle')) {
                tag.classList.add('active');
            } else if (seatingPref === 'window' && text.includes('window')) {
                tag.classList.add('active');
            } else if (seatingPref === 'extra_legroom' && text.includes('extra')) {
                tag.classList.add('active');
            } else if (seatingPref === 'family' && text.includes('family')) {
                tag.classList.add('active');
            }
        });
        
        // Update meal preference
        const mealPref = userPreferences.meal_preference || 'vegetarian';
        document.querySelectorAll('#preferences .preference-tag').forEach(tag => {
            const text = tag.textContent.trim().toLowerCase();
            if (mealPref === 'vegetarian' && text.includes('vegetarian')) {
                tag.classList.add('active');
            } else if (mealPref === 'non_veg' && (text.includes('non-veg') || text.includes('non veg'))) {
                tag.classList.add('active');
            } else if (mealPref === 'vegan' && text.includes('vegan')) {
                tag.classList.add('active');
            } else if (mealPref === 'gluten_free' && text.includes('gluten')) {
                tag.classList.add('active');
            }
        });
        
        // Update notification checkboxes
        const checkboxes = document.querySelectorAll('#preferences input[type="checkbox"]');
        if (checkboxes.length >= 4) {
            checkboxes[0].checked = userPreferences.notifications_flight_status || false;
            checkboxes[1].checked = userPreferences.notifications_price_drop || false;
            checkboxes[2].checked = userPreferences.notifications_promotions || false;
            checkboxes[3].checked = userPreferences.notifications_confirmations || false;
        }
        
    } catch (error) {
        console.error('Error loading preferences:', error);
    }
}

/**
 * Load booking statistics
 */
async function loadBookingStats() {
    try {
        const bookings = await BookingsAPI.list('', 100, 0);
        const bookingsList = bookings.bookings || [];
        
        // Update stats cards
        const totalBookings = bookingsList.length;
        const totalSpent = bookingsList.reduce((sum, b) => sum + parseFloat(b.total_price || 0), 0);
        
        const stats = {
            totalBookings: totalBookings,
            totalSpent: totalSpent
        };
        
        updateProfileStats(stats);
        
        // Load upcoming trips
        await loadUpcomingTrips(bookingsList);
        
        // Load recent activity
        await loadRecentActivity(bookingsList);
        
    } catch (error) {
        console.error('Error loading booking stats:', error);
    }
}

/**
 * Load upcoming trips
 */
async function loadUpcomingTrips(bookings) {
    const upcomingTripsDiv = document.getElementById('upcomingTrips');
    if (!upcomingTripsDiv) return;
    
    const now = new Date();
    const upcoming = bookings
        .filter(b => {
            const departureDate = new Date(b.departure_time);
            return departureDate > now && b.status === 'confirmed';
        })
        .sort((a, b) => new Date(a.departure_time) - new Date(b.departure_time))
        .slice(0, 3);
    
    if (upcoming.length === 0) {
        upcomingTripsDiv.innerHTML = `
            <div style="text-align: center; padding: 2rem; color: var(--gray);">
                <i class="fas fa-calendar-times" style="font-size: 2rem; margin-bottom: 1rem;"></i>
                <p>No upcoming trips</p>
                <a href="flights.html" class="btn btn-primary" style="margin-top: 1rem;">
                    <i class="fas fa-search"></i> Book a Flight
                </a>
            </div>
        `;
        return;
    }
    
    const gradients = [
        'linear-gradient(135deg, var(--primary), var(--secondary))',
        'linear-gradient(135deg, #f093fb, #f5576c)',
        'linear-gradient(135deg, #43e97b, #38f9d7)'
    ];
    
    upcomingTripsDiv.innerHTML = upcoming.map((booking, index) => {
        const departureTime = new Date(booking.departure_time);
        const statusClass = `status-${booking.status}`;
        const gradient = gradients[index % gradients.length];
        
        return `
            <div style="display: flex; align-items: center; gap: 15px; padding: 15px; background: #f8f9fa; border-radius: 10px;">
                <div style="background: ${gradient}; width: 50px; height: 50px; border-radius: 10px; display: flex; align-items: center; justify-content: center; color: white;">
                    <i class="fas fa-plane"></i>
                </div>
                <div style="flex: 1;">
                    <p style="margin: 0; font-weight: 500;">${booking.departure_city} → ${booking.arrival_city}</p>
                    <p style="margin: 5px 0 0; color: var(--gray); font-size: 0.9rem;">
                        ${formatDate(departureTime)} • ${formatTime(departureTime)}
                    </p>
                </div>
                <span class="booking-status ${statusClass}">${booking.status.toUpperCase()}</span>
            </div>
        `;
    }).join('');
}

/**
 * Load recent activity
 */
async function loadRecentActivity(bookings) {
    const activityDiv = document.getElementById('recentActivity');
    if (!activityDiv) return;
    
    const now = new Date();
    const activities = [];
    
    // Create activities from bookings
    bookings.forEach(booking => {
        const bookingDate = new Date(booking.booking_date);
        const departureDate = new Date(booking.departure_time);
        
        // Booking created activity
        activities.push({
            date: bookingDate,
            type: booking.payment_status === 'paid' ? 'confirmed' : 'pending',
            title: booking.payment_status === 'paid' ? 'Flight Booking Confirmed' : 'Payment Pending',
            description: `${booking.departure_city} → ${booking.arrival_city} • Flight ${booking.flight_number}`,
            bookingRef: booking.booking_reference
        });
        
        // If flight is completed
        if (departureDate < now && booking.status === 'confirmed') {
            activities.push({
                date: departureDate,
                type: 'completed',
                title: 'Flight Completed',
                description: `${booking.departure_city} → ${booking.arrival_city} • Flight ${booking.flight_number}`,
                bookingRef: booking.booking_reference
            });
        }
    });
    
    // Sort by date (newest first) and take top 5
    activities.sort((a, b) => b.date - a.date);
    const recentActivities = activities.slice(0, 5);
    
    if (recentActivities.length === 0) {
        activityDiv.innerHTML = `
            <div style="text-align: center; padding: 2rem; color: var(--gray);">
                <i class="fas fa-history" style="font-size: 2rem; margin-bottom: 1rem;"></i>
                <p>No recent activity</p>
            </div>
        `;
        return;
    }
    
    activityDiv.innerHTML = recentActivities.map(activity => {
        const timeAgo = getTimeAgo(activity.date);
        const bgColor = activity.type === 'confirmed' ? '#e8f5e9' : 
                       activity.type === 'pending' ? '#fff3cd' : 
                       activity.type === 'completed' ? '#e3f2fd' : '#f8f9fa';
        
        return `
            <div class="timeline-item">
                <div class="timeline-date">${timeAgo}</div>
                <div style="background: ${bgColor}; padding: 12px; border-radius: 10px;">
                    <p style="margin: 0; font-weight: 500;">${activity.title}</p>
                    <p style="margin: 5px 0 0; color: var(--gray); font-size: 0.9rem;">
                        ${activity.description}
                    </p>
                </div>
            </div>
        `;
    }).join('');
}

/**
 * Format date
 */
function formatDate(date) {
    return date.toLocaleDateString('en-US', { year: 'numeric', month: 'short', day: 'numeric' });
}

/**
 * Format time
 */
function formatTime(date) {
    return date.toLocaleTimeString('en-US', { hour: '2-digit', minute: '2-digit', hour12: true });
}

/**
 * Get time ago string
 */
function getTimeAgo(date) {
    const now = new Date();
    const diffMs = now - date;
    const diffMins = Math.floor(diffMs / 60000);
    const diffHours = Math.floor(diffMs / 3600000);
    const diffDays = Math.floor(diffMs / 86400000);
    
    if (diffMins < 60) {
        return diffMins <= 1 ? 'Just now' : `${diffMins} minutes ago`;
    } else if (diffHours < 24) {
        return diffHours === 1 ? '1 hour ago' : `${diffHours} hours ago`;
    } else if (diffDays === 0) {
        return 'Today, ' + formatTime(date);
    } else if (diffDays === 1) {
        return 'Yesterday, ' + formatTime(date);
    } else if (diffDays < 7) {
        return `${diffDays} days ago`;
    } else {
        return formatDate(date);
    }
}

/**
 * Save personal info
 */
async function savePersonalInfo() {
    const dobInputs = document.querySelectorAll('#personal input[type="date"]');
    const data = {
        firstName: document.querySelector('#personal input[placeholder*="first name"]')?.value || '',
        lastName: document.querySelector('#personal input[placeholder*="last name"]')?.value || '',
        phone: document.querySelector('#personal input[type="tel"]')?.value || '',
        dateOfBirth: dobInputs[0]?.value || '',
        address: document.querySelector('#personal input[placeholder*="address"]')?.value || '',
        passportNumber: document.querySelector('#personal input[placeholder*="passport number"]')?.value || '',
        passportExpiry: dobInputs[1]?.value || '',
        emergencyContactName: document.getElementById('emergencyContactName')?.value || '',
        emergencyContactPhone: document.getElementById('emergencyContactPhone')?.value || '',
        emergencyContactRelation: document.getElementById('emergencyContactRelation')?.value || ''
    };
    
    try {
        await ProfileAPI.update(data);
        if (typeof showToast !== 'undefined') {
            showToast('Profile updated successfully!', 'success');
        }
        // Reload profile to update avatar initials
        await loadProfile();
    } catch (error) {
        if (typeof showToast !== 'undefined') {
            showToast('Failed to update profile', 'error');
        }
    }
}

/**
 * Update password
 */
async function updatePassword() {
    const currentPassword = document.querySelector('#security input[placeholder*="current password"]')?.value;
    const newPassword = document.querySelector('#security input[placeholder*="new password"]')?.value;
    const confirmPassword = document.querySelector('#security input[placeholder*="confirm password"]')?.value;
    
    if (!currentPassword || !newPassword || !confirmPassword) {
        if (typeof showToast !== 'undefined') {
            showToast('Please fill all password fields', 'error');
        }
        return;
    }
    
    if (newPassword !== confirmPassword) {
        if (typeof showToast !== 'undefined') {
            showToast('New passwords do not match', 'error');
        }
        return;
    }
    
    try {
        await ProfileAPI.updatePassword(currentPassword, newPassword, confirmPassword);
        if (typeof showToast !== 'undefined') {
            showToast('Password updated successfully!', 'success');
        }
        // Clear password fields
        document.querySelectorAll('#security input[type="password"]').forEach(input => input.value = '');
    } catch (error) {
        if (typeof showToast !== 'undefined') {
            showToast(error.message || 'Failed to update password', 'error');
        }
    }
}

// Make functions available globally
window.savePersonalInfo = savePersonalInfo;
window.updatePassword = updatePassword;
window.loadProfile = loadProfile;
