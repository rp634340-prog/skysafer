/**
 * Notification bell + realtime updates (Socket.IO).
 */
(function initNotificationCenterGlobal() {
    const SOCKET_URL = 'http://127.0.0.1:3001';
    const MAX_ITEMS = 20;
    let socket = null;
    let state = {
        userId: null,
        role: 'user',
        isOpen: false
    };

    function ensureSocketClientScript() {
        if (window.io) return Promise.resolve();
        return new Promise((resolve, reject) => {
            const script = document.createElement('script');
            script.src = 'https://cdn.socket.io/4.8.1/socket.io.min.js';
            script.onload = () => resolve();
            script.onerror = reject;
            document.head.appendChild(script);
        });
    }

    function createBellMarkup() {
        if (document.getElementById('notificationBellWrap')) return;
        const navMenu = document.querySelector('.nav-menu');
        if (!navMenu) return;

        const wrap = document.createElement('div');
        wrap.id = 'notificationBellWrap';
        wrap.className = 'notification-bell-wrap';
        wrap.innerHTML = `
            <button id="notificationBell" class="notification-bell-btn" type="button" aria-label="Notifications">
                <i class="fas fa-bell"></i>
                <span id="notificationBadge" class="notification-badge hidden">0</span>
            </button>
            <div id="notificationDropdown" class="notification-dropdown hidden">
                <div class="notification-header">
                    <span>Notifications</span>
                    <button id="markAllReadBtn" type="button" class="mark-read-btn">Mark all read</button>
                </div>
                <div id="notificationList" class="notification-list">
                    <div class="notification-empty">No notifications</div>
                </div>
            </div>
        `;
        navMenu.appendChild(wrap);
    }

    function renderItems(items) {
        const list = document.getElementById('notificationList');
        if (!list) return;
        if (!items || items.length === 0) {
            list.innerHTML = '<div class="notification-empty">No notifications</div>';
            return;
        }
        list.innerHTML = items.map((item) => {
            const isRead = Number(item.is_read) === 1;
            const created = item.created_at ? new Date(item.created_at).toLocaleString() : '';
            return `
                <button class="notification-item ${isRead ? 'read' : 'unread'}" data-id="${item.id}" type="button">
                    <div class="notification-item-title">${item.title}</div>
                    <div class="notification-item-message">${item.message}</div>
                    <div class="notification-item-time">${created}</div>
                </button>
            `;
        }).join('');

        list.querySelectorAll('.notification-item').forEach((el) => {
            el.addEventListener('click', async () => {
                const id = Number(el.dataset.id);
                if (!id || typeof NotificationsAPI === 'undefined') return;
                try {
                    await NotificationsAPI.markRead(id);
                    await fetchAndRender();
                } catch (error) {
                    console.warn('Failed to mark notification as read', error);
                }
            });
        });
    }

    function updateBadge(unreadCount) {
        const badge = document.getElementById('notificationBadge');
        if (!badge) return;
        const count = Number(unreadCount || 0);
        badge.textContent = String(count > 99 ? '99+' : count);
        badge.classList.toggle('hidden', count <= 0);
    }

    async function fetchAndRender() {
        if (typeof NotificationsAPI === 'undefined') return;
        try {
            const response = await NotificationsAPI.list({ limit: MAX_ITEMS });
            renderItems(response.notifications || []);
            updateBadge(response.unreadCount || 0);
        } catch (error) {
            console.warn('Failed loading notifications', error);
        }
    }

    function prependRealtimeItem(payload) {
        const list = document.getElementById('notificationList');
        if (!list) return;
        const first = list.firstElementChild;
        const created = payload.createdAt ? new Date(payload.createdAt).toLocaleString() : new Date().toLocaleString();
        const node = document.createElement('button');
        node.className = 'notification-item unread';
        node.type = 'button';
        node.innerHTML = `
            <div class="notification-item-title">${payload.title || 'Notification'}</div>
            <div class="notification-item-message">${payload.message || ''}</div>
            <div class="notification-item-time">${created}</div>
        `;
        if (first && first.classList.contains('notification-empty')) {
            list.innerHTML = '';
        }
        list.prepend(node);

        const badge = document.getElementById('notificationBadge');
        const current = Number((badge && badge.textContent !== '99+' ? badge.textContent : 0) || 0);
        updateBadge(current + 1);
    }

    function bindUI() {
        const bell = document.getElementById('notificationBell');
        const dropdown = document.getElementById('notificationDropdown');
        const markAllReadBtn = document.getElementById('markAllReadBtn');
        if (!bell || !dropdown) return;

        bell.addEventListener('click', async () => {
            state.isOpen = !state.isOpen;
            dropdown.classList.toggle('hidden', !state.isOpen);
            if (state.isOpen) {
                await fetchAndRender();
            }
        });

        if (markAllReadBtn) {
            markAllReadBtn.addEventListener('click', async () => {
                if (typeof NotificationsAPI === 'undefined') return;
                await NotificationsAPI.markAllRead();
                await fetchAndRender();
            });
        }

        document.addEventListener('click', (event) => {
            const wrap = document.getElementById('notificationBellWrap');
            if (!wrap || wrap.contains(event.target)) return;
            state.isOpen = false;
            dropdown.classList.add('hidden');
        });
    }

    async function connectSocket() {
        await ensureSocketClientScript();
        if (!window.io) return;
        socket = window.io(SOCKET_URL, { transports: ['websocket', 'polling'] });

        socket.on('connect', () => {
            socket.emit('join', { userId: state.userId, role: state.role });
        });
        socket.on('notification', (payload) => {
            const toUser = payload.recipientUserId ? Number(payload.recipientUserId) === Number(state.userId) : false;
            const toRole = payload.targetRole && payload.targetRole === state.role;
            if (toUser || toRole) {
                prependRealtimeItem(payload);
            }
        });
    }

    async function init({ userId, role }) {
        if (!userId) return;
        state.userId = userId;
        state.role = role || 'user';
        createBellMarkup();
        bindUI();
        await fetchAndRender();
        try {
            await connectSocket();
        } catch (error) {
            console.warn('Realtime notifications unavailable', error);
        }
    }

    window.NotificationCenter = { init, refresh: fetchAndRender };
})();
