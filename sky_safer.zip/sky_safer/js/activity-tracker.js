/**
 * Activity Tracker
 * Queues user activity and sends in batches.
 */
(function initActivityTrackerGlobal() {
    if (typeof window === 'undefined') return;

    const MAX_BATCH_SIZE = 10;
    const FLUSH_INTERVAL_MS = 5000;
    const SEARCH_DEBOUNCE_MS = 300;
    const CLICK_THROTTLE_MS = 1000;

    const state = {
        queue: [],
        intervalId: null,
        clickThrottleMap: new Map(),
        searchDebounceTimer: null
    };

    function nowISO() {
        return new Date().toISOString();
    }

    function normalizePath(url) {
        try {
            return new URL(url, window.location.origin).pathname;
        } catch (error) {
            return window.location.pathname || '';
        }
    }

    function enqueue(event) {
        state.queue.push(event);
        if (state.queue.length >= MAX_BATCH_SIZE) {
            flush();
        }
    }

    function buildEvent(eventType, eventName, metadata = {}) {
        return {
            event_type: eventType,
            event_name: eventName,
            page_url: normalizePath(window.location.href),
            element_name: metadata.elementName || '',
            metadata,
            created_at: nowISO()
        };
    }

    function sendBatch(events) {
        if (!events || events.length === 0) return Promise.resolve();

        if (typeof ActivityAPI !== 'undefined' && ActivityAPI.batch) {
            return ActivityAPI.batch(events);
        }

        if (typeof apiRequest !== 'undefined') {
            return apiRequest('user-activity.php?action=batch', {
                method: 'POST',
                body: { events }
            });
        }

        return fetch('/api/user-activity.php?action=batch', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ events })
        }).then(response => response.json());
    }

    function flush() {
        if (state.queue.length === 0) {
            return Promise.resolve();
        }

        const events = state.queue.splice(0, MAX_BATCH_SIZE);
        return sendBatch(events).catch((error) => {
            // Re-queue only once to avoid losing events on transient failures.
            state.queue = events.concat(state.queue);
            console.warn('Activity flush failed:', error);
        });
    }

    function trackPageVisit(pageName = document.title || 'page') {
        enqueue(buildEvent('page_visit', pageName, {
            title: document.title || '',
            path: normalizePath(window.location.href),
            referrer: document.referrer || ''
        }));
    }

    function trackClick(eventOrData, metadata = {}) {
        const now = Date.now();
        let elementName = '';
        let eventName = 'click';
        let finalMetadata = metadata || {};

        if (eventOrData && eventOrData.target) {
            const target = eventOrData.target.closest('button, a, [data-track], [role="button"], input[type="submit"]');
            if (!target) return;

            elementName = target.id || target.name || target.dataset.track || target.textContent?.trim()?.slice(0, 64) || target.tagName.toLowerCase();
            eventName = target.dataset.trackEvent || 'click';
            finalMetadata = {
                ...finalMetadata,
                tag: target.tagName.toLowerCase(),
                text: target.textContent?.trim()?.slice(0, 100) || '',
                href: target.getAttribute('href') || ''
            };
        } else if (typeof eventOrData === 'object' && eventOrData !== null) {
            elementName = eventOrData.elementName || '';
            eventName = eventOrData.eventName || eventName;
            finalMetadata = {
                ...eventOrData,
                ...finalMetadata
            };
        }

        const key = `${normalizePath(window.location.href)}::${eventName}::${elementName}`;
        const last = state.clickThrottleMap.get(key) || 0;
        if (now - last < CLICK_THROTTLE_MS) {
            return;
        }
        state.clickThrottleMap.set(key, now);

        enqueue(buildEvent('click', eventName, {
            ...finalMetadata,
            elementName
        }));
    }

    function trackSearch(searchData = {}) {
        clearTimeout(state.searchDebounceTimer);
        state.searchDebounceTimer = setTimeout(() => {
            enqueue(buildEvent('search', 'flight_search', {
                ...searchData,
                query: searchData.query || `${searchData.from || ''}-${searchData.to || ''}`
            }));
        }, SEARCH_DEBOUNCE_MS);
    }

    function startPeriodicFlush() {
        if (state.intervalId) return;
        state.intervalId = setInterval(() => {
            flush();
        }, FLUSH_INTERVAL_MS);
    }

    function init() {
        startPeriodicFlush();

        if (!document.body || document.body.dataset.activityTrackerBound === '1') {
            return;
        }

        document.body.dataset.activityTrackerBound = '1';
        document.addEventListener('click', trackClick, true);
        window.addEventListener('beforeunload', () => {
            flush();
        });
    }

    window.ActivityTracker = {
        init,
        trackPageVisit,
        trackClick,
        trackSearch,
        flush
    };
})();
