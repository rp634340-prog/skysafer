/**
 * Admin dashboard rendering.
 */
document.addEventListener('DOMContentLoaded', async () => {
    try {
        if (typeof AuthAPI === 'undefined' || typeof AdminAPI === 'undefined') {
            throw new Error('Required API helpers are not available');
        }

        const auth = await AuthAPI.check();
        if (!auth.authenticated) {
            window.location.href = 'login.html';
            return;
        }
        if ((auth.user?.role || 'user') !== 'admin') {
            window.location.href = 'index.html';
            return;
        }

        await loadNavigation('admin.html');
        const data = await AdminAPI.dashboard();
        renderSystemStats(data.systemStats || {});
        renderUserAnalytics(data.userAnalytics || {});
        renderActivityLogs(data.activityLogs || []);
    } catch (error) {
        console.error('Failed to load admin dashboard', error);
        if (typeof showToast !== 'undefined') {
            showToast('Failed to load admin dashboard', 'error');
        }
    }
});

function renderSystemStats(stats) {
    const grid = document.getElementById('systemStatsGrid');
    if (!grid) return;
    const items = [
        { label: 'Weekly Active Users', value: stats.weeklyActiveUsers || 0, icon: 'fa-user-check' },
        { label: 'Total Bookings', value: stats.totalBookings || 0, icon: 'fa-ticket-alt' },
        { label: 'Revenue', value: '$' + Number(stats.totalRevenue || 0).toFixed(2), icon: 'fa-dollar-sign' },
        { label: 'Activity Events (7d)', value: stats.weeklyActivityEvents || 0, icon: 'fa-wave-square' },
        { label: 'Unread Notifications', value: stats.notificationsUnread || 0, icon: 'fa-bell' },
        { label: 'Flights', value: stats.flightsTotal || 0, icon: 'fa-plane' }
    ];

    grid.innerHTML = items.map((item) => `
        <div class="admin-card">
            <div class="admin-card-icon"><i class="fas ${item.icon}"></i></div>
            <div class="admin-card-value">${item.value}</div>
            <div class="admin-card-label">${item.label}</div>
        </div>
    `).join('');
}

function renderUserAnalytics(analytics) {
    const summary = document.getElementById('userSummary');
    const list = document.getElementById('topUsersList');
    if (summary) {
        summary.innerHTML = `
            <div class="admin-summary-item"><strong>Total users:</strong> ${analytics.totalUsers || 0}</div>
            <div class="admin-summary-item"><strong>New users (7d):</strong> ${analytics.newUsersLast7Days || 0}</div>
        `;
    }
    if (list) {
        const topUsers = analytics.topUsers || [];
        if (topUsers.length === 0) {
            list.innerHTML = '<div class="admin-empty">No user analytics available.</div>';
            return;
        }
        list.innerHTML = topUsers.map((user) => `
            <div class="admin-list-item">
                <div><strong>${escapeHtml(user.username)}</strong></div>
                <div>Bookings: ${Number(user.bookings_count || 0)}</div>
                <div>Spent: $${Number(user.total_spent || 0).toFixed(2)}</div>
            </div>
        `).join('');
    }
}

function renderActivityLogs(logs) {
    const list = document.getElementById('activityLogsList');
    if (!list) return;
    if (!logs || logs.length === 0) {
        list.innerHTML = '<div class="admin-empty">No activity logs available.</div>';
        return;
    }
    list.innerHTML = logs.map((log) => `
        <div class="admin-list-item">
            <div><strong>${escapeHtml(log.username)}</strong> · ${escapeHtml(log.event_type || '')}</div>
            <div>${escapeHtml(log.event_name || '')}</div>
            <div class="admin-muted">${escapeHtml(log.page_url || '')}</div>
            <div class="admin-muted">${new Date(log.created_at).toLocaleString()}</div>
        </div>
    `).join('');
}

function escapeHtml(value) {
    const text = String(value || '');
    return text
        .replaceAll('&', '&amp;')
        .replaceAll('<', '&lt;')
        .replaceAll('>', '&gt;')
        .replaceAll('"', '&quot;')
        .replaceAll("'", '&#039;');
}
