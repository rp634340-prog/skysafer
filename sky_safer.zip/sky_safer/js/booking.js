/**
 * Booking Page JavaScript
 * Handles flight booking form and submission
 */

document.addEventListener('DOMContentLoaded', async function() {
    // Check authentication
    try {
        const authCheck = await AuthAPI.check();
        if (!authCheck.authenticated) {
            window.location.href = 'login.html?redirect=booking';
            return;
        }
    } catch (error) {
        window.location.href = 'login.html?redirect=booking';
        return;
    }

    // Get booking data from sessionStorage
    const bookingDataStr = sessionStorage.getItem('bookingData');
    if (!bookingDataStr) {
        showError('No flight selected. Please select a flight first.');
        setTimeout(() => {
            window.location.href = 'flights.html';
        }, 2000);
        return;
    }

    const bookingData = JSON.parse(bookingDataStr);
    const {
        flightId,
        classType,
        passengers,
        price,
        departure_date,
        return_date,
        trip_type,
        tripType,
        returnFlightId,
    } = bookingData;

    window.SeatSelectionState = {
        socket: null,
        selectedSeats: [],
        seatMap: [],
        flightId: parseInt(flightId),
        classType,
        passengers: parseInt(passengers),
        lockRefreshTimer: null
    };

    // Load flight details
    await loadFlightDetails(flightId, classType, passengers, price, bookingData);

    // Load user profile for contact info
    await loadUserContactInfo();

    await initializeSeatSelection();

    // Setup form
    setupPassengerForms(passengers);
    setupBookingForm(flightId, classType, passengers, price, bookingData);

    window.addEventListener('beforeunload', releaseAllSelectedSeats);
});

/**
 * Load flight details and display in summary
 */
async function loadFlightDetails(flightId, classType, passengers, price, bookingMeta = {}) {
    try {
        const flight = await FlightsAPI.get(flightId);
        let returnFlight = null;
        if (bookingMeta.returnFlightId) {
            try {
                returnFlight = await FlightsAPI.get(bookingMeta.returnFlightId);
            } catch (e) {
                console.warn('Return flight details unavailable', e);
            }
        }
        displayFlightSummary(flight, classType, passengers, price, bookingMeta, returnFlight);
    } catch (error) {
        console.error('Error loading flight:', error);
        showError('Failed to load flight details. Please try again.');
    }
}

/**
 * Display flight summary
 */
function displayFlightSummary(flight, classType, passengers, price, bookingMeta = {}, returnFlight = null) {
    const summaryContainer = document.getElementById('flightSummary');
    const priceContainer = document.getElementById('priceSummary');

    const departureTime = new Date(flight.departure_time);
    const arrivalTime = new Date(flight.arrival_time);
    const duration = formatDuration(flight.duration_minutes);
    const trip = bookingMeta.trip_type || bookingMeta.tripType || 'one_way';
    const isRound = typeof FlightDates !== 'undefined'
        ? FlightDates.isRoundTrip(trip)
        : trip === 'round_trip';
    const departDateLabel = bookingMeta.departure_date
        ? (typeof FlightDates !== 'undefined' ? FlightDates.formatDisplayDate(bookingMeta.departure_date) : bookingMeta.departure_date)
        : null;
    const returnDateLabel = bookingMeta.return_date
        ? (typeof FlightDates !== 'undefined' ? FlightDates.formatDisplayDate(bookingMeta.return_date) : bookingMeta.return_date)
        : null;

    let tripDatesHtml = '';
    if (departDateLabel) {
        tripDatesHtml += `
        <div class="booking-trip-dates">
            <span class="trip-badge">${isRound ? 'Round trip' : 'One way'}</span>
            <div class="flight-summary-item"><strong>Departure date:</strong><span>${departDateLabel}</span></div>
            ${isRound && returnDateLabel ? `<div class="flight-summary-item"><strong>Return date:</strong><span>${returnDateLabel}</span></div>` : ''}
        </div>`;
    }

    summaryContainer.innerHTML = `
        ${tripDatesHtml}
        <div class="flight-summary-item">
            <strong>Flight:</strong>
            <span>${flight.flight_number}</span>
        </div>
        <div class="flight-summary-item">
            <strong>Airline:</strong>
            <span>${flight.airline_name}</span>
        </div>
        <div class="flight-summary-item">
            <strong>Route:</strong>
            <span>${flight.departure_city} → ${flight.arrival_city}</span>
        </div>
        <div class="flight-summary-item">
            <strong>Departure:</strong>
            <span>${formatDateTime(departureTime)}</span>
        </div>
        <div class="flight-summary-item">
            <strong>Arrival:</strong>
            <span>${formatDateTime(arrivalTime)}</span>
        </div>
        <div class="flight-summary-item">
            <strong>Duration:</strong>
            <span>${duration}</span>
        </div>
        <div class="flight-summary-item">
            <strong>Class:</strong>
            <span>${classType.charAt(0).toUpperCase() + classType.slice(1)}</span>
        </div>
        <div class="flight-summary-item">
            <strong>Passengers:</strong>
            <span>${passengers}</span>
        </div>
        ${flight.stops > 0 ? `
        <div class="flight-summary-item">
            <strong>Stops:</strong>
            <span>${flight.stops} stop${flight.stops > 1 ? 's' : ''}</span>
        </div>
        ` : ''}
        ${returnFlight ? `
        <hr style="margin:1rem 0;border:none;border-top:1px solid #e2e8f0;">
        <div class="flight-summary-item"><strong>Return flight:</strong><span>${returnFlight.flight_number}</span></div>
        <div class="flight-summary-item"><strong>Return route:</strong><span>${returnFlight.departure_city} → ${returnFlight.arrival_city}</span></div>
        ` : ''}
    `;

    const totalPrice = parseFloat(price) * parseInt(passengers, 10);
    priceContainer.innerHTML = `
        <div class="flight-summary-item">
            <strong>Price per passenger:</strong>
            <span>₹${parseFloat(price).toFixed(2)}</span>
        </div>
        <div class="flight-summary-item">
            <strong>Passengers:</strong>
            <span>${passengers}</span>
        </div>
        <div class="price-total">
            <strong>Total:</strong>
            <span>₹${totalPrice.toFixed(2)}</span>
        </div>
    `;
}

/**
 * Setup passenger forms
 */
function setupPassengerForms(passengerCount) {
    const container = document.getElementById('passengersContainer');
    container.innerHTML = '';

    for (let i = 1; i <= passengerCount; i++) {
        const passengerSection = document.createElement('div');
        passengerSection.className = 'passenger-section';
        passengerSection.innerHTML = `
            <div class="passenger-header">
                <span class="passenger-number">Passenger ${i}</span>
            </div>
            <div class="form-row">
                <div class="form-group">
                    <label for="passenger${i}_firstName">First Name *</label>
                    <input type="text" id="passenger${i}_firstName" required>
                </div>
                <div class="form-group">
                    <label for="passenger${i}_lastName">Last Name *</label>
                    <input type="text" id="passenger${i}_lastName" required>
                </div>
            </div>
            <div class="form-row">
                <div class="form-group">
                    <label for="passenger${i}_dateOfBirth">Date of Birth</label>
                    <input type="date" id="passenger${i}_dateOfBirth">
                </div>
                <div class="form-group">
                    <label for="passenger${i}_passport">Passport Number</label>
                    <input type="text" id="passenger${i}_passport" placeholder="Optional">
                </div>
            </div>
        `;
        container.appendChild(passengerSection);
    }
}

/**
 * Load user contact info
 */
async function loadUserContactInfo() {
    try {
        const profile = await ProfileAPI.get();
        if (profile.email) {
            document.getElementById('contactEmail').value = profile.email;
        }
        if (profile.phone) {
            document.getElementById('contactPhone').value = profile.phone;
        }
    } catch (error) {
        console.error('Error loading profile:', error);
        // Continue without pre-filling
    }
}

/**
 * Setup booking form submission
 */
function setupBookingForm(flightId, classType, passengers, price, bookingMeta = {}) {
    const form = document.getElementById('bookingForm');
    const submitBtn = document.getElementById('submitBtn');
    const loading = document.getElementById('loading');

    form.addEventListener('submit', async (e) => {
        e.preventDefault();

        // Collect passenger data
        const passengerData = [];
        const passengerCount = parseInt(passengers);
        const seatState = window.SeatSelectionState || { selectedSeats: [] };

        for (let i = 1; i <= passengerCount; i++) {
            const firstName = document.getElementById(`passenger${i}_firstName`).value.trim();
            const lastName = document.getElementById(`passenger${i}_lastName`).value.trim();
            const dateOfBirth = document.getElementById(`passenger${i}_dateOfBirth`).value;
            const passportNumber = document.getElementById(`passenger${i}_passport`).value.trim();

            if (!firstName || !lastName) {
                showError(`Please fill in all required fields for Passenger ${i}`);
                return;
            }

            passengerData.push({
                firstName,
                lastName,
                dateOfBirth: dateOfBirth || null,
                passportNumber: passportNumber || null
            });
        }

        // Get contact info
        const contactEmail = document.getElementById('contactEmail').value.trim();
        const contactPhone = document.getElementById('contactPhone').value.trim();

        if (!contactEmail || !contactPhone) {
            showError('Please provide contact email and phone number');
            return;
        }

        if (!seatState.selectedSeats || seatState.selectedSeats.length !== passengerCount) {
            showError(`Please select ${passengerCount} seat${passengerCount > 1 ? 's' : ''} before confirming.`);
            return;
        }

        // Disable form
        submitBtn.disabled = true;
        loading.classList.add('active');
        hideError();
        hideSuccess();

        // Update progress indicator to Review & Confirm step
        updateProgressIndicator(2);

        try {
            // Create booking
            const bookingData = {
                flightId: parseInt(flightId),
                passengersCount: passengerCount,
                classType: classType,
                passengers: passengerData,
                selectedSeats: seatState.selectedSeats,
                departure_date: bookingMeta.departure_date || null,
                return_date: bookingMeta.return_date || null,
                tripType: bookingMeta.tripType || bookingMeta.trip_type || 'one_way',
                returnFlightId: bookingMeta.returnFlightId ? parseInt(bookingMeta.returnFlightId, 10) : null,
            };

            const response = await BookingsAPI.create(bookingData);

            if (response.success) {
                showSuccess('Booking confirmed! Redirecting to your bookings...');
                
                // Clear session storage
                sessionStorage.removeItem('bookingData');
                clearSeatSelectionState();
                
                // Redirect to bookings page after 2 seconds
                setTimeout(() => {
                    window.location.href = 'my-bookings.html';
                }, 2000);
            } else {
                showError(response.error || 'Failed to create booking');
                submitBtn.disabled = false;
                loading.classList.remove('active');
            }
        } catch (error) {
            console.error('Booking error:', error);
            showError(error.message || 'Failed to create booking. Please try again.');
            submitBtn.disabled = false;
            loading.classList.remove('active');
        }
    });
}

async function initializeSeatSelection() {
    const state = window.SeatSelectionState;
    if (!state) return;
    await refreshSeatLayout();
    await connectSeatSocket();
    startSeatLockRefresh();
}

async function refreshSeatLayout() {
    const state = window.SeatSelectionState;
    const seatMapEl = document.getElementById('seatMap');
    const seatStatusEl = document.getElementById('seatStatus');
    if (!state || !seatMapEl || !seatStatusEl) return;

    try {
        const response = await BookingsAPI.seatLayout(state.flightId, state.classType);
        state.seatMap = response.seats || [];
        reconcileSelectedSeatsWithLayout();
        renderSeatMap();
        seatStatusEl.textContent = `${state.selectedSeats.length}/${state.passengers} selected • ${response.stats?.available ?? 0} available`;
    } catch (error) {
        console.error('Seat layout load failed', error);
        seatStatusEl.textContent = 'Failed to load seats';
        seatMapEl.innerHTML = '';
        showError('Unable to load seat layout right now. Please refresh.');
    }
}

function renderSeatMap() {
    const state = window.SeatSelectionState;
    const seatMapEl = document.getElementById('seatMap');
    if (!state || !seatMapEl) return;

    seatMapEl.innerHTML = '';
    const seats = Array.isArray(state.seatMap) ? state.seatMap : [];
    seats.forEach((seat) => {
        const btn = document.createElement('button');
        btn.type = 'button';
        btn.className = `seat-btn ${seat.state || 'available'}`;
        btn.textContent = seat.seat_number;
        btn.dataset.seat = seat.seat_number;

        if (state.selectedSeats.includes(seat.seat_number)) {
            btn.classList.add('selected');
        }

        const blockedStates = ['booked', 'locked'];
        if (blockedStates.includes(seat.state)) {
            btn.disabled = true;
        }

        btn.addEventListener('click', () => handleSeatClick(seat));
        seatMapEl.appendChild(btn);
    });
}

async function handleSeatClick(seat) {
    const state = window.SeatSelectionState;
    if (!state || !seat) return;
    hideError();

    const seatNumber = seat.seat_number;
    const isSelected = state.selectedSeats.includes(seatNumber);

    if (isSelected) {
        await releaseSeat(seatNumber);
        return;
    }

    if (state.selectedSeats.length >= state.passengers) {
        showError(`You can select up to ${state.passengers} seat${state.passengers > 1 ? 's' : ''}.`);
        return;
    }

    try {
        await BookingsAPI.lockSeat(state.flightId, state.classType, seatNumber);
        state.selectedSeats.push(seatNumber);
        await refreshSeatLayout();
    } catch (error) {
        showError(error.message || 'Unable to lock seat.');
    }
}

async function releaseSeat(seatNumber) {
    const state = window.SeatSelectionState;
    if (!state) return;

    try {
        await BookingsAPI.unlockSeat(state.flightId, state.classType, seatNumber);
    } catch (error) {
        console.warn('Unlock seat failed', error);
    }

    state.selectedSeats = state.selectedSeats.filter((seat) => seat !== seatNumber);
    await refreshSeatLayout();
}

function reconcileSelectedSeatsWithLayout() {
    const state = window.SeatSelectionState;
    if (!state) return;

    const validSelected = new Set();
    (state.seatMap || []).forEach((seat) => {
        if (seat.state === 'locked-by-me') {
            validSelected.add(seat.seat_number);
        }
    });
    state.selectedSeats = state.selectedSeats.filter((seat) => validSelected.has(seat));
}

async function connectSeatSocket() {
    const state = window.SeatSelectionState;
    if (!state || !window.io) return;

    try {
        const authCheck = await AuthAPI.check();
        const socket = window.io('http://127.0.0.1:3001', { transports: ['websocket', 'polling'] });
        state.socket = socket;
        socket.on('connect', () => {
            socket.emit('join', { userId: authCheck.user?.id || null, role: authCheck.user?.role || 'user' });
            socket.emit('joinSeatRoom', { flightId: state.flightId, classType: state.classType });
        });

        socket.on('seat_update', (payload) => {
            if (!payload || payload.type !== 'seat_update') return;
            const p = payload.payload || {};
            if (Number(p.flightId) !== Number(state.flightId) || p.classType !== state.classType) return;
            refreshSeatLayout();
        });
    } catch (error) {
        console.warn('Seat live updates unavailable', error);
    }
}

function startSeatLockRefresh() {
    const state = window.SeatSelectionState;
    if (!state) return;

    if (state.lockRefreshTimer) {
        clearInterval(state.lockRefreshTimer);
    }
    state.lockRefreshTimer = setInterval(async () => {
        if (!state.selectedSeats || state.selectedSeats.length === 0) return;
        const seatsToRefresh = [...state.selectedSeats];
        for (const seat of seatsToRefresh) {
            try {
                await BookingsAPI.lockSeat(state.flightId, state.classType, seat);
            } catch (error) {
                console.warn('Lock refresh failed for', seat);
            }
        }
        await refreshSeatLayout();
    }, 120000);
}

async function releaseAllSelectedSeats() {
    const state = window.SeatSelectionState;
    if (!state || !state.selectedSeats || state.selectedSeats.length === 0) return;

    const seats = [...state.selectedSeats];
    state.selectedSeats = [];
    await Promise.all(seats.map((seat) =>
        BookingsAPI.unlockSeat(state.flightId, state.classType, seat).catch(() => null)
    ));
}

function clearSeatSelectionState() {
    const state = window.SeatSelectionState;
    if (!state) return;
    if (state.lockRefreshTimer) {
        clearInterval(state.lockRefreshTimer);
        state.lockRefreshTimer = null;
    }
    if (state.socket) {
        state.socket.emit('leaveSeatRoom', { flightId: state.flightId, classType: state.classType });
        state.socket.disconnect();
        state.socket = null;
    }
    state.selectedSeats = [];
}

/**
 * Format duration
 */
function formatDuration(minutes) {
    const hours = Math.floor(minutes / 60);
    const mins = minutes % 60;
    return `${hours}h ${mins}m`;
}

/**
 * Format date and time
 */
function formatDateTime(date) {
    return date.toLocaleString('en-US', {
        month: 'short',
        day: 'numeric',
        year: 'numeric',
        hour: 'numeric',
        minute: '2-digit',
        hour12: true
    });
}

/**
 * Show error message
 */
function showError(message) {
    const errorDiv = document.getElementById('errorMessage');
    errorDiv.textContent = message;
    errorDiv.classList.add('active');
    errorDiv.scrollIntoView({ behavior: 'smooth', block: 'nearest' });
}

/**
 * Hide error message
 */
function hideError() {
    document.getElementById('errorMessage').classList.remove('active');
}

/**
 * Show success message
 */
function showSuccess(message) {
    const successDiv = document.getElementById('successMessage');
    successDiv.textContent = message;
    successDiv.classList.add('active');
    successDiv.scrollIntoView({ behavior: 'smooth', block: 'nearest' });
}

/**
 * Hide success message
 */
function hideSuccess() {
    document.getElementById('successMessage').classList.remove('active');
}

/**
 * Update progress indicator
 */
function updateProgressIndicator(step) {
    const steps = document.querySelectorAll('.progress-step');
    const lines = document.querySelectorAll('.progress-line');
    
    steps.forEach((stepEl, index) => {
        if (index < step) {
            stepEl.classList.add('completed');
            stepEl.classList.remove('active');
        } else if (index === step) {
            stepEl.classList.add('active');
            stepEl.classList.remove('completed');
        } else {
            stepEl.classList.remove('active', 'completed');
        }
    });
    
    lines.forEach((line, index) => {
        if (index < step - 1) {
            line.classList.add('completed');
        } else {
            line.classList.remove('completed');
        }
    });
}
