// main.js - Main JavaScript file with API integration
document.addEventListener('DOMContentLoaded', function() {
    // Load API helper
    if (typeof AuthAPI === 'undefined') {
        const script = document.createElement('script');
        script.src = 'js/api.js';
        document.head.appendChild(script);
    }

    // Load activity tracker if needed
    if (typeof ActivityTracker === 'undefined') {
        const trackerScript = document.createElement('script');
        trackerScript.src = 'js/activity-tracker.js';
        document.head.appendChild(trackerScript);
        trackerScript.onload = () => {
            if (typeof ActivityTracker !== 'undefined') {
                ActivityTracker.init();
                ActivityTracker.trackPageVisit(document.title || 'page');
            }
        };
    } else {
        ActivityTracker.init();
        ActivityTracker.trackPageVisit(document.title || 'page');
    }
    
    // Mobile Menu Toggle
    const menuToggle = document.getElementById('menuToggle');
    const navMenu = document.querySelector('.nav-menu');
    
    if (menuToggle) {
        menuToggle.addEventListener('click', () => {
            navMenu.classList.toggle('active');
            menuToggle.innerHTML = navMenu.classList.contains('active') 
                ? '<i class="fas fa-times"></i>' 
                : '<i class="fas fa-bars"></i>';
        });
    }

    // Check authentication status
    checkAuthStatus();

    // Trip type + departure / return date fields
    if (typeof FlightDates !== 'undefined') {
        FlightDates.initForm({
            tripTypeSelectId: 'tripType',
            departureInputId: 'departure_date',
            returnGroupId: 'returnDateGroup',
            returnInputId: 'return_date',
            errorBoxId: 'flightDateError',
        });
    }

    // Passenger Counter
    const decreaseBtn = document.getElementById('decreasePassengers');
    const increaseBtn = document.getElementById('increasePassengers');
    const passengersInput = document.getElementById('passengers');
    
    if (decreaseBtn && increaseBtn && passengersInput) {
        decreaseBtn.addEventListener('click', () => {
            let value = parseInt(passengersInput.value);
            if (value > 1) {
                passengersInput.value = value - 1;
            }
        });
        
        increaseBtn.addEventListener('click', () => {
            let value = parseInt(passengersInput.value);
            if (value < 9) {
                passengersInput.value = value + 1;
            }
        });
    }

    // City Suggestions (fallback - airports.js handles this better)
    const cities = [
        'New York (JFK)', 'Los Angeles (LAX)', 'Chicago (ORD)', 
        'Miami (MIA)', 'London (LHR)', 'Paris (CDG)', 
        'Tokyo (NRT)', 'Dubai (DXB)', 'Singapore (SIN)',
        'Sydney (SYD)', 'Toronto (YYZ)', 'Hong Kong (HKG)',
        'Mahesana (MAH)', 'Surat (STV)', 'Mumbai (BOM)',
        'Delhi (DEL)', 'Bangalore (BLR)', 'Chennai (MAA)'
    ];

    const fromCity = document.getElementById('fromCity');
    const toCity = document.getElementById('toCity');
    const fromSuggestions = document.getElementById('fromSuggestions');
    const toSuggestions = document.getElementById('toSuggestions');

    function showSuggestions(input, suggestionsBox, query) {
        if (query.length > 1) {
            const filtered = cities.filter(city => 
                city.toLowerCase().includes(query.toLowerCase())
            );
            
            suggestionsBox.innerHTML = '';
            if (filtered.length > 0) {
                suggestionsBox.style.display = 'block';
                filtered.forEach(city => {
                    const div = document.createElement('div');
                    div.className = 'suggestion-item';
                    div.textContent = city;
                    div.addEventListener('click', () => {
                        input.value = city;
                        suggestionsBox.style.display = 'none';
                    });
                    suggestionsBox.appendChild(div);
                });
            } else {
                suggestionsBox.style.display = 'none';
            }
        } else {
            suggestionsBox.style.display = 'none';
        }
    }

    if (fromCity && fromSuggestions) {
        fromCity.addEventListener('input', (e) => {
            showSuggestions(fromCity, fromSuggestions, e.target.value);
        });
        
        document.addEventListener('click', (e) => {
            if (!fromCity.contains(e.target) && !fromSuggestions.contains(e.target)) {
                fromSuggestions.style.display = 'none';
            }
        });
    }

    if (toCity && toSuggestions) {
        toCity.addEventListener('input', (e) => {
            showSuggestions(toCity, toSuggestions, e.target.value);
        });
        
        document.addEventListener('click', (e) => {
            if (!toCity.contains(e.target) && !toSuggestions.contains(e.target)) {
                toSuggestions.style.display = 'none';
            }
        });
    }

    const departDate = document.getElementById('departure_date');
    const returnDate = document.getElementById('return_date');
    const tripTypeSelect = document.getElementById('tripType');

    // Form Validation and Search
    const searchForm = document.getElementById('searchForm');
    if (searchForm) {
        searchForm.addEventListener('submit', async (e) => {
            e.preventDefault();
            
            const from = fromCity ? fromCity.value.trim() : '';
            const to = toCity ? toCity.value.trim() : '';
            const depart = departDate ? departDate.value : '';
            const returnDateValue = returnDate ? returnDate.value : '';
            const tripType = tripTypeSelect ? tripTypeSelect.value : 'one_way';
            const passengers = passengersInput ? passengersInput.value : 1;
            const classType = document.getElementById('classType') ? document.getElementById('classType').value : 'economy';

            if (typeof FlightDates !== 'undefined' && !FlightDates.validateForm(tripType, depart, returnDateValue, 'flightDateError')) {
                return;
            }
            
            if (!from || !to || !depart) {
                if (typeof showToast !== 'undefined') {
                    showToast('Please fill in all required fields', 'error');
                } else {
                    alert('Please fill in all required fields');
                }
                return;
            }
            
            if (from === to) {
                if (typeof showToast !== 'undefined') {
                    showToast('Departure and arrival cities cannot be the same', 'error');
                } else {
                    alert('Departure and arrival cities cannot be the same');
                }
                return;
            }
            
            // Extract city code or name
            let fromCityCode = extractCityCode(from);
            let toCityCode = extractCityCode(to);
            
            // If no code found, use the city name as-is
            if (!fromCityCode || fromCityCode === from) {
                fromCityCode = from;
            }
            if (!toCityCode || toCityCode === to) {
                toCityCode = to;
            }
            
            // Redirect to flights page with search parameters
            const params = new URLSearchParams({
                from: fromCityCode,
                to: toCityCode,
                departDate: depart,
                returnDate: returnDateValue,
                tripType: tripType,
                passengers: passengers,
                class: classType
            });

            if (typeof ActivityTracker !== 'undefined') {
                ActivityTracker.trackSearch({
                    from: fromCityCode,
                    to: toCityCode,
                    departDate: depart,
                    returnDate: returnDateValue,
                    tripType: tripType,
                    passengers: passengers,
                    classType: classType,
                    source: 'home-search'
                });
                ActivityTracker.flush();
            }
            
            window.location.href = `flights.html?${params.toString()}`;
        });
    }

    // Flight Filtering (for flights.html)
    const airlineFilters = document.querySelectorAll('input[name="airline"]');
    const priceFilter = document.getElementById('priceFilter');
    const flightCards = document.querySelectorAll('.flight-card');
    
    if (airlineFilters.length > 0 && flightCards.length > 0) {
        function filterFlights() {
            const selectedAirlines = Array.from(airlineFilters)
                .filter(filter => filter.checked)
                .map(filter => filter.value.toLowerCase());
            
            const maxPrice = parseInt(priceFilter.value);
            
            flightCards.forEach(card => {
                const airline = card.dataset.airline ? card.dataset.airline.toLowerCase() : '';
                const price = parseInt(card.dataset.price || 0);
                
                const airlineMatch = selectedAirlines.length === 0 || 
                                   selectedAirlines.includes(airline);
                const priceMatch = !maxPrice || price <= maxPrice;
                
                if (airlineMatch && priceMatch) {
                    card.style.display = 'grid';
                } else {
                    card.style.display = 'none';
                }
            });
        }
        
        airlineFilters.forEach(filter => {
            filter.addEventListener('change', filterFlights);
        });
        
        if (priceFilter) {
            priceFilter.addEventListener('input', filterFlights);
        }
    }
});

/**
 * Extract city code from city string (e.g., "New York (JFK)" -> "JFK")
 */
function extractCityCode(cityString) {
    const match = cityString.match(/\(([A-Z]{3})\)/);
    return match ? match[1] : cityString.split('(')[0].trim();
}

/**
 * Check authentication status and update UI
 */
async function checkAuthStatus() {
    try {
        if (typeof AuthAPI !== 'undefined') {
            const response = await AuthAPI.check();
            if (response.authenticated) {
                updateUIForLoggedInUser(response.user);
            } else {
                updateUIForLoggedOutUser();
            }
        }
    } catch (error) {
        console.error('Auth check failed:', error);
        updateUIForLoggedOutUser();
    }
}

/**
 * Update UI for logged in user
 */
function updateUIForLoggedInUser(user) {
    // Hide login/signup links
    const loginLink = document.getElementById('loginLink');
    const signupLink = document.getElementById('signupLink');
    if (loginLink) loginLink.style.display = 'none';
    if (signupLink) signupLink.style.display = 'none';
    
    // Show profile link
    const profileLink = document.getElementById('profileLink');
    if (profileLink) {
        profileLink.style.display = 'flex';
        profileLink.innerHTML = `<i class="fas fa-user"></i> ${user.firstName || user.username}`;
    }
}

/**
 * Update UI for logged out user
 */
function updateUIForLoggedOutUser() {
    const loginLink = document.getElementById('loginLink');
    const signupLink = document.getElementById('signupLink');
    if (loginLink) loginLink.style.display = 'flex';
    if (signupLink) signupLink.style.display = 'flex';
    
    const profileLink = document.getElementById('profileLink');
    if (profileLink && !profileLink.href.includes('profile.html')) {
        profileLink.style.display = 'none';
    }
}
