/**
 * Bookings Page JavaScript
 * Loads and displays user bookings
 */

document.addEventListener('DOMContentLoaded', async function() {
    // Load API if not loaded
    if (typeof BookingsAPI === 'undefined') {
        const script = document.createElement('script');
        script.src = 'js/api.js';
        document.head.appendChild(script);
        await new Promise(resolve => script.onload = resolve);
    }
    
    // Check authentication
    try {
        const authResponse = await AuthAPI.check();
        if (!authResponse.authenticated) {
            window.location.href = 'login.html';
            return;
        }
        
        // Setup tab switching first
        setupTabs();
        
        // Load all bookings by default
        await loadBookings('all');
    } catch (error) {
        console.error('Error loading bookings:', error);
        if (typeof showToast !== 'undefined') {
            showToast('Failed to load bookings. Please login again.', 'error');
        }
        setTimeout(() => {
            window.location.href = 'login.html';
        }, 2000);
    }
});

/**
 * Setup booking tabs
 */
function setupTabs() {
    document.querySelectorAll('.booking-tab').forEach(tab => {
        tab.addEventListener('click', function() {
            document.querySelectorAll('.booking-tab').forEach(t => t.classList.remove('active'));
            this.classList.add('active');
            
            const tabName = this.getAttribute('data-tab');
            loadBookings(tabName);
        });
    });
}

/**
 * Load bookings
 */
async function loadBookings(status = 'upcoming') {
    // Hide all booking sections
    const sections = ['upcoming-bookings', 'completed-bookings', 'cancelled-bookings', 'all-bookings'];
    sections.forEach(id => {
        const el = document.getElementById(id);
        if (el) el.style.display = 'none';
    });
    
    // Show appropriate section
    let containerId = 'upcoming-bookings';
    if (status === 'completed') containerId = 'completed-bookings';
    else if (status === 'cancelled') containerId = 'cancelled-bookings';
    else if (status === 'all') containerId = 'all-bookings';
    
    const container = document.getElementById(containerId);
    if (!container) return;
    
    container.style.display = 'block';
    
    // Get or create booking-history div
    let historyDiv = container.querySelector('.booking-history');
    if (!historyDiv) {
        historyDiv = document.createElement('div');
        historyDiv.className = 'booking-history';
        container.appendChild(historyDiv);
    }
    
    // Show loading state only in the booking-history div
    historyDiv.style.display = 'block';
    historyDiv.innerHTML = '<div style="text-align: center; padding: 2rem;"><i class="fas fa-spinner fa-spin"></i> Loading bookings...</div>';
    
    try {
        let bookings = [];
        const now = new Date();
        
        if (status === 'all') {
            // Get all bookings regardless of status
            const response = await BookingsAPI.list('', 100, 0);
            bookings = response.bookings || [];
        } else if (status === 'upcoming') {
            // Get confirmed bookings with future departure dates
            const response = await BookingsAPI.list('', 100, 0);
            const allBookings = response.bookings || [];
            bookings = allBookings.filter(booking => {
                const departureDate = new Date(booking.departure_time);
                return booking.status === 'confirmed' && departureDate > now;
            });
        } else if (status === 'completed') {
            // Get bookings with past departure dates or status completed
            const response = await BookingsAPI.list('', 100, 0);
            const allBookings = response.bookings || [];
            bookings = allBookings.filter(booking => {
                const departureDate = new Date(booking.departure_time);
                return booking.status === 'completed' || (departureDate < now && booking.status === 'confirmed');
            });
        } else if (status === 'cancelled') {
            // Get cancelled bookings
            const response = await BookingsAPI.list('cancelled', 100, 0);
            bookings = response.bookings || [];
        }
        
        if (bookings.length === 0) {
            const statusText = status === 'all' ? '' : status + ' ';
            const emptyState = `
                <div class="empty-state">
                    <i class="fas fa-ticket-alt"></i>
                    <h3>No ${statusText}bookings found</h3>
                    <p>Your ${statusText}bookings will appear here.</p>
                    <a href="flights.html" class="btn btn-primary" style="margin-top: 1rem;">
                        <i class="fas fa-search"></i> Book New Flight
                    </a>
                </div>
            `;
            historyDiv.innerHTML = emptyState;
            return;
        }
        
        // Display bookings
        const bookingsHTML = bookings.map(booking => createBookingCard(booking)).join('');
        historyDiv.innerHTML = bookingsHTML;
        
        // Update statistics - load all bookings for accurate stats
        try {
            const allBookingsResponse = await BookingsAPI.list('', 100, 0);
            const allBookings = allBookingsResponse.bookings || [];
            updateStatistics(allBookings);
        } catch (error) {
            console.error('Error loading statistics:', error);
            // Fallback to current bookings if error
            updateStatistics(bookings);
        }
        
    } catch (error) {
        console.error('Error loading bookings:', error);
        const errorState = `
            <div class="empty-state">
                <i class="fas fa-exclamation-triangle"></i>
                <h3>Error loading bookings</h3>
                <p>${error.message || 'Please try again later'}</p>
            </div>
        `;
        // Ensure historyDiv exists (it should from the code above)
        if (historyDiv) {
            historyDiv.innerHTML = errorState;
        } else {
            // Fallback if historyDiv doesn't exist
            const fallbackDiv = container.querySelector('.booking-history') || document.createElement('div');
            fallbackDiv.className = 'booking-history';
            fallbackDiv.innerHTML = errorState;
            if (!container.querySelector('.booking-history')) {
                container.appendChild(fallbackDiv);
            }
        }
    }
}

/**
 * Create booking card HTML
 */
function createBookingCard(booking) {
    const departureTime = new Date(booking.departure_time);
    const arrivalTime = new Date(booking.arrival_time);
    const bookingDate = new Date(booking.booking_date);
    
    const statusClass = `status-${booking.status}`;
    const statusText = booking.status.toUpperCase();
    
    return `
        <div class="booking-history-item fade-in">
            <div style="flex: 1;">
                <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 10px;">
                    <h3 style="margin: 0;">${booking.departure_city} → ${booking.arrival_city}</h3>
                    <span class="booking-status ${statusClass}">${statusText}</span>
                </div>
                <p style="margin: 5px 0; color: var(--gray);">
                    <i class="fas fa-plane-departure"></i> Flight ${booking.flight_number} • ${booking.airline_name}
                </p>
                <p style="margin: 5px 0; color: var(--gray);">
                    <i class="fas fa-calendar-alt"></i> ${formatDate(departureTime)} • ${formatTime(departureTime)} → ${formatTime(arrivalTime)}
                </p>
                ${booking.departure_date ? `
                <p style="margin: 5px 0; color: var(--gray);">
                    <i class="fas fa-route"></i>
                    ${(booking.trip_type === 'round_trip') ? 'Round trip' : 'One way'}
                    • Depart: ${booking.departure_date}${booking.return_date ? ` • Return: ${booking.return_date}` : ''}
                </p>` : ''}
                ${booking.return_flight_number ? `
                <p style="margin: 5px 0; color: var(--gray);">
                    <i class="fas fa-plane-arrival"></i> Return: ${booking.return_flight_number}
                </p>` : ''}
                <p style="margin: 5px 0; color: var(--gray);">
                    <i class="fas fa-users"></i> ${booking.passengers_count} Passenger${booking.passengers_count > 1 ? 's' : ''} • 
                    <i class="fas fa-couch"></i> ${booking.class_type.charAt(0).toUpperCase() + booking.class_type.slice(1)}
                </p>
                <div class="booking-actions">
                    <button class="btn btn-primary btn-small" onclick="viewBookingDetails('${booking.booking_reference}')">
                        <i class="fas fa-eye"></i> View Details
                    </button>
                    ${booking.status === 'confirmed' ? `
                        <button class="btn btn-outline btn-small" onclick="downloadTicket('${booking.booking_reference}')">
                            <i class="fas fa-download"></i> Download Ticket
                        </button>
                        <button class="btn btn-danger btn-small" onclick="cancelBooking(${booking.id}, '${booking.class_type}')">
                            <i class="fas fa-times"></i> Cancel
                        </button>
                    ` : ''}
                    ${(booking.status === 'pending' || booking.payment_status === 'pending') ? `
                        <button class="btn btn-success btn-small" onclick="makePayment('${booking.booking_reference}')">
                            <i class="fas fa-credit-card"></i> Complete Payment
                        </button>
                    ` : ''}
                </div>
            </div>
            <div style="text-align: right;">
                <p class="price" style="margin: 0;">$${parseFloat(booking.total_price).toFixed(2)}</p>
                <p style="margin: 5px 0; color: var(--gray); font-size: 0.9rem;">Booking #${booking.booking_reference}</p>
                <p style="margin: 0; color: var(--gray); font-size: 0.9rem;">
                    <i class="fas fa-clock"></i> Booked on ${formatDate(bookingDate)}
                </p>
            </div>
        </div>
    `;
}

/**
 * Update statistics
 */
function updateStatistics(bookings) {
    const now = new Date();
    const totalBookings = bookings.length;
    const totalSpent = bookings.reduce((sum, b) => sum + parseFloat(b.total_price || 0), 0);
    
    // Count upcoming flights (confirmed with future departure date)
    const upcomingCount = bookings.filter(b => {
        if (b.status !== 'confirmed') return false;
        const departureDate = new Date(b.departure_time);
        return departureDate > now;
    }).length;
    
    // Calculate reward points (example: 1 point per dollar spent)
    const rewardPoints = Math.floor(totalSpent);
    
    // Update stats if elements exist
    const statsElements = document.querySelectorAll('.stat-card h3');
    if (statsElements.length >= 4) {
        if (statsElements[0]) statsElements[0].textContent = totalBookings;
        if (statsElements[1]) statsElements[1].textContent = `$${totalSpent.toFixed(0)}`;
        if (statsElements[2]) statsElements[2].textContent = upcomingCount;
        if (statsElements[3]) statsElements[3].textContent = rewardPoints;
    } else if (statsElements.length >= 3) {
        // Fallback if only 3 stat cards exist
        if (statsElements[0]) statsElements[0].textContent = totalBookings;
        if (statsElements[1]) statsElements[1].textContent = `$${totalSpent.toFixed(0)}`;
        if (statsElements[2]) statsElements[2].textContent = upcomingCount;
    }
}

/**
 * Format date
 */
function formatDate(date) {
    return date.toLocaleDateString('en-US', { year: 'numeric', month: 'short', day: 'numeric' });
}

/**
 * Format time
 */
function formatTime(date) {
    return date.toLocaleTimeString('en-US', { hour: '2-digit', minute: '2-digit', hour12: true });
}

/**
 * View booking details
 */
async function viewBookingDetails(bookingRef) {
    try {
        // Get full booking details from API
        const response = await BookingsAPI.get(0, bookingRef);
        if (!response || !response.id) {
            // Fallback to list if get doesn't work
            const listResponse = await BookingsAPI.list('', 100, 0);
            const booking = listResponse.bookings.find(b => b.booking_reference === bookingRef);
            if (booking) {
                showBookingDetailsModal(booking);
            } else {
                if (typeof showToast !== 'undefined') {
                    showToast('Booking not found', 'error');
                }
            }
            return;
        }
        
        showBookingDetailsModal(response);
    } catch (error) {
        console.error('Error loading booking details:', error);
        if (typeof showToast !== 'undefined') {
            showToast('Failed to load booking details', 'error');
        }
    }
}

/**
 * Show booking details modal
 */
function showBookingDetailsModal(booking) {
    const modal = document.getElementById('bookingDetailsModal');
    const content = document.getElementById('bookingDetailsContent');
    
    const departureTime = new Date(booking.departure_time);
    const arrivalTime = new Date(booking.arrival_time);
    const bookingDate = new Date(booking.booking_date);
    
    const statusClass = `status-${booking.status}`;
    const statusText = booking.status.toUpperCase();
    const paymentStatusText = (booking.payment_status || 'pending').toUpperCase();
    
    // Format duration
    const durationHours = Math.floor((booking.duration_minutes || 0) / 60);
    const durationMins = (booking.duration_minutes || 0) % 60;
    const durationText = durationHours > 0 ? `${durationHours}h ${durationMins}m` : `${durationMins}m`;
    
    content.innerHTML = `
        <div style="margin-bottom: 2rem;">
            <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 1.5rem; padding-bottom: 1rem; border-bottom: 2px solid #e5e7eb;">
                <div>
                    <h2 style="margin: 0; color: var(--primary);">${booking.departure_city} → ${booking.arrival_city}</h2>
                    <p style="margin: 5px 0 0 0; color: var(--gray);">Booking #${booking.booking_reference}</p>
                </div>
                <div style="text-align: right;">
                    <span class="booking-status ${statusClass}" style="display: block; margin-bottom: 5px;">${statusText}</span>
                    <span class="booking-status ${booking.payment_status === 'paid' ? 'status-confirmed' : 'status-pending'}" style="font-size: 0.75rem;">
                        ${paymentStatusText}
                    </span>
                </div>
            </div>
            
            <div style="display: grid; grid-template-columns: repeat(auto-fit, minmax(250px, 1fr)); gap: 1.5rem; margin-bottom: 1.5rem;">
                <div style="background: #f8f9fa; padding: 1rem; border-radius: 8px;">
                    <p style="margin: 0 0 0.5rem 0; color: var(--gray); font-size: 0.9rem;">
                        <i class="fas fa-plane-departure" style="color: var(--primary);"></i> Flight Number
                    </p>
                    <p style="margin: 0; font-weight: 600; font-size: 1.1rem;">${booking.flight_number}</p>
                    <p style="margin: 5px 0 0 0; color: var(--gray); font-size: 0.9rem;">${booking.airline_name}</p>
                </div>
                
                <div style="background: #f8f9fa; padding: 1rem; border-radius: 8px;">
                    <p style="margin: 0 0 0.5rem 0; color: var(--gray); font-size: 0.9rem;">
                        <i class="fas fa-calendar-alt" style="color: var(--primary);"></i> Departure
                    </p>
                    <p style="margin: 0; font-weight: 600; font-size: 1.1rem;">${formatDate(departureTime)}</p>
                    <p style="margin: 5px 0 0 0; color: var(--gray); font-size: 0.9rem;">${formatTime(departureTime)}</p>
                    <p style="margin: 5px 0 0 0; color: var(--gray); font-size: 0.85rem;">${booking.departure_city} (${booking.departure_code})</p>
                </div>
                
                <div style="background: #f8f9fa; padding: 1rem; border-radius: 8px;">
                    <p style="margin: 0 0 0.5rem 0; color: var(--gray); font-size: 0.9rem;">
                        <i class="fas fa-calendar-check" style="color: var(--primary);"></i> Arrival
                    </p>
                    <p style="margin: 0; font-weight: 600; font-size: 1.1rem;">${formatDate(arrivalTime)}</p>
                    <p style="margin: 5px 0 0 0; color: var(--gray); font-size: 0.9rem;">${formatTime(arrivalTime)}</p>
                    <p style="margin: 5px 0 0 0; color: var(--gray); font-size: 0.85rem;">${booking.arrival_city} (${booking.arrival_code})</p>
                </div>
            </div>
            
            <div style="background: #f8f9fa; padding: 1rem; border-radius: 8px; margin-bottom: 1.5rem;">
                <p style="margin: 0 0 0.5rem 0; color: var(--gray); font-size: 0.9rem;">
                    <i class="fas fa-clock" style="color: var(--primary);"></i> Duration
                </p>
                <p style="margin: 0; font-weight: 600;">${durationText}</p>
                ${booking.stops > 0 ? `<p style="margin: 5px 0 0 0; color: var(--gray); font-size: 0.9rem;">${booking.stops} stop${booking.stops > 1 ? 's' : ''}${booking.stop_city ? ` via ${booking.stop_city}` : ''}</p>` : '<p style="margin: 5px 0 0 0; color: var(--gray); font-size: 0.9rem;">Direct flight</p>'}
            </div>
            
            <div style="display: grid; grid-template-columns: repeat(auto-fit, minmax(200px, 1fr)); gap: 1rem; margin-bottom: 1.5rem;">
                <div style="background: #f8f9fa; padding: 1rem; border-radius: 8px;">
                    <p style="margin: 0 0 0.5rem 0; color: var(--gray); font-size: 0.9rem;">
                        <i class="fas fa-users" style="color: var(--primary);"></i> Passengers
                    </p>
                    <p style="margin: 0; font-weight: 600;">${booking.passengers_count}</p>
                </div>
                
                <div style="background: #f8f9fa; padding: 1rem; border-radius: 8px;">
                    <p style="margin: 0 0 0.5rem 0; color: var(--gray); font-size: 0.9rem;">
                        <i class="fas fa-couch" style="color: var(--primary);"></i> Class
                    </p>
                    <p style="margin: 0; font-weight: 600;">${booking.class_type.charAt(0).toUpperCase() + booking.class_type.slice(1)}</p>
                </div>
                
                <div style="background: #f8f9fa; padding: 1rem; border-radius: 8px;">
                    <p style="margin: 0 0 0.5rem 0; color: var(--gray); font-size: 0.9rem;">
                        <i class="fas fa-dollar-sign" style="color: var(--primary);"></i> Total Price
                    </p>
                    <p style="margin: 0; font-weight: 600; color: var(--primary); font-size: 1.2rem;">$${parseFloat(booking.total_price).toFixed(2)}</p>
                </div>
            </div>
            
            ${booking.passengers && booking.passengers.length > 0 ? `
            <div style="margin-bottom: 1.5rem;">
                <h4 style="margin-bottom: 1rem; color: var(--primary);">
                    <i class="fas fa-user-friends"></i> Passenger Details
                </h4>
                <div style="background: #f8f9fa; padding: 1rem; border-radius: 8px;">
                    ${booking.passengers.map((passenger, index) => `
                        <div style="padding: 0.75rem; background: white; border-radius: 6px; margin-bottom: 0.5rem;">
                            <p style="margin: 0; font-weight: 600;">${index + 1}. ${passenger.first_name} ${passenger.last_name}</p>
                            ${passenger.date_of_birth ? `<p style="margin: 5px 0 0 0; color: var(--gray); font-size: 0.9rem;">DOB: ${new Date(passenger.date_of_birth).toLocaleDateString()}</p>` : ''}
                            ${passenger.passport_number ? `<p style="margin: 5px 0 0 0; color: var(--gray); font-size: 0.9rem;">Passport: ${passenger.passport_number}</p>` : ''}
                            ${passenger.seat_number ? `<p style="margin: 5px 0 0 0; color: var(--gray); font-size: 0.9rem;">Seat: ${passenger.seat_number}</p>` : ''}
                        </div>
                    `).join('')}
                </div>
            </div>
            ` : ''}
            
            <div style="background: #f8f9fa; padding: 1rem; border-radius: 8px; margin-bottom: 1.5rem;">
                <p style="margin: 0 0 0.5rem 0; color: var(--gray); font-size: 0.9rem;">
                    <i class="fas fa-calendar" style="color: var(--primary);"></i> Booking Date
                </p>
                <p style="margin: 0; font-weight: 600;">${formatDate(bookingDate)} at ${formatTime(bookingDate)}</p>
            </div>
            
            ${booking.payment_method ? `
            <div style="background: #f8f9fa; padding: 1rem; border-radius: 8px; margin-bottom: 1.5rem;">
                <p style="margin: 0 0 0.5rem 0; color: var(--gray); font-size: 0.9rem;">
                    <i class="fas fa-credit-card" style="color: var(--primary);"></i> Payment Method
                </p>
                <p style="margin: 0; font-weight: 600;">${booking.payment_method.charAt(0).toUpperCase() + booking.payment_method.slice(1)}</p>
            </div>
            ` : ''}
            
            <div style="display: flex; gap: 1rem; margin-top: 2rem;">
                <button class="btn btn-primary" onclick="downloadTicket('${booking.booking_reference}'); closeBookingDetailsModal();" style="flex: 1;">
                    <i class="fas fa-download"></i> Download Ticket (PDF)
                </button>
                <button class="btn btn-outline" onclick="closeBookingDetailsModal()" style="flex: 1;">
                    <i class="fas fa-times"></i> Close
                </button>
            </div>
        </div>
    `;
    
    modal.classList.add('active');
}

/**
 * Close booking details modal
 */
function closeBookingDetailsModal() {
    const modal = document.getElementById('bookingDetailsModal');
    modal.classList.remove('active');
}

/**
 * Cancel booking
 */
async function cancelBooking(bookingId, classType) {
    if (!confirm('Are you sure you want to cancel this booking? This action cannot be undone.')) {
        return;
    }
    
    try {
        await BookingsAPI.cancel(bookingId, classType);
        if (typeof showToast !== 'undefined') {
            showToast('Booking cancelled successfully', 'success');
        }
        // Reload current tab
        const activeTab = document.querySelector('.booking-tab.active');
        const tabName = activeTab ? activeTab.getAttribute('data-tab') : 'upcoming';
        await loadBookings(tabName);
    } catch (error) {
        if (typeof showToast !== 'undefined') {
            showToast(error.message || 'Failed to cancel booking', 'error');
        }
    }
}

/**
 * Download ticket as PDF
 */
async function downloadTicket(bookingRef) {
    try {
        // Get full booking details
        let booking;
        try {
            const response = await BookingsAPI.get(0, bookingRef);
            if (response && response.id) {
                booking = response;
            } else {
                throw new Error('Booking not found');
            }
        } catch (error) {
            // Fallback to list
            const listResponse = await BookingsAPI.list('', 100, 0);
            booking = listResponse.bookings.find(b => b.booking_reference === bookingRef);
            if (!booking) {
                throw new Error('Booking not found');
            }
        }
        
        // Generate PDF using jsPDF
        const { jsPDF } = window.jspdf;
        const doc = new jsPDF({
            orientation: 'portrait',
            unit: 'mm',
            format: 'a4'
        });
        
        const pageWidth = doc.internal.pageSize.getWidth();
        const pageHeight = doc.internal.pageSize.getHeight();
        const margin = 15;
        let yPos = margin;
        
        // Colors
        const primaryColor = [37, 99, 235]; // #2563eb
        const secondaryColor = [16, 185, 129]; // #10b981
        const darkColor = [31, 41, 55]; // #1f2937
        const grayColor = [107, 114, 128]; // #6b7280
        
        // Header with gradient effect (simulated)
        doc.setFillColor(...primaryColor);
        doc.rect(0, 0, pageWidth, 50, 'F');
        
        // Logo/Title
        doc.setTextColor(255, 255, 255);
        doc.setFontSize(24);
        doc.setFont('helvetica', 'bold');
        doc.text('SkySafer', margin, 20);
        
        doc.setFontSize(12);
        doc.setFont('helvetica', 'normal');
        doc.text('Flight Booking Ticket', margin, 30);
        
        // Ticket Number
        doc.setFontSize(10);
        doc.text(`Ticket #${booking.booking_reference}`, pageWidth - margin, 20, { align: 'right' });
        
        yPos = 60;
        
        // Flight Information Box
        doc.setFillColor(245, 247, 250);
        doc.rect(margin, yPos, pageWidth - (margin * 2), 40, 'F');
        
        doc.setTextColor(...darkColor);
        doc.setFontSize(16);
        doc.setFont('helvetica', 'bold');
        doc.text(`${booking.departure_city} → ${booking.arrival_city}`, margin + 5, yPos + 10);
        
        doc.setFontSize(10);
        doc.setFont('helvetica', 'normal');
        doc.setTextColor(...grayColor);
        doc.text(`Flight: ${booking.flight_number} | ${booking.airline_name}`, margin + 5, yPos + 18);
        
        const departureTime = new Date(booking.departure_time);
        const arrivalTime = new Date(booking.arrival_time);
        const durationHours = Math.floor((booking.duration_minutes || 0) / 60);
        const durationMins = (booking.duration_minutes || 0) % 60;
        
        doc.text(
            `Departure: ${formatDateForPDF(departureTime)} ${formatTimeForPDF(departureTime)} | ` +
            `Arrival: ${formatDateForPDF(arrivalTime)} ${formatTimeForPDF(arrivalTime)}`,
            margin + 5,
            yPos + 25
        );
        
        doc.text(
            `Duration: ${durationHours}h ${durationMins}m | ` +
            `Class: ${booking.class_type.charAt(0).toUpperCase() + booking.class_type.slice(1)}`,
            margin + 5,
            yPos + 32
        );
        
        yPos += 50;
        
        // Passenger Information
        doc.setFontSize(14);
        doc.setFont('helvetica', 'bold');
        doc.setTextColor(...darkColor);
        doc.text('Passenger Information', margin, yPos);
        
        yPos += 10;
        
        if (booking.passengers && booking.passengers.length > 0) {
            booking.passengers.forEach((passenger, index) => {
                doc.setFontSize(10);
                doc.setFont('helvetica', 'bold');
                doc.setTextColor(...darkColor);
                doc.text(`${index + 1}. ${passenger.first_name} ${passenger.last_name}`, margin, yPos);
                
                yPos += 6;
                doc.setFont('helvetica', 'normal');
                doc.setTextColor(...grayColor);
                
                let passengerInfo = [];
                if (passenger.date_of_birth) {
                    passengerInfo.push(`DOB: ${new Date(passenger.date_of_birth).toLocaleDateString()}`);
                }
                if (passenger.passport_number) {
                    passengerInfo.push(`Passport: ${passenger.passport_number}`);
                }
                if (passenger.seat_number) {
                    passengerInfo.push(`Seat: ${passenger.seat_number}`);
                }
                
                if (passengerInfo.length > 0) {
                    doc.text(passengerInfo.join(' | '), margin, yPos);
                    yPos += 6;
                }
                
                yPos += 4; // Space between passengers
            });
        } else {
            doc.setFontSize(10);
            doc.setFont('helvetica', 'normal');
            doc.setTextColor(...grayColor);
            doc.text(`${booking.passengers_count} Passenger(s)`, margin, yPos);
            yPos += 10;
        }
        
        yPos += 10;
        
        // Booking Details
        doc.setFontSize(14);
        doc.setFont('helvetica', 'bold');
        doc.setTextColor(...darkColor);
        doc.text('Booking Details', margin, yPos);
        
        yPos += 10;
        
        doc.setFontSize(10);
        doc.setFont('helvetica', 'normal');
        doc.setTextColor(...grayColor);
        
        const bookingDate = new Date(booking.booking_date);
        doc.text(`Booking Date: ${formatDateForPDF(bookingDate)} at ${formatTimeForPDF(bookingDate)}`, margin, yPos);
        yPos += 6;
        
        doc.text(`Booking Status: ${booking.status.toUpperCase()}`, margin, yPos);
        yPos += 6;
        
        doc.text(`Payment Status: ${(booking.payment_status || 'pending').toUpperCase()}`, margin, yPos);
        yPos += 6;
        
        if (booking.payment_method) {
            doc.text(`Payment Method: ${booking.payment_method.charAt(0).toUpperCase() + booking.payment_method.slice(1)}`, margin, yPos);
            yPos += 6;
        }
        
        yPos += 10;
        
        // Price Box
        doc.setFillColor(245, 247, 250);
        doc.rect(margin, yPos, pageWidth - (margin * 2), 20, 'F');
        
        doc.setFontSize(12);
        doc.setFont('helvetica', 'bold');
        doc.setTextColor(...darkColor);
        doc.text('Total Amount Paid', margin + 5, yPos + 10);
        
        doc.setFontSize(18);
        doc.setTextColor(...primaryColor);
        doc.text(`$${parseFloat(booking.total_price).toFixed(2)}`, pageWidth - margin - 5, yPos + 10, { align: 'right' });
        
        yPos += 30;
        
        // Footer
        if (yPos > pageHeight - 30) {
            doc.addPage();
            yPos = margin;
        }
        
        doc.setFontSize(8);
        doc.setFont('helvetica', 'normal');
        doc.setTextColor(...grayColor);
        doc.text(
            'This is an electronic ticket. Please present a valid ID at the airport.',
            pageWidth / 2,
            pageHeight - 15,
            { align: 'center' }
        );
        
        doc.text(
            'For support, contact: support@skysafer.com | www.skysafer.com',
            pageWidth / 2,
            pageHeight - 10,
            { align: 'center' }
        );
        
        // Save PDF
        const fileName = `SkySafer_Ticket_${booking.booking_reference}.pdf`;
        doc.save(fileName);
        
        if (typeof showToast !== 'undefined') {
            showToast('Ticket downloaded successfully!', 'success');
        }
        
    } catch (error) {
        console.error('Error generating PDF:', error);
        if (typeof showToast !== 'undefined') {
            showToast('Failed to download ticket. Please try again.', 'error');
        }
    }
}

/**
 * Format date for PDF
 */
function formatDateForPDF(date) {
    return date.toLocaleDateString('en-US', { year: 'numeric', month: 'short', day: 'numeric' });
}

/**
 * Format time for PDF
 */
function formatTimeForPDF(date) {
    return date.toLocaleTimeString('en-US', { hour: '2-digit', minute: '2-digit', hour12: true });
}

/**
 * Make payment - opens payment modal
 */
async function makePayment(bookingRef) {
    try {
        // Get booking details
        const response = await BookingsAPI.get(0, bookingRef);
        if (!response || !response.id) {
            if (typeof showToast !== 'undefined') {
                showToast('Booking not found', 'error');
            }
            return;
        }

        const booking = response;
        
        // Check if already paid
        if (booking.payment_status === 'paid') {
            if (typeof showToast !== 'undefined') {
                showToast('This booking is already paid', 'info');
            }
            return;
        }

        // Store booking data for payment
        window.currentPaymentBooking = booking;
        
        // Show payment modal
        showPaymentModal(booking);
    } catch (error) {
        console.error('Error loading booking:', error);
        if (typeof showToast !== 'undefined') {
            showToast('Failed to load booking details', 'error');
        }
    }
}

/**
 * Show payment modal
 */
function showPaymentModal(booking) {
    const modal = document.getElementById('paymentModal');
    const summary = document.getElementById('paymentSummary');
    
    // Populate summary
    const departureTime = new Date(booking.departure_time);
    const arrivalTime = new Date(booking.arrival_time);
    
    summary.innerHTML = `
        <h4 style="margin-top: 0; margin-bottom: 1rem;">Booking Summary</h4>
        <div class="payment-summary-item">
            <span>Flight:</span>
            <span>${booking.flight_number} - ${booking.airline_name}</span>
        </div>
        <div class="payment-summary-item">
            <span>Route:</span>
            <span>${booking.departure_city} → ${booking.arrival_city}</span>
        </div>
        <div class="payment-summary-item">
            <span>Date:</span>
            <span>${formatDate(departureTime)}</span>
        </div>
        <div class="payment-summary-item">
            <span>Passengers:</span>
            <span>${booking.passengers_count}</span>
        </div>
        <div class="payment-summary-item">
            <span>Class:</span>
            <span>${booking.class_type.charAt(0).toUpperCase() + booking.class_type.slice(1)}</span>
        </div>
        <div class="payment-summary-item">
            <span>Total Amount:</span>
            <span style="color: var(--primary); font-size: 1.2rem;">$${parseFloat(booking.total_price).toFixed(2)}</span>
        </div>
    `;
    
    // Reset form
    document.getElementById('cardNumber').value = '';
    document.getElementById('cardExpiry').value = '';
    document.getElementById('cardCVV').value = '';
    document.getElementById('cardName').value = '';
    
    // Show modal
    modal.classList.add('active');
    
    // Format card number input
    const cardNumberInput = document.getElementById('cardNumber');
    cardNumberInput.addEventListener('input', function(e) {
        let value = e.target.value.replace(/\s/g, '');
        let formattedValue = value.match(/.{1,4}/g)?.join(' ') || value;
        e.target.value = formattedValue;
    });
    
    // Format expiry input
    const expiryInput = document.getElementById('cardExpiry');
    expiryInput.addEventListener('input', function(e) {
        let value = e.target.value.replace(/\D/g, '');
        if (value.length >= 2) {
            value = value.substring(0, 2) + '/' + value.substring(2, 4);
        }
        e.target.value = value;
    });
}

/**
 * Close payment modal
 */
function closePaymentModal() {
    const modal = document.getElementById('paymentModal');
    modal.classList.remove('active');
    window.currentPaymentBooking = null;
}

/**
 * Select payment method
 */
function selectPaymentMethod(method) {
    document.querySelectorAll('.payment-method-option').forEach(option => {
        option.classList.remove('selected');
    });
    document.querySelector(`[data-method="${method}"]`).classList.add('selected');
    
    // Show/hide card form based on method
    const cardForm = document.getElementById('cardPaymentForm');
    if (method === 'card') {
        cardForm.style.display = 'block';
    } else {
        cardForm.style.display = 'none';
    }
}

/**
 * Process payment
 */
async function processPayment() {
    const booking = window.currentPaymentBooking;
    if (!booking) {
        if (typeof showToast !== 'undefined') {
            showToast('No booking selected', 'error');
        }
        return;
    }

    const selectedMethod = document.querySelector('.payment-method-option.selected');
    const paymentMethod = selectedMethod ? selectedMethod.getAttribute('data-method') : 'card';
    
    // Validate card details if card payment
    if (paymentMethod === 'card') {
        const cardNumber = document.getElementById('cardNumber').value.replace(/\s/g, '');
        const cardExpiry = document.getElementById('cardExpiry').value;
        const cardCVV = document.getElementById('cardCVV').value;
        const cardName = document.getElementById('cardName').value;
        
        if (!cardNumber || cardNumber.length < 13) {
            if (typeof showToast !== 'undefined') {
                showToast('Please enter a valid card number', 'error');
            }
            return;
        }
        
        if (!cardExpiry || !/^\d{2}\/\d{2}$/.test(cardExpiry)) {
            if (typeof showToast !== 'undefined') {
                showToast('Please enter a valid expiry date (MM/YY)', 'error');
            }
            return;
        }
        
        if (!cardCVV || cardCVV.length < 3) {
            if (typeof showToast !== 'undefined') {
                showToast('Please enter a valid CVV', 'error');
            }
            return;
        }
        
        if (!cardName) {
            if (typeof showToast !== 'undefined') {
                showToast('Please enter cardholder name', 'error');
            }
            return;
        }
    }

    // Disable submit button and show loading
    const submitBtn = document.getElementById('paymentSubmitBtn');
    const loading = document.getElementById('paymentLoading');
    submitBtn.disabled = true;
    loading.classList.add('active');

    try {
        // Process payment
        const response = await BookingsAPI.pay(booking.id, booking.booking_reference, paymentMethod);
        
        if (response.success) {
            if (typeof showToast !== 'undefined') {
                showToast('Payment processed successfully! Booking confirmed.', 'success');
            }
            
            // Close modal
            closePaymentModal();
            
            // Reload bookings
            const activeTab = document.querySelector('.booking-tab.active');
            const tabName = activeTab ? activeTab.getAttribute('data-tab') : 'all';
            await loadBookings(tabName);
        } else {
            throw new Error(response.error || 'Payment failed');
        }
    } catch (error) {
        console.error('Payment error:', error);
        if (typeof showToast !== 'undefined') {
            showToast(error.message || 'Failed to process payment. Please try again.', 'error');
        }
        submitBtn.disabled = false;
        loading.classList.remove('active');
    }
}

// Make functions available globally
window.viewBookingDetails = viewBookingDetails;
window.cancelBooking = cancelBooking;
window.downloadTicket = downloadTicket;
window.makePayment = makePayment;
window.closePaymentModal = closePaymentModal;
window.closeBookingDetailsModal = closeBookingDetailsModal;
window.selectPaymentMethod = selectPaymentMethod;
window.processPayment = processPayment;
