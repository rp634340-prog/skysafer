/**
 * Flights Page JavaScript
 * Handles flight search and display
 */

const FlightSearchState = {
    baseParams: null,
    activeParams: null,
    latestDepartureFlights: [],
    latestReturnFlights: [],
    outboundSelection: null,
};

document.addEventListener('DOMContentLoaded', async function() {
    // Load API helper
    if (typeof FlightsAPI === 'undefined') {
        const script = document.createElement('script');
        script.src = 'js/api.js';
        document.head.appendChild(script);
        await new Promise(resolve => script.onload = resolve);
    }

    // Load activity tracker
    if (typeof ActivityTracker === 'undefined') {
        const trackerScript = document.createElement('script');
        trackerScript.src = 'js/activity-tracker.js';
        document.head.appendChild(trackerScript);
        await new Promise(resolve => trackerScript.onload = resolve);
    }

    if (typeof ActivityTracker !== 'undefined') {
        ActivityTracker.init();
        ActivityTracker.trackPageVisit('flights');
    }

    await loadRecommendations();
    bindAdvancedFilterEvents();
    
    if (typeof FlightDates !== 'undefined') {
        FlightDates.initForm({
            tripTypeSelectId: 'tripType',
            departureInputId: 'departure_date',
            returnGroupId: 'returnDateGroup',
            returnInputId: 'return_date',
            errorBoxId: 'flightDateError',
        });
    }

    // Get search parameters from URL
    const urlParams = new URLSearchParams(window.location.search);
    let from = urlParams.get('from');
    let to = urlParams.get('to');
    const departDate = urlParams.get('departDate') || urlParams.get('departure_date');
    const returnDate = urlParams.get('returnDate') || urlParams.get('return_date');
    const tripType = urlParams.get('tripType') || (returnDate ? 'round_trip' : 'one_way');
    const passengers = urlParams.get('passengers') || 1;
    const classType = urlParams.get('class') || 'economy';

    const tripTypeSelect = document.getElementById('tripType');
    if (tripTypeSelect && tripType) {
        tripTypeSelect.value = FlightDates && FlightDates.isRoundTrip(tripType) ? 'round_trip' : 'one_way';
        tripTypeSelect.dispatchEvent(new Event('change'));
    }
    
    // Populate search form
    const fromInput = document.getElementById('searchFrom');
    const toInput = document.getElementById('searchTo');
    
    if (from && fromInput) {
        // If it's just a code, try to find the full name
        if (from.length === 3 && from.match(/^[A-Z]{3}$/)) {
            // Will be populated by airports.js if available
            fromInput.value = from;
        } else {
            fromInput.value = from;
        }
    }
    
    if (to && toInput) {
        // If it's just a code, try to find the full name
        if (to.length === 3 && to.match(/^[A-Z]{3}$/)) {
            // Will be populated by airports.js if available
            toInput.value = to;
        } else {
            toInput.value = to;
        }
    }
    if (departDate) {
        const depEl = document.getElementById('departure_date');
        if (depEl) depEl.value = departDate;
    }
    if (returnDate) {
        const retEl = document.getElementById('return_date');
        if (retEl) retEl.value = returnDate;
    }
    if (passengers) document.getElementById('searchPassengers').value = passengers;
    if (classType) document.getElementById('searchClass').value = classType;
    
    // Search flights if parameters are provided
    if (from && to && departDate) {
        const initialParams = {
            from,
            to,
            departDate,
            returnDate: FlightDates && FlightDates.isRoundTrip(tripType) ? returnDate : '',
            tripType: FlightDates && FlightDates.isRoundTrip(tripType) ? 'round_trip' : 'one_way',
            passengers,
            class: classType,
        };
        FlightSearchState.baseParams = { ...initialParams };
        await performSearch(initialParams);
    }
    
    // Handle search form submission
    const searchForm = document.getElementById('flightSearchForm');
    if (searchForm) {
        searchForm.addEventListener('submit', async (e) => {
            e.preventDefault();
            
            const fromInput = document.getElementById('searchFrom');
            const toInput = document.getElementById('searchTo');
            
            // Extract airport code from input (format: "City (CODE)")
            let from = fromInput.value;
            let to = toInput.value;
            
            // Extract code if in format "City (CODE)"
            const fromMatch = from.match(/\(([A-Z]{3})\)/);
            const toMatch = to.match(/\(([A-Z]{3})\)/);
            
            if (fromMatch) from = fromMatch[1];
            if (toMatch) to = toMatch[1];
            
            const tripTypeVal = document.getElementById('tripType')?.value || 'one_way';
            const departVal = document.getElementById('departure_date')?.value || '';
            const returnVal = document.getElementById('return_date')?.value || '';

            if (typeof FlightDates !== 'undefined' && !FlightDates.validateForm(tripTypeVal, departVal, returnVal, 'flightDateError')) {
                return;
            }

            const searchParams = {
                from: from,
                to: to,
                departDate: departVal,
                returnDate: FlightDates && FlightDates.isRoundTrip(tripTypeVal) ? returnVal : '',
                tripType: tripTypeVal,
                passengers: document.getElementById('searchPassengers').value,
                class: document.getElementById('searchClass').value,
            };
            FlightSearchState.baseParams = { ...searchParams };
            FlightSearchState.outboundSelection = null;
            sessionStorage.removeItem('bookingData');

            if (typeof ActivityTracker !== 'undefined') {
                ActivityTracker.trackSearch({
                    from: searchParams.from,
                    to: searchParams.to,
                    departDate: searchParams.departDate,
                    returnDate: searchParams.returnDate,
                    passengers: searchParams.passengers,
                    classType: searchParams.class,
                    source: 'flights-search'
                });
                ActivityTracker.flush();
            }
            
            await performSearch(searchParams);
        });

        const searchFromInput = document.getElementById('searchFrom');
        const searchToInput = document.getElementById('searchTo');
        const debouncedSearchTrack = () => {
            if (typeof ActivityTracker === 'undefined') return;
            ActivityTracker.trackSearch({
                from: searchFromInput ? searchFromInput.value : '',
                to: searchToInput ? searchToInput.value : '',
                source: 'flights-search-input'
            });
        };

        if (searchFromInput) {
            searchFromInput.addEventListener('input', debouncedSearchTrack);
        }
        if (searchToInput) {
            searchToInput.addEventListener('input', debouncedSearchTrack);
        }
    }
    
    // Passenger counter
    const increaseBtn = document.getElementById('searchIncreasePassengers');
    const decreaseBtn = document.getElementById('searchDecreasePassengers');
    const passengersInput = document.getElementById('searchPassengers');
    
    if (increaseBtn && decreaseBtn && passengersInput) {
        increaseBtn.addEventListener('click', () => {
            let value = parseInt(passengersInput.value);
            if (value < 9) {
                passengersInput.value = value + 1;
            }
        });
        
        decreaseBtn.addEventListener('click', () => {
            let value = parseInt(passengersInput.value);
            if (value > 1) {
                passengersInput.value = value - 1;
            }
        });
    }
});

async function loadRecommendations() {
    const section = document.getElementById('recommendedSection');
    const container = document.getElementById('recommendedFlights');
    const meta = document.getElementById('recommendedMeta');
    if (!section || !container || typeof RecommendationsAPI === 'undefined') {
        return;
    }

    try {
        const auth = await AuthAPI.check();
        if (!auth.authenticated) {
            return;
        }

        const response = await RecommendationsAPI.flights(6);
        const flights = response.recommendedFlights || [];
        if (flights.length === 0) {
            return;
        }

        section.style.display = 'block';
        const preferredClass = response.preferredClassType || 'economy';
        meta.textContent = `Personalized using your recent activity • ${preferredClass} class`;

        container.innerHTML = flights.map((flight) => {
            const depart = new Date(flight.departure_time);
            const arrival = new Date(flight.arrival_time);
            return `
                <article style="border:1px solid var(--border); border-radius:10px; padding:1rem;">
                    <div style="display:flex; justify-content:space-between; gap:0.75rem; align-items:flex-start;">
                        <div>
                            <h3 style="margin:0 0 0.2rem 0; font-size:1rem;">${flight.departure_city} → ${flight.arrival_city}</h3>
                            <p style="margin:0; font-size:0.9rem; color:var(--gray);">${flight.airline_name} • ${flight.flight_number}</p>
                        </div>
                        <strong style="color:var(--primary);">$${parseFloat(flight.price || 0).toFixed(0)}</strong>
                    </div>
                    <p style="margin:0.7rem 0 0.3rem; font-size:0.88rem;">
                        <i class="fas fa-clock"></i> ${formatTime(depart)} - ${formatTime(arrival)} • ${formatDuration(flight.duration_minutes)}
                    </p>
                    <p style="margin:0; font-size:0.82rem; color:var(--gray);">${flight.recommendation_reason || 'Matched to your preferences'}</p>
                    <button class="btn btn-primary" style="margin-top:0.85rem; width:100%;"
                        onclick="bookFlight(${flight.id}, '${preferredClass}', 1, ${parseFloat(flight.price || 0).toFixed(2)})">
                        <i class="fas fa-shopping-cart"></i> Book Recommended
                    </button>
                </article>
            `;
        }).join('');
    } catch (error) {
        console.warn('Recommendations unavailable', error);
    }
}

/**
 * Search flights
 */
async function searchFlights(params) {
    const resultsContainer = document.getElementById('flightResults');
    const resultsHeader = document.getElementById('resultsHeader');
    const resultsTitle = document.getElementById('resultsTitle');
    const resultsInfo = document.getElementById('resultsInfo');
    
    if (!resultsContainer) return;
    
    try {
        // Show loading
        resultsContainer.innerHTML = '<div style="text-align: center; padding: 4rem 2rem;"><i class="fas fa-spinner fa-spin" style="font-size: 3rem; color: var(--primary);"></i><p style="margin-top: 1rem;">Searching flights...</p></div>';
        if (resultsHeader) resultsHeader.style.display = 'none';
        
        const response = await FlightsAPI.search(params);
        
        if (response.departureFlights && response.departureFlights.length > 0) {
            // Show results header
            if (resultsHeader) {
                resultsHeader.style.display = 'block';
            if (resultsTitle) {
                // Get city names from API response or use codes
                const fromCity = response.departureFlights[0]?.departure_city || params.from;
                const toCity = response.departureFlights[0]?.arrival_city || params.to;
                resultsTitle.textContent = `Flights from ${fromCity} to ${toCity}`;
            }
                if (resultsInfo) {
                    const departDate = new Date(params.departDate).toLocaleDateString('en-US', { month: 'short', day: 'numeric', year: 'numeric' });
                    const returnText = params.returnDate ? ` - ${new Date(params.returnDate).toLocaleDateString('en-US', { month: 'short', day: 'numeric', year: 'numeric' })}` : '';
                    resultsInfo.textContent = `Showing ${response.departureFlights.length} flights for ${departDate}${returnText} • ${params.passengers} Passenger${params.passengers > 1 ? 's' : ''} • ${params.class.charAt(0).toUpperCase() + params.class.slice(1)}`;
                }
            }
            
            displayFlights(response.departureFlights, resultsContainer, params, 'outbound');
            FlightSearchState.activeParams = { ...params };
            FlightSearchState.latestDepartureFlights = response.departureFlights || [];
            FlightSearchState.latestReturnFlights = response.returnFlights || [];
            populateAirlineFilters(response.departureFlights || []);

            const isRound = typeof FlightDates !== 'undefined'
                ? FlightDates.isRoundTrip(params.tripType || '')
                : Boolean(params.returnDate);
            if (isRound && response.returnFlights && response.returnFlights.length > 0) {
                displayReturnFlights(response.returnFlights, params);
            } else {
                hideReturnFlightsSection();
            }
        } else {
            hideReturnFlightsSection();
            if (resultsHeader) resultsHeader.style.display = 'none';
            resultsContainer.innerHTML = `
                <div style="text-align: center; padding: 4rem 2rem; background: white; border-radius: 10px; box-shadow: var(--shadow);">
                    <i class="fas fa-search" style="font-size: 4rem; color: var(--gray); margin-bottom: 1.5rem;"></i>
                    <h3>No flights found</h3>
                    <p style="color: var(--gray);">No flights match your search criteria. Please try different dates or destinations.</p>
                </div>
            `;
        }
    } catch (error) {
        console.error('Flight search error:', error);
        if (resultsHeader) resultsHeader.style.display = 'none';
        if (resultsContainer) {
            resultsContainer.innerHTML = `
                <div style="text-align: center; padding: 4rem 2rem; background: white; border-radius: 10px; box-shadow: var(--shadow);">
                    <i class="fas fa-exclamation-triangle" style="font-size: 4rem; color: #f44336; margin-bottom: 1.5rem;"></i>
                    <h3>Error searching flights</h3>
                    <p style="color: var(--gray);">${error.message || 'Please try again later'}</p>
                </div>
            `;
        }
        if (typeof showToast !== 'undefined') {
            showToast('Failed to search flights. Please try again.', 'error');
        }
    }
}

async function performSearch(baseParams) {
    const merged = {
        ...baseParams,
        ...collectAdvancedFilters(),
        sortBy: mapSortToApi(document.getElementById('sortSelect')?.value || 'price-asc')
    };
    await searchFlights(merged);
}

/**
 * Display flights
 */
function hideReturnFlightsSection() {
    const section = document.getElementById('returnFlightsSection');
    if (section) section.style.display = 'none';
}

function displayReturnFlights(flights, params) {
    const section = document.getElementById('returnFlightsSection');
    const container = document.getElementById('returnFlightResults');
    const hint = document.getElementById('returnFlightsHint');
    if (!section || !container) return;

    section.style.display = 'block';
    if (hint) {
        hint.textContent = FlightSearchState.outboundSelection
            ? 'Now select your return flight to continue booking.'
            : 'Select an outbound flight first, then choose your return flight below.';
    }

    if (FlightSearchState.outboundSelection) {
        section.classList.add('selecting-return');
    } else {
        section.classList.remove('selecting-return');
    }

    displayFlights(flights, container, params, 'return');
}

function displayFlights(flights, container, params, leg = 'outbound') {
    // Sort flights if needed
    let sortedFlights = [...flights];
    const sortSelect = document.getElementById('sortSelect');
    if (sortSelect) {
        const sortValue = sortSelect.value;
        if (sortValue === 'price-asc') {
            sortedFlights.sort((a, b) => parseFloat(a.price) - parseFloat(b.price));
        } else if (sortValue === 'price-desc') {
            sortedFlights.sort((a, b) => parseFloat(b.price) - parseFloat(a.price));
        } else if (sortValue === 'time-asc') {
            sortedFlights.sort((a, b) => new Date(a.departure_time) - new Date(b.departure_time));
        } else if (sortValue === 'time-desc') {
            sortedFlights.sort((a, b) => new Date(b.departure_time) - new Date(a.departure_time));
        } else if (sortValue === 'duration-asc') {
            sortedFlights.sort((a, b) => a.duration_minutes - b.duration_minutes);
        } else if (sortValue === 'duration-desc') {
            sortedFlights.sort((a, b) => b.duration_minutes - a.duration_minutes);
        }
    }
    
    container.innerHTML = '';
    
    sortedFlights.forEach(flight => {
        const flightCard = createFlightCard(flight, params, leg);
        container.appendChild(flightCard);
    });
    
    // Add sort event listener
    if (sortSelect) {
        sortSelect.onchange = () => {
            if (FlightSearchState.baseParams) {
                performSearch(FlightSearchState.baseParams);
            } else {
                displayFlights(flights, container, params);
            }
        };
    }
}

function populateAirlineFilters(flights) {
    const wrap = document.getElementById('airlineFilters');
    if (!wrap) return;

    const existing = new Set(Array.from(wrap.querySelectorAll('input[type="checkbox"]:checked')).map((el) => el.value));
    const airlineMap = new Map();
    flights.forEach((f) => {
        if (!f.airline_code) return;
        airlineMap.set(f.airline_code, f.airline_name || f.airline_code);
    });

    if (airlineMap.size === 0) {
        wrap.innerHTML = '<p style="color: var(--gray); margin: 0;">No airline filters yet</p>';
        return;
    }

    wrap.innerHTML = Array.from(airlineMap.entries()).map(([code, name]) => `
        <label class="filter-option">
            <input type="checkbox" value="${code}" ${existing.has(code) ? 'checked' : ''}> ${name}
        </label>
    `).join('');

    wrap.querySelectorAll('input[type="checkbox"]').forEach((el) => {
        el.addEventListener('change', () => {
            if (FlightSearchState.baseParams) {
                performSearch(FlightSearchState.baseParams);
            }
        });
    });
}

function collectAdvancedFilters() {
    const keyword = (document.getElementById('keywordInput')?.value || '').trim();
    const maxPrice = Number(document.getElementById('priceRange')?.value || 0);
    const stops = document.getElementById('stopsFilter')?.value || 'any';
    const departStartTime = document.getElementById('departStartTime')?.value || '';
    const departEndTime = document.getElementById('departEndTime')?.value || '';
    const airlineCodes = Array.from(document.querySelectorAll('#airlineFilters input[type="checkbox"]:checked')).map((el) => el.value);

    const payload = {
        keyword,
        maxPrice: maxPrice > 0 ? maxPrice : '',
        stops,
        departStartTime,
        departEndTime,
        airlines: airlineCodes.join(',')
    };
    return payload;
}

function bindAdvancedFilterEvents() {
    const applyBtn = document.getElementById('applyAdvancedFiltersBtn');
    const debouncedSearch = debounce(() => {
        if (!FlightSearchState.baseParams) return;
        performSearch(FlightSearchState.baseParams);
    }, 350);

    if (applyBtn) {
        applyBtn.addEventListener('click', () => {
            if (!FlightSearchState.baseParams) return;
            performSearch(FlightSearchState.baseParams);
        });
    }

    const keywordInput = document.getElementById('keywordInput');
    if (keywordInput) {
        keywordInput.addEventListener('input', debouncedSearch);
    }

    const priceRange = document.getElementById('priceRange');
    const selectedPrice = document.getElementById('selectedPrice');
    const maxPrice = document.getElementById('maxPrice');
    if (priceRange) {
        const syncPrice = () => {
            if (selectedPrice) selectedPrice.textContent = priceRange.value;
            if (maxPrice) maxPrice.textContent = `$${priceRange.value}`;
            debouncedSearch();
        };
        priceRange.addEventListener('input', syncPrice);
    }

    ['stopsFilter', 'departStartTime', 'departEndTime'].forEach((id) => {
        const el = document.getElementById(id);
        if (el) {
            el.addEventListener('change', () => {
                if (!FlightSearchState.baseParams) return;
                performSearch(FlightSearchState.baseParams);
            });
        }
    });
}

function mapSortToApi(uiSort) {
    const map = {
        'price-asc': 'price_asc',
        'price-desc': 'price_desc',
        'time-asc': 'departure_time_asc',
        'time-desc': 'departure_time_desc',
        'duration-asc': 'duration_asc',
        'duration-desc': 'duration_desc'
    };
    return map[uiSort] || 'departure_time_asc';
}

function debounce(fn, delay) {
    let timer = null;
    return (...args) => {
        clearTimeout(timer);
        timer = setTimeout(() => fn(...args), delay);
    };
}

/**
 * Create flight card element
 */
function createFlightCard(flight, params, leg = 'outbound') {
    const card = document.createElement('div');
    card.className = 'flight-card fade-in';
    
    const departureTime = new Date(flight.departure_time);
    const arrivalTime = new Date(flight.arrival_time);
    const duration = formatDuration(flight.duration_minutes);
    
    card.innerHTML = `
        <div class="flight-header">
            <div class="airline-info">
                <div style="width: 40px; height: 40px; background: var(--primary); color: white; border-radius: 50%; display: flex; align-items: center; justify-content: center; margin-right: 10px;">
                    <i class="fas fa-plane"></i>
                </div>
                <div>
                    <h4 style="margin: 0;">${flight.airline_name}</h4>
                    <p style="margin: 0; font-size: 0.9rem; color: var(--gray);">Flight ${flight.flight_number}</p>
                </div>
            </div>
            <div class="flight-price">
                <p class="price">$${parseFloat(flight.price).toFixed(0)}</p>
                <p style="margin: 0; color: var(--gray); font-size: 0.9rem;">per person</p>
            </div>
        </div>
        
        <div class="flight-info">
            <div style="text-align: center;">
                <h3 style="margin: 0;">${formatTime(departureTime)}</h3>
                <p style="margin: 0; color: var(--gray);">${flight.departure_code}</p>
            </div>
            
            <div class="flight-route">
                <div class="flight-duration">
                    <i class="fas fa-clock"></i> ${duration}
                </div>
                <div style="display: flex; align-items: center; margin: 10px 0;">
                    <div style="flex: 1; height: 2px; background: var(--border);"></div>
                    <i class="fas fa-plane" style="margin: 0 10px; color: var(--primary);"></i>
                    <div style="flex: 1; height: 2px; background: var(--border);"></div>
                </div>
                <p style="margin: 0; color: var(--gray); font-size: 0.9rem;">${flight.stops === 0 ? 'Direct' : flight.stops + ' Stop' + (flight.stops > 1 ? 's' : '') + (flight.stop_city ? ' (' + flight.stop_city + ')' : '')}</p>
            </div>
            
            <div style="text-align: center;">
                <h3 style="margin: 0;">${formatTime(arrivalTime)}</h3>
                <p style="margin: 0; color: var(--gray);">${flight.arrival_code}</p>
            </div>
        </div>
        
        <div class="flight-details">
            <div>
                <p style="margin: 0; color: var(--gray);">
                    <i class="fas fa-suitcase"></i> ${flight.baggage_allowance_kg}kg Check-in • ${flight.cabin_baggage_kg}kg Cabin
                </p>
            </div>
            <button class="btn btn-primary" onclick="bookFlight(${flight.id}, '${params.class}', ${params.passengers}, ${parseFloat(flight.price).toFixed(2)}, '${leg}')">
                <i class="fas fa-shopping-cart"></i> ${leg === 'return' ? 'Select Return' : 'Book Now'}
            </button>
        </div>
    `;
    
    return card;
}

/**
 * Format time
 */
function formatTime(date) {
    return date.toLocaleTimeString('en-US', { hour: '2-digit', minute: '2-digit', hour12: true });
}

/**
 * Format duration
 */
function formatDuration(minutes) {
    const hours = Math.floor(minutes / 60);
    const mins = minutes % 60;
    return `${hours}h ${mins}m`;
}

/**
 * Book flight (outbound or return leg for round trip).
 */
function bookFlight(flightId, classType, passengers, price, leg = 'outbound') {
    AuthAPI.check().then(response => {
        if (!response.authenticated) {
            if (typeof showToast !== 'undefined') {
                showToast('Please login to book a flight', 'error');
            }
            setTimeout(() => {
                window.location.href = 'login.html';
            }, 1500);
            return;
        }

        const params = FlightSearchState.activeParams || FlightSearchState.baseParams || {};
        const tripType = params.tripType || 'one_way';
        const isRound = typeof FlightDates !== 'undefined'
            ? FlightDates.isRoundTrip(tripType)
            : Boolean(params.returnDate);

        if (leg === 'outbound' && isRound && params.returnDate) {
            FlightSearchState.outboundSelection = {
                flightId,
                classType,
                passengers,
                price: parseFloat(price),
            };
            const payload = {
                flightId,
                classType,
                passengers,
                price: parseFloat(price),
                outboundPrice: parseFloat(price),
                departure_date: params.departDate,
                return_date: params.returnDate,
                trip_type: 'round_trip',
                tripType: 'round_trip',
            };
            sessionStorage.setItem('bookingData', JSON.stringify(payload));

            if (typeof showToast !== 'undefined') {
                showToast('Outbound flight selected. Please choose your return flight.', 'success');
            }

            if (FlightSearchState.latestReturnFlights.length > 0) {
                displayReturnFlights(FlightSearchState.latestReturnFlights, params);
            }
            document.getElementById('returnFlightsSection')?.scrollIntoView({ behavior: 'smooth', block: 'start' });
            return;
        }

        let bookingPayload = {
            flightId,
            classType,
            passengers,
            price: parseFloat(price),
            departure_date: params.departDate || null,
            return_date: isRound ? (params.returnDate || null) : null,
            trip_type: isRound ? 'round_trip' : 'one_way',
            tripType: isRound ? 'round_trip' : 'one_way',
        };

        if (leg === 'return' && FlightSearchState.outboundSelection) {
            const outbound = FlightSearchState.outboundSelection;
            bookingPayload = {
                flightId: outbound.flightId,
                returnFlightId: flightId,
                classType,
                passengers,
                price: parseFloat(outbound.price) + parseFloat(price),
                outboundPrice: parseFloat(outbound.price),
                returnPrice: parseFloat(price),
                departure_date: params.departDate,
                return_date: params.returnDate,
                trip_type: 'round_trip',
                tripType: 'round_trip',
            };
        }

        sessionStorage.setItem('bookingData', JSON.stringify(bookingPayload));
        window.location.href = 'booking.html';
    }).catch(() => {
        window.location.href = 'login.html';
    });
}
