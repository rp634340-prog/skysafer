/**
 * SkySafer AI Help Assistant — floating widget + chat logic
 */
const SkyHelpChat = (function () {
    const STORAGE_SESSION = 'skyHelpSessionId';
    const STORAGE_THEME = 'skyHelpTheme';

    let panelOpen = false;
    let isLoading = false;
    let sessionId = '';
    let elements = {};

    function resolveApiBase() {
        if (typeof resolveApiBaseUrl === 'function') {
            return resolveApiBaseUrl();
        }
        const path = window.location.pathname || '';
        const baseDir = path.replace(/\/[^/]*$/, '');
        const normalized = baseDir.endsWith('/') ? baseDir.slice(0, -1) : baseDir;
        return `${normalized}/api`;
    }

    function getSessionId() {
        let id = sessionStorage.getItem(STORAGE_SESSION);
        if (!id) {
            id = 'sess_' + Date.now().toString(36) + '_' + Math.random().toString(36).slice(2, 12);
            sessionStorage.setItem(STORAGE_SESSION, id);
        }
        return id;
    }

    function getTheme() {
        return localStorage.getItem(STORAGE_THEME) || 'light';
    }

    function setTheme(theme) {
        localStorage.setItem(STORAGE_THEME, theme);
        document.documentElement.setAttribute('data-help-theme', theme === 'dark' ? 'dark' : 'light');
        if (elements.themeBtn) {
            elements.themeBtn.innerHTML = theme === 'dark'
                ? '<i class="fas fa-sun"></i>'
                : '<i class="fas fa-moon"></i>';
        }
    }

    function toggleTheme() {
        setTheme(getTheme() === 'dark' ? 'light' : 'dark');
    }

    function formatTime(date) {
        return date.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
    }

    function scrollToBottom() {
        if (elements.messages) {
            requestAnimationFrame(() => {
                elements.messages.scrollTop = elements.messages.scrollHeight;
            });
        }
    }

    function appendMessage(text, role, timestamp) {
        if (!elements.messages) return;

        const wrap = document.createElement('div');
        wrap.className = `sky-help-msg ${role}`;
        const time = timestamp ? new Date(timestamp) : new Date();
        wrap.innerHTML = `
            <div class="sky-help-bubble">
                ${escapeHtml(text).replace(/\n/g, '<br>')}
                <span class="sky-help-time">${formatTime(time)}</span>
            </div>
        `;
        elements.messages.appendChild(wrap);
        scrollToBottom();
    }

    function escapeHtml(str) {
        const el = document.createElement('div');
        el.textContent = str;
        return el.innerHTML;
    }

    function showTyping() {
        if (!elements.messages || document.getElementById('skyHelpTyping')) return;
        const el = document.createElement('div');
        el.id = 'skyHelpTyping';
        el.className = 'sky-help-msg bot';
        el.innerHTML = `
            <div class="sky-help-typing" aria-label="Assistant is typing">
                <span></span><span></span><span></span>
            </div>
        `;
        elements.messages.appendChild(el);
        scrollToBottom();
    }

    function hideTyping() {
        document.getElementById('skyHelpTyping')?.remove();
    }

    function setLoading(loading) {
        isLoading = loading;
        if (elements.sendBtn) elements.sendBtn.disabled = loading;
        if (elements.input) elements.input.disabled = loading;
    }

    async function fetchJson(url, options = {}) {
        const res = await fetch(url, options);
        const text = await res.text();
        let data;
        try {
            data = text ? JSON.parse(text) : {};
        } catch (e) {
            throw new Error('Invalid response from help server.');
        }
        if (!res.ok && !data.answer) {
            throw new Error(data.message || 'Request failed');
        }
        return data;
    }

    async function loadWelcome() {
        try {
            const data = await fetchJson(`${resolveApiBase()}/help_chat.php?action=welcome`);
            if (data.message) {
                appendMessage(data.message, 'bot');
            }
        } catch (e) {
            appendMessage(
                'Hello! I am the SkySafer Help Assistant. Ask me about bookings, payments, or your account.',
                'bot'
            );
        }
    }

    async function loadHistory() {
        try {
            const data = await fetchJson(
                `${resolveApiBase()}/help_chat.php?action=history&sessionId=${encodeURIComponent(sessionId)}&limit=30`
            );
            if (data.history && data.history.length > 0) {
                data.history.forEach((row) => {
                    appendMessage(row.user_message, 'user', row.created_at);
                    appendMessage(row.bot_answer, 'bot', row.created_at);
                });
                return true;
            }
        } catch (e) {
            console.warn('Help history unavailable', e);
        }
        return false;
    }

    async function sendMessage() {
        const text = (elements.input?.value || '').trim();
        if (!text || isLoading) return;

        appendMessage(text, 'user');
        elements.input.value = '';
        elements.input.style.height = 'auto';

        setLoading(true);
        showTyping();

        try {
            const data = await fetchJson(`${resolveApiBase()}/help_chat.php?action=chat`, {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ message: text, sessionId }),
            });

            hideTyping();

            if (data.sessionId) {
                sessionId = data.sessionId;
                sessionStorage.setItem(STORAGE_SESSION, sessionId);
            }

            appendMessage(
                data.answer || 'Sorry, I could not understand your question.',
                'bot',
                data.timestamp
            );
        } catch (err) {
            hideTyping();
            appendMessage(
                err.message || 'Sorry, I could not reach the help server. Please try again.',
                'bot'
            );
        } finally {
            setLoading(false);
            elements.input?.focus();
        }
    }

    function togglePanel(force) {
        panelOpen = typeof force === 'boolean' ? force : !panelOpen;
        elements.panel?.classList.toggle('is-open', panelOpen);
        elements.launcher?.classList.toggle('is-open', panelOpen);
        if (panelOpen) {
            elements.input?.focus();
            scrollToBottom();
        }
    }

    function buildWidget(rootId) {
        const root = document.getElementById(rootId) || document.body;
        const standalone = rootId === 'helpChatStandalone';

        const wrapper = document.createElement('div');
        wrapper.id = 'skyHelpChatRoot';
        wrapper.innerHTML = `
            ${standalone ? '' : `
            <button type="button" class="sky-help-launcher" id="skyHelpLauncher" aria-label="Open help chat">
                <span class="badge" aria-hidden="true"></span>
                <i class="fas fa-comments"></i>
            </button>`}
            <div class="sky-help-panel ${standalone ? 'help-chat-standalone is-open' : ''}" id="skyHelpPanel" role="dialog" aria-label="Help chat">
                <header class="sky-help-header">
                    <div class="sky-help-header-info">
                        <div class="sky-help-avatar"><i class="fas fa-robot"></i></div>
                        <div>
                            <h3>SkySafer Help</h3>
                            <p>AI Assistant • Online</p>
                        </div>
                    </div>
                    <div class="sky-help-header-actions">
                        <button type="button" class="sky-help-icon-btn" id="skyHelpTheme" title="Toggle theme"><i class="fas fa-moon"></i></button>
                        ${standalone ? '' : '<button type="button" class="sky-help-icon-btn" id="skyHelpClose" title="Close"><i class="fas fa-times"></i></button>'}
                    </div>
                </header>
                <div class="sky-help-messages" id="skyHelpMessages"></div>
                <footer class="sky-help-footer">
                    <textarea class="sky-help-input" id="skyHelpInput" rows="1" placeholder="Ask about booking, payment, refund…" maxlength="2000"></textarea>
                    <button type="button" class="sky-help-send" id="skyHelpSend" aria-label="Send"><i class="fas fa-paper-plane"></i></button>
                </footer>
            </div>
        `;

        root.appendChild(wrapper);

        elements = {
            launcher: document.getElementById('skyHelpLauncher'),
            panel: document.getElementById('skyHelpPanel'),
            messages: document.getElementById('skyHelpMessages'),
            input: document.getElementById('skyHelpInput'),
            sendBtn: document.getElementById('skyHelpSend'),
            themeBtn: document.getElementById('skyHelpTheme'),
            closeBtn: document.getElementById('skyHelpClose'),
        };

        setTheme(getTheme());

        elements.launcher?.addEventListener('click', () => togglePanel());
        elements.closeBtn?.addEventListener('click', () => togglePanel(false));
        elements.themeBtn?.addEventListener('click', toggleTheme);
        elements.sendBtn?.addEventListener('click', sendMessage);

        elements.input?.addEventListener('keydown', (e) => {
            if (e.key === 'Enter' && !e.shiftKey) {
                e.preventDefault();
                sendMessage();
            }
        });

        elements.input?.addEventListener('input', function () {
            this.style.height = 'auto';
            this.style.height = Math.min(this.scrollHeight, 100) + 'px';
        });
    }

    async function init(options = {}) {
        if (window.SKY_HELP_CHAT_INIT) return;
        window.SKY_HELP_CHAT_INIT = true;

        sessionId = getSessionId();
        const rootId = options.rootId || null;
        buildWidget(rootId);

        const hadHistory = await loadHistory();
        if (!hadHistory) {
            await loadWelcome();
        }

        if (options.autoOpen) {
            togglePanel(true);
        }
    }

    return { init, sendMessage, togglePanel };
})();

document.addEventListener('DOMContentLoaded', () => {
    if (window.SKY_HELP_CHAT_DISABLE_AUTO) return;
    const standalone = document.getElementById('helpChatStandalone');
    if (standalone) {
        SkyHelpChat.init({ rootId: 'helpChatStandalone', autoOpen: true });
    } else if (!document.getElementById('skyHelpChatRoot')) {
        SkyHelpChat.init();
    }
});
