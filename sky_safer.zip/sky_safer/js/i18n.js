/**
 * Lightweight i18n bootstrap for static pages.
 */
(function initI18n() {
    const DEFAULT_LANG = 'en';
    const SUPPORTED_LANGS = ['en', 'hi'];
    const STORAGE_KEY = 'app_lang';
    const resources = {};

    function getInitialLang() {
        const saved = localStorage.getItem(STORAGE_KEY);
        if (saved && SUPPORTED_LANGS.includes(saved)) return saved;
        const browserLang = (navigator.language || DEFAULT_LANG).split('-')[0];
        return SUPPORTED_LANGS.includes(browserLang) ? browserLang : DEFAULT_LANG;
    }

    async function loadLanguage(lang) {
        const response = await fetch(`locales/${lang}.json`);
        if (!response.ok) throw new Error(`Failed to load locale: ${lang}`);
        resources[lang] = { translation: await response.json() };
    }

    function applyTranslations() {
        if (!window.i18next) return;
        document.documentElement.lang = window.i18next.language || DEFAULT_LANG;

        document.querySelectorAll('[data-i18n]').forEach((el) => {
            const key = el.getAttribute('data-i18n');
            const translated = window.i18next.t(key);
            if (translated && translated !== key) {
                el.textContent = translated;
            }
        });

        document.querySelectorAll('[data-i18n-placeholder]').forEach((el) => {
            const key = el.getAttribute('data-i18n-placeholder');
            const translated = window.i18next.t(key);
            if (translated && translated !== key) {
                el.setAttribute('placeholder', translated);
            }
        });
    }

    function bindSwitcher() {
        const switcher = document.getElementById('languageSwitcher');
        if (!switcher) return;
        switcher.value = window.i18next.language || DEFAULT_LANG;
        switcher.addEventListener('change', async (event) => {
            const lang = event.target.value;
            await window.i18next.changeLanguage(lang);
            localStorage.setItem(STORAGE_KEY, lang);
            applyTranslations();
        });
    }

    window.I18nApp = {
        t: (key, options) => (window.i18next ? window.i18next.t(key, options) : key),
        apply: applyTranslations
    };

    document.addEventListener('DOMContentLoaded', async () => {
        if (!window.i18next) return;

        const lang = getInitialLang();
        await Promise.all(SUPPORTED_LANGS.map(loadLanguage));

        await window.i18next.init({
            lng: lang,
            fallbackLng: DEFAULT_LANG,
            resources,
            interpolation: { escapeValue: false }
        });

        bindSwitcher();
        applyTranslations();
    });
})();
