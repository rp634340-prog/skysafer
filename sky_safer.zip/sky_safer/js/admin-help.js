/**
 * Admin Help FAQ management
 */
document.addEventListener('DOMContentLoaded', async () => {
    try {
        const auth = await AuthAPI.check();
        if (!auth.authenticated || auth.user?.role !== 'admin') {
            window.location.href = 'login.html?redirect=admin-help.html';
            return;
        }
    } catch (e) {
        window.location.href = 'login.html?redirect=admin-help.html';
        return;
    }

    await loadFaqs();
    document.getElementById('faqForm').addEventListener('submit', onSubmit);
    document.getElementById('cancelEditBtn').addEventListener('click', resetForm);
});

function showMsg(text, ok) {
    const el = document.getElementById('adminMsg');
    el.textContent = text;
    el.className = 'msg ' + (ok ? 'ok' : 'err');
}

async function loadFaqs() {
    const list = document.getElementById('faqList');
    try {
        const data = await HelpAPI.listFaqs();
        const faqs = data.faqs || [];
        if (faqs.length === 0) {
            list.innerHTML = '<p style="color:var(--gray);">No FAQs yet. Add one above.</p>';
            return;
        }
        list.innerHTML = faqs.map((f) => `
            <article class="faq-item" data-id="${f.id}">
                <h4>${escapeHtml(f.question)}</h4>
                <p><strong>Answer:</strong> ${escapeHtml(f.answer).slice(0, 200)}${f.answer.length > 200 ? '…' : ''}</p>
                <p><strong>Keywords:</strong> ${escapeHtml(f.keywords || '—')}</p>
                <p style="font-size:0.8rem;"><i class="fas fa-clock"></i> ${f.updated_at || f.created_at}</p>
                <div class="faq-actions">
                    <button type="button" class="btn btn-primary btn-small" onclick="editFaq(${f.id})"><i class="fas fa-edit"></i> Edit</button>
                    <button type="button" class="btn btn-danger btn-small" onclick="deleteFaq(${f.id})"><i class="fas fa-trash"></i> Delete</button>
                </div>
            </article>
        `).join('');
        window.__faqCache = faqs;
    } catch (err) {
        list.innerHTML = `<p style="color:#b91c1c;">${escapeHtml(err.message)}</p>`;
    }
}

function escapeHtml(s) {
    const d = document.createElement('div');
    d.textContent = s || '';
    return d.innerHTML;
}

window.editFaq = function (id) {
    const faq = (window.__faqCache || []).find((f) => Number(f.id) === Number(id));
    if (!faq) return;
    document.getElementById('faqId').value = faq.id;
    document.getElementById('faqQuestion').value = faq.question;
    document.getElementById('faqAnswer').value = faq.answer;
    document.getElementById('faqKeywords').value = faq.keywords || '';
    document.getElementById('formTitle').innerHTML = '<i class="fas fa-edit"></i> Edit FAQ';
    document.getElementById('cancelEditBtn').style.display = 'inline-flex';
    window.scrollTo({ top: 0, behavior: 'smooth' });
};

window.deleteFaq = async function (id) {
    if (!confirm('Delete this FAQ?')) return;
    try {
        await HelpAPI.deleteFaq(id);
        showMsg('FAQ deleted.', true);
        resetForm();
        await loadFaqs();
    } catch (err) {
        showMsg(err.message, false);
    }
};

function resetForm() {
    document.getElementById('faqForm').reset();
    document.getElementById('faqId').value = '';
    document.getElementById('formTitle').innerHTML = '<i class="fas fa-plus"></i> Add FAQ';
    document.getElementById('cancelEditBtn').style.display = 'none';
}

async function onSubmit(e) {
    e.preventDefault();
    const id = document.getElementById('faqId').value;
    const payload = {
        question: document.getElementById('faqQuestion').value.trim(),
        answer: document.getElementById('faqAnswer').value.trim(),
        keywords: document.getElementById('faqKeywords').value.trim(),
    };
    try {
        if (id) {
            await HelpAPI.updateFaq({ id: parseInt(id, 10), ...payload });
            showMsg('FAQ updated successfully.', true);
        } else {
            await HelpAPI.createFaq(payload);
            showMsg('FAQ created successfully.', true);
        }
        resetForm();
        await loadFaqs();
    } catch (err) {
        showMsg(err.message, false);
    }
}
