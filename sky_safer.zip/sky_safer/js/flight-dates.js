/**
 * Shared departure / return date validation and trip-type UI.
 */
const FlightDates = (function () {
    const TRIP_ONE_WAY = 'one_way';
    const TRIP_ROUND = 'round_trip';

    function todayIso() {
        return new Date().toISOString().split('T')[0];
    }

    function isRoundTrip(tripType) {
        return tripType === TRIP_ROUND || tripType === 'round-trip' || tripType === 'round_trip';
    }

    /**
     * @returns {{ valid: boolean, message: string }}
     */
    function validate(tripType, departureDate, returnDate) {
        const depart = (departureDate || '').trim();
        const ret = (returnDate || '').trim();
        const today = todayIso();

        if (!depart) {
            return { valid: false, message: 'Departure date is required.' };
        }

        if (!/^\d{4}-\d{2}-\d{2}$/.test(depart)) {
            return { valid: false, message: 'Invalid departure date format.' };
        }

        if (depart < today) {
            return { valid: false, message: 'Departure date cannot be in the past.' };
        }

        if (isRoundTrip(tripType)) {
            if (!ret) {
                return { valid: false, message: 'Return date is required for a round trip.' };
            }
            if (!/^\d{4}-\d{2}-\d{2}$/.test(ret)) {
                return { valid: false, message: 'Invalid return date format.' };
            }
            if (ret <= depart) {
                return { valid: false, message: 'Return date must be after departure date.' };
            }
        }

        return { valid: true, message: '' };
    }

    function showError(errorEl, message) {
        if (!errorEl) {
            if (typeof showToast !== 'undefined') {
                showToast(message, 'error');
            } else {
                alert(message);
            }
            return;
        }
        errorEl.textContent = message;
        errorEl.classList.add('is-visible');
        errorEl.setAttribute('role', 'alert');
    }

    function hideError(errorEl) {
        if (!errorEl) return;
        errorEl.classList.remove('is-visible');
        errorEl.textContent = '';
        errorEl.removeAttribute('role');
    }

    function setInputError(input, hasError) {
        if (!input) return;
        input.classList.toggle('input-error', hasError);
    }

    /**
     * Wire trip type dropdown to show/hide return date and enforce mins.
     */
    function initForm(options) {
        const {
            tripTypeSelectId = 'tripType',
            departureInputId = 'departure_date',
            returnGroupId = 'returnDateGroup',
            returnInputId = 'return_date',
            errorBoxId = 'flightDateError',
        } = options;

        const tripSelect = document.getElementById(tripTypeSelectId);
        const departInput = document.getElementById(departureInputId);
        const returnGroup = document.getElementById(returnGroupId);
        const returnInput = document.getElementById(returnInputId);
        const errorEl = document.getElementById(errorBoxId);

        if (!departInput) return;

        const today = todayIso();
        departInput.min = today;
        if (returnInput) {
            returnInput.min = departInput.value || today;
        }

        function syncReturnVisibility() {
            const round = tripSelect && isRoundTrip(tripSelect.value);
            if (returnGroup) {
                returnGroup.classList.toggle('is-hidden', !round);
            }
            if (returnInput) {
                if (round) {
                    returnInput.required = true;
                    returnInput.disabled = false;
                    returnInput.min = departInput.value || today;
                } else {
                    returnInput.required = false;
                    returnInput.value = '';
                    returnInput.disabled = true;
                    setInputError(returnInput, false);
                }
            }
        }

        departInput.addEventListener('change', () => {
            hideError(errorEl);
            setInputError(departInput, false);
            if (returnInput) {
                returnInput.min = departInput.value || today;
                if (returnInput.value && returnInput.value <= departInput.value) {
                    returnInput.value = '';
                }
            }
        });

        if (returnInput) {
            returnInput.addEventListener('change', () => {
                hideError(errorEl);
                setInputError(returnInput, false);
            });
        }

        if (tripSelect) {
            tripSelect.addEventListener('change', () => {
                hideError(errorEl);
                syncReturnVisibility();
            });
        }

        syncReturnVisibility();
    }

    /**
     * Validate and show inline error; returns true if valid.
     */
    function validateForm(tripType, departureDate, returnDate, errorBoxId) {
        const errorEl = errorBoxId ? document.getElementById(errorBoxId) : null;
        const result = validate(tripType, departureDate, returnDate);

        const departInput = document.getElementById('departure_date') || document.getElementById('searchDepart');
        const returnInput = document.getElementById('return_date') || document.getElementById('searchReturn');

        setInputError(departInput, !result.valid && !departureDate);
        setInputError(returnInput, !result.valid && isRoundTrip(tripType));

        if (!result.valid) {
            showError(errorEl, result.message);
            return false;
        }

        hideError(errorEl);
        return true;
    }

    function formatDisplayDate(isoDate) {
        if (!isoDate) return '—';
        const d = new Date(isoDate + 'T12:00:00');
        return d.toLocaleDateString('en-US', { weekday: 'short', month: 'short', day: 'numeric', year: 'numeric' });
    }

    return {
        TRIP_ONE_WAY,
        TRIP_ROUND,
        todayIso,
        isRoundTrip,
        validate,
        validateForm,
        initForm,
        formatDisplayDate,
        showError,
        hideError,
    };
})();

if (typeof window !== 'undefined') {
    window.FlightDates = FlightDates;
}
