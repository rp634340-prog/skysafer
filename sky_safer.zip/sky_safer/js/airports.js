/**
 * Airports Data and Suggestions
 * Loads airports from JSON and provides autocomplete functionality
 */

let airportsData = [];
let indiaAirports = [];

// Load airports data
async function loadAirports() {
    try {
        const response = await fetch('airports.json');
        airportsData = await response.json();
        
        // Filter for India airports (iso: "IN") and active airports (status: 1)
        indiaAirports = airportsData.filter(airport => 
            airport.iso === 'IN' && 
            airport.status === 1 && 
            airport.type === 'airport' &&
            airport.iata && 
            airport.iata.length === 3
        );
        
        // Add city name to each airport
        indiaAirports = indiaAirports.map(airport => {
            airport.city = extractCityFromName(airport.name);
            return airport;
        });
        
        // Sort by city name
        indiaAirports.sort((a, b) => (a.city || a.name).localeCompare(b.city || b.name));
        
        console.log(`Loaded ${indiaAirports.length} India airports`);
        return indiaAirports;
    } catch (error) {
        console.error('Error loading airports:', error);
        // Fallback to common India airports
        return getFallbackAirports();
    }
}

// Fallback airports if JSON fails to load
function getFallbackAirports() {
    return [
        { iata: 'AMD', name: 'Sardar Vallabhbhai Patel International Airport', city: 'Ahmedabad', state: 'Gujarat' },
        { iata: 'STV', name: 'Surat Airport', city: 'Surat', state: 'Gujarat' },
        { iata: 'BOM', name: 'Chhatrapati Shivaji Maharaj International Airport', city: 'Mumbai', state: 'Maharashtra' },
        { iata: 'DEL', name: 'Indira Gandhi International Airport', city: 'Delhi', state: 'Delhi' },
        { iata: 'BLR', name: 'Kempegowda International Airport', city: 'Bangalore', state: 'Karnataka' },
        { iata: 'MAA', name: 'Chennai International Airport', city: 'Chennai', state: 'Tamil Nadu' },
        { iata: 'CCU', name: 'Netaji Subhash Chandra Bose International Airport', city: 'Kolkata', state: 'West Bengal' },
        { iata: 'HYD', name: 'Rajiv Gandhi International Airport', city: 'Hyderabad', state: 'Telangana' },
        { iata: 'PNQ', name: 'Pune Airport', city: 'Pune', state: 'Maharashtra' },
        { iata: 'GOI', name: 'Dabolim Airport', city: 'Goa', state: 'Goa' },
        { iata: 'JAI', name: 'Jaipur International Airport', city: 'Jaipur', state: 'Rajasthan' },
        { iata: 'COK', name: 'Cochin International Airport', city: 'Kochi', state: 'Kerala' },
        { iata: 'IXC', name: 'Chandigarh Airport', city: 'Chandigarh', state: 'Chandigarh' },
        { iata: 'LKO', name: 'Chaudhary Charan Singh International Airport', city: 'Lucknow', state: 'Uttar Pradesh' },
        { iata: 'VNS', name: 'Lal Bahadur Shastri Airport', city: 'Varanasi', state: 'Uttar Pradesh' }
    ];
}

/**
 * Get airport suggestions based on search query
 */
function getAirportSuggestions(query, limit = 10) {
    if (!query || query.length < 1) {
        return [];
    }
    
    const searchTerm = query.toLowerCase().trim();
    const results = [];
    
    // Search in airport name, IATA code, and city
    for (const airport of indiaAirports) {
        const name = (airport.name || '').toLowerCase();
        const iata = (airport.iata || '').toLowerCase();
        const city = (airport.city || '').toLowerCase();
        
        if (name.includes(searchTerm) || 
            iata.includes(searchTerm) || 
            city.includes(searchTerm)) {
            results.push(airport);
            if (results.length >= limit) break;
        }
    }
    
    return results;
}

/**
 * Format airport for display
 */
function formatAirport(airport) {
    const city = airport.city || extractCityFromName(airport.name);
    return `${city} (${airport.iata}) - ${airport.name}`;
}

/**
 * Extract city name from airport name
 */
function extractCityFromName(name) {
    if (!name) return '';
    
    // Remove common suffixes
    let cityName = name
        .replace(/\s+International\s+Airport.*$/i, '')
        .replace(/\s+Airport.*$/i, '')
        .replace(/\s+Air\s+Base.*$/i, '')
        .replace(/\s+Airfield.*$/i, '')
        .trim();
    
    // Handle names with "/" - take first part
    if (cityName.includes('/')) {
        cityName = cityName.split('/')[0].trim();
    }
    
    // Handle names with "-" - take first part
    if (cityName.includes('-')) {
        cityName = cityName.split('-')[0].trim();
    }
    
    // Remove common prefixes
    cityName = cityName
        .replace(/^(Sardar|Chhatrapati|Indira|Netaji|Rajiv|Chaudhary|Lal|Kempegowda)\s+/i, '')
        .replace(/\s+(Vallabhbhai|Shivaji|Gandhi|Subhash|Charan|Bahadur|Shastri|Maharaj).*$/i, '')
        .trim();
    
    // If still long, take first 2-3 words
    const words = cityName.split(' ');
    if (words.length > 3) {
        cityName = words.slice(0, 2).join(' ');
    }
    
    return cityName || name.split(' ')[0];
}

/**
 * Initialize airport suggestions for input fields
 */
function initAirportSuggestions(inputId, suggestionsId) {
    const input = document.getElementById(inputId);
    const suggestionsBox = document.getElementById(suggestionsId);
    
    if (!input || !suggestionsBox) return;
    
    let selectedIndex = -1;
    let suggestions = [];
    
    input.addEventListener('input', (e) => {
        const query = e.target.value;
        
        if (query.length < 1) {
            suggestionsBox.style.display = 'none';
            return;
        }
        
        suggestions = getAirportSuggestions(query, 8);
        selectedIndex = -1;
        
        if (suggestions.length > 0) {
            displaySuggestions(suggestions, suggestionsBox, input);
        } else {
            suggestionsBox.style.display = 'none';
        }
    });
    
    input.addEventListener('keydown', (e) => {
        if (!suggestionsBox.style.display || suggestionsBox.style.display === 'none') return;
        
        if (e.key === 'ArrowDown') {
            e.preventDefault();
            selectedIndex = Math.min(selectedIndex + 1, suggestions.length - 1);
            updateSelectedSuggestion();
        } else if (e.key === 'ArrowUp') {
            e.preventDefault();
            selectedIndex = Math.max(selectedIndex - 1, -1);
            updateSelectedSuggestion();
        } else if (e.key === 'Enter' && selectedIndex >= 0) {
            e.preventDefault();
            selectAirport(suggestions[selectedIndex], input);
        } else if (e.key === 'Escape') {
            suggestionsBox.style.display = 'none';
        }
    });
    
    function displaySuggestions(suggestions, container, input) {
        container.innerHTML = '';
        container.style.display = 'block';
        
        suggestions.forEach((airport, index) => {
            const div = document.createElement('div');
            div.className = 'suggestion-item';
            div.dataset.index = index;
            
            const city = airport.city || extractCityFromName(airport.name);
            div.innerHTML = `
                <div style="display: flex; justify-content: space-between; align-items: center;">
                    <div>
                        <strong>${city} (${airport.iata})</strong>
                        <div style="font-size: 0.85rem; color: var(--gray);">${airport.name}</div>
                    </div>
                </div>
            `;
            
            div.addEventListener('click', () => {
                selectAirport(airport, input);
            });
            
            div.addEventListener('mouseenter', () => {
                selectedIndex = index;
                updateSelectedSuggestion();
            });
            
            container.appendChild(div);
        });
    }
    
    function updateSelectedSuggestion() {
        const items = suggestionsBox.querySelectorAll('.suggestion-item');
        items.forEach((item, index) => {
            if (index === selectedIndex) {
                item.style.background = 'var(--primary)';
                item.style.color = 'white';
            } else {
                item.style.background = '';
                item.style.color = '';
            }
        });
    }
    
    function selectAirport(airport, input) {
        const city = airport.city || extractCityFromName(airport.name);
        input.value = `${city} (${airport.iata})`;
        suggestionsBox.style.display = 'none';
        input.dataset.airportCode = airport.iata;
        input.dataset.airportName = airport.name;
    }
    
    // Close suggestions when clicking outside
    document.addEventListener('click', (e) => {
        if (!input.contains(e.target) && !suggestionsBox.contains(e.target)) {
            suggestionsBox.style.display = 'none';
        }
    });
}

// Load airports when DOM is ready
document.addEventListener('DOMContentLoaded', async () => {
    await loadAirports();
    
    // Initialize suggestions for search forms
    initAirportSuggestions('searchFrom', 'searchFromSuggestions');
    initAirportSuggestions('searchTo', 'searchToSuggestions');
    initAirportSuggestions('fromCity', 'fromSuggestions');
    initAirportSuggestions('toCity', 'toSuggestions');
});
