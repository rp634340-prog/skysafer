/**
 * API Helper Functions
 * Handles all AJAX calls to the backend
 */

function resolveApiBaseUrl() {
    if (typeof window === 'undefined') return '/api';
    const path = window.location.pathname || '';
    const baseDir = path.replace(/\/[^/]*$/, '');
    const normalized = baseDir.endsWith('/') ? baseDir.slice(0, -1) : baseDir;
    return `${normalized}/api`;
}

const API_BASE_URL = resolveApiBaseUrl();
let csrfToken = sessionStorage.getItem('csrfToken') || '';

/**
 * Path under /api/ (avoid double "api" when endpoint mistakenly includes "api/").
 */
function normalizeApiEndpoint(endpoint) {
    let path = String(endpoint).replace(/^\/+/, '');
    if (path.startsWith('api/')) {
        path = path.slice(4);
    }
    return path;
}

/**
 * Make API request; parses JSON from body regardless of Content-Type (Apache-safe).
 */
async function apiRequest(endpoint, options = {}) {
    const path = normalizeApiEndpoint(endpoint);
    const url = `${API_BASE_URL}/${path}`;
    const defaultOptions = {
        headers: {
            'Content-Type': 'application/json',
        },
    };
    
    const config = { ...defaultOptions, ...options };
    config.headers = { ...defaultOptions.headers, ...(options.headers || {}) };

    if (csrfToken) {
        config.headers['X-CSRF-Token'] = csrfToken;
    }
    
    if (config.body && typeof config.body === 'object') {
        config.body = JSON.stringify(config.body);
    }
    
    try {
        const response = await fetch(url, config);
        const rawText = await response.text();
        let data;
        try {
            data = rawText ? JSON.parse(rawText) : null;
        } catch (parseErr) {
            const preview = rawText.replace(/\s+/g, ' ').trim().slice(0, 160);
            throw new Error(
                `Invalid API response from ${path}. Expected JSON but received: ${preview || '(empty body)'}`
            );
        }
        if (data === null || typeof data !== 'object') {
            throw new Error(`Invalid API response from ${path}: response was not a JSON object.`);
        }

        if (data && data.csrfToken) {
            csrfToken = data.csrfToken;
            sessionStorage.setItem('csrfToken', csrfToken);
        }
        
        if (!response.ok) {
            throw new Error(data.message || data.error || 'Request failed');
        }
        
        return data;
    } catch (error) {
        console.error('API Error:', error);
        throw error;
    }
}

/**
 * Authentication API
 */
const AuthAPI = {
    signup: async (userData) => {
        return apiRequest('auth.php?action=signup', {
            method: 'POST',
            body: userData,
        });
    },
    
    login: async (username, password) => {
        return apiRequest('auth.php?action=login', {
            method: 'POST',
            body: { username, password },
        });
    },
    
    logout: async () => {
        const result = await apiRequest('auth.php?action=logout', {
            method: 'POST',
        });
        csrfToken = '';
        sessionStorage.removeItem('csrfToken');
        return result;
    },
    
    check: async () => {
        return apiRequest('auth.php?action=check');
    },
};

/**
 * Flights API
 */
const FlightsAPI = {
    search: async (searchParams) => {
        const params = new URLSearchParams(searchParams);
        return apiRequest(`flights.php?action=search&${params.toString()}`);
    },
    
    get: async (flightId) => {
        return apiRequest(`flights.php?action=get&id=${flightId}`);
    },
    
    list: async (limit = 50, offset = 0) => {
        return apiRequest(`flights.php?action=list&limit=${limit}&offset=${offset}`);
    },
};

/**
 * Bookings API
 */
const BookingsAPI = {
    create: async (bookingData) => {
        return apiRequest('bookings.php?action=create', {
            method: 'POST',
            body: bookingData,
        });
    },
    
    list: async (status = '', limit = 50, offset = 0) => {
        const params = new URLSearchParams({
            limit,
            offset,
        });
        if (status) params.append('status', status);
        return apiRequest(`bookings.php?action=list&${params.toString()}`);
    },
    
    get: async (bookingId, bookingRef = '') => {
        if (bookingRef) {
            return apiRequest(`bookings.php?action=get&ref=${bookingRef}`);
        }
        return apiRequest(`bookings.php?action=get&id=${bookingId}`);
    },
    
    cancel: async (bookingId, classType) => {
        return apiRequest('bookings.php?action=cancel', {
            method: 'POST',
            body: { bookingId, classType },
        });
    },
    
    pay: async (bookingId, bookingRef, paymentMethod = 'card') => {
        return apiRequest('bookings.php?action=pay', {
            method: 'POST',
            body: { bookingId, bookingReference: bookingRef, paymentMethod },
        });
    },

    seatLayout: async (flightId, classType) => {
        return apiRequest(`bookings.php?action=seatLayout&flightId=${flightId}&classType=${encodeURIComponent(classType)}`);
    },

    lockSeat: async (flightId, classType, seatNumber) => {
        return apiRequest('bookings.php?action=lockSeat', {
            method: 'POST',
            body: { flightId, classType, seatNumber }
        });
    },

    unlockSeat: async (flightId, classType, seatNumber) => {
        return apiRequest('bookings.php?action=unlockSeat', {
            method: 'POST',
            body: { flightId, classType, seatNumber }
        });
    },
};

/**
 * Profile API
 */
const ProfileAPI = {
    get: async () => {
        return apiRequest('profile.php?action=get');
    },
    
    update: async (profileData) => {
        return apiRequest('profile.php?action=update', {
            method: 'POST',
            body: profileData,
        });
    },
    
    updatePassword: async (currentPassword, newPassword, confirmPassword) => {
        return apiRequest('profile.php?action=updatePassword', {
            method: 'POST',
            body: { currentPassword, newPassword, confirmPassword },
        });
    },
    
    getPreferences: async () => {
        return apiRequest('profile.php?action=getPreferences');
    },
    
    updatePreferences: async (preferences) => {
        return apiRequest('profile.php?action=updatePreferences', {
            method: 'POST',
            body: preferences,
        });
    },
};

/**
 * Activity API
 */
const ActivityAPI = {
    track: async (eventData) => {
        return apiRequest('user-activity.php?action=track', {
            method: 'POST',
            body: eventData,
        });
    },

    batch: async (events) => {
        return apiRequest('user-activity.php?action=batch', {
            method: 'POST',
            body: { events },
        });
    },

    searchHistory: async (params = {}) => {
        const query = new URLSearchParams(params);
        return apiRequest(`user-activity.php?action=searchHistory&${query.toString()}`);
    },
};

/**
 * Notifications API
 */
const NotificationsAPI = {
    list: async (params = {}) => {
        const query = new URLSearchParams(params);
        return apiRequest(`notifications.php?action=list&${query.toString()}`);
    },

    create: async (payload) => {
        return apiRequest('notifications.php?action=create', {
            method: 'POST',
            body: payload
        });
    },

    markRead: async (notificationId) => {
        return apiRequest('notifications.php?action=markRead', {
            method: 'POST',
            body: { notificationId }
        });
    },

    markAllRead: async () => {
        return apiRequest('notifications.php?action=markAllRead', {
            method: 'POST'
        });
    }
};

/**
 * Admin API
 */
const AdminAPI = {
    dashboard: async () => {
        return apiRequest('admin.php?action=dashboard');
    }
};

/**
 * Recommendations API
 */
const RecommendationsAPI = {
    flights: async (limit = 6) => {
        return apiRequest(`recommendations.php?action=flights&limit=${limit}`);
    }
};

/**
 * Help / AI Chat API
 */
const HelpAPI = {
    chat: async (message, sessionId) => {
        return apiRequest('help_chat.php?action=chat', {
            method: 'POST',
            body: { message, sessionId },
        });
    },
    welcome: async () => apiRequest('help_chat.php?action=welcome'),
    history: async (sessionId, limit = 30) =>
        apiRequest(`help_chat.php?action=history&sessionId=${encodeURIComponent(sessionId)}&limit=${limit}`),
    listFaqs: async () => apiRequest('help_chat.php?action=list'),
    createFaq: async (data) =>
        apiRequest('help_chat.php?action=create', { method: 'POST', body: data }),
    updateFaq: async (data) =>
        apiRequest('help_chat.php?action=update', { method: 'POST', body: data }),
    deleteFaq: async (id) =>
        apiRequest('help_chat.php?action=delete', { method: 'POST', body: { id } }),
};

/**
 * Show toast notification
 */
function showToast(message, type = 'info') {
    const toast = document.createElement('div');
    toast.className = `toast show ${type}`;
    toast.style.cssText = `
        position: fixed;
        top: 20px;
        right: 20px;
        padding: 15px 20px;
        background: ${type === 'success' ? '#4caf50' : type === 'error' ? '#f44336' : '#2196f3'};
        color: white;
        border-radius: 5px;
        box-shadow: 0 4px 6px rgba(0,0,0,0.1);
        z-index: 10000;
        animation: slideIn 0.3s ease;
    `;
    toast.innerHTML = `
        <i class="fas fa-${type === 'success' ? 'check-circle' : type === 'error' ? 'exclamation-circle' : 'info-circle'}"></i>
        <span style="margin-left: 10px;">${message}</span>
    `;
    document.body.appendChild(toast);
    
    setTimeout(() => {
        toast.style.animation = 'slideOut 0.3s ease';
        setTimeout(() => toast.remove(), 300);
    }, 3000);
}

// Add CSS for toast animation
if (!document.getElementById('toast-styles')) {
    const style = document.createElement('style');
    style.id = 'toast-styles';
    style.textContent = `
        @keyframes slideIn {
            from { transform: translateX(100%); opacity: 0; }
            to { transform: translateX(0); opacity: 1; }
        }
        @keyframes slideOut {
            from { transform: translateX(0); opacity: 1; }
            to { transform: translateX(100%); opacity: 0; }
        }
    `;
    document.head.appendChild(style);
}
