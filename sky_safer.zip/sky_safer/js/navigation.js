/**
 * Common Navigation Component
 * Handles navigation across all pages
 */

async function loadNavigation(activePage = '') {
    const t = (key, fallback) => {
        if (typeof I18nApp !== 'undefined' && typeof I18nApp.t === 'function') {
            return I18nApp.t(key);
        }
        return fallback;
    };
    // Check authentication status
    let isLoggedIn = false;
    let currentUser = null;
    
    try {
        if (typeof AuthAPI !== 'undefined') {
            const response = await AuthAPI.check();
            isLoggedIn = response.authenticated;
            currentUser = response.user || null;
        }
    } catch (error) {
        console.error('Auth check failed:', error);
    }
    
    // Update navigation based on auth status
    const loginLink = document.getElementById('loginLink');
    const signupLink = document.getElementById('signupLink');
    const profileLink = document.getElementById('profileLink');
    const logoutBtn = document.getElementById('logoutBtn');
    
    if (isLoggedIn && currentUser) {
        // Hide login/signup, show profile
        if (loginLink) loginLink.style.display = 'none';
        if (signupLink) signupLink.style.display = 'none';
        if (profileLink) {
            profileLink.style.display = 'flex';
            profileLink.innerHTML = `<i class="fas fa-user"></i> ${currentUser.firstName || currentUser.username}`;
            profileLink.href = 'profile.html';
        }

        if ((currentUser.role || 'user') === 'admin' && document.querySelector('.nav-menu') && !document.getElementById('adminLink')) {
            const navMenu = document.querySelector('.nav-menu');
            const adminLink = document.createElement('a');
            adminLink.id = 'adminLink';
            adminLink.className = 'nav-link';
            adminLink.href = 'admin.html';
            adminLink.innerHTML = '<i class="fas fa-shield-alt"></i> Admin';
            navMenu.insertBefore(adminLink, profileLink || navMenu.firstChild);
        }
        // Add logout button if not exists
        if (!logoutBtn && document.querySelector('.nav-menu')) {
            const navMenu = document.querySelector('.nav-menu');
            const logoutLink = document.createElement('a');
            logoutLink.id = 'logoutBtn';
            logoutLink.className = 'nav-link';
            logoutLink.href = '#';
            logoutLink.innerHTML = `<i class="fas fa-sign-out-alt"></i> ${t('nav.logout', 'Logout')}`;
            logoutLink.addEventListener('click', async (e) => {
                e.preventDefault();
                try {
                    await AuthAPI.logout();
                    window.location.href = 'index.html';
                } catch (error) {
                    console.error('Logout failed:', error);
                    window.location.href = 'index.html';
                }
            });
            navMenu.appendChild(logoutLink);
        }
    } else {
        // Show login/signup, hide profile
        if (loginLink) loginLink.style.display = 'flex';
        if (signupLink) signupLink.style.display = 'flex';
        if (profileLink) {
            profileLink.style.display = 'none';
        }
        const adminLink = document.getElementById('adminLink');
        if (adminLink) adminLink.remove();
        if (logoutBtn) logoutBtn.remove();
    }

    if (isLoggedIn && currentUser && document.querySelector('.nav-menu')) {
        const initNotificationCenter = async () => {
            if (typeof NotificationCenter !== 'undefined') {
                await NotificationCenter.init({
                    userId: currentUser.id,
                    role: currentUser.role || 'user'
                });
                return;
            }
            const existing = document.querySelector('script[data-notifications-script="1"]');
            if (existing) return;
            const script = document.createElement('script');
            script.src = 'js/notifications.js';
            script.dataset.notificationsScript = '1';
            script.onload = async () => {
                if (typeof NotificationCenter !== 'undefined') {
                    await NotificationCenter.init({
                        userId: currentUser.id,
                        role: currentUser.role || 'user'
                    });
                }
            };
            document.head.appendChild(script);
        };
        await initNotificationCenter();
    }
    
    // Set active page
    if (activePage) {
        document.querySelectorAll('.nav-link').forEach(link => {
            link.classList.remove('active');
            if (link.getAttribute('href') === activePage || link.textContent.includes(activePage)) {
                link.classList.add('active');
            }
        });
    }

    if (typeof I18nApp !== 'undefined' && typeof I18nApp.apply === 'function') {
        I18nApp.apply();
    }
    
    return { isLoggedIn, currentUser };
}

// Mobile menu toggle
document.addEventListener('DOMContentLoaded', function() {
    const menuToggle = document.getElementById('menuToggle');
    const navMenu = document.querySelector('.nav-menu');
    
    if (menuToggle && navMenu) {
        menuToggle.addEventListener('click', () => {
            navMenu.classList.toggle('active');
            menuToggle.innerHTML = navMenu.classList.contains('active') 
                ? '<i class="fas fa-times"></i>' 
                : '<i class="fas fa-bars"></i>';
        });
    }
});
