-- SkySafer Flight Booking System Database Schema
-- Created for MySQL/MariaDB

CREATE DATABASE IF NOT EXISTS skysafer_db;
USE skysafer_db;

-- Users table
CREATE TABLE IF NOT EXISTS users (
    id INT PRIMARY KEY AUTO_INCREMENT,
    username VARCHAR(50) UNIQUE NOT NULL,
    email VARCHAR(100) UNIQUE NOT NULL,
    password_hash VARCHAR(255) NOT NULL,
    first_name VARCHAR(50) NOT NULL,
    last_name VARCHAR(50) NOT NULL,
    phone VARCHAR(20),
    date_of_birth DATE,
    address TEXT,
    passport_number VARCHAR(50),
    passport_expiry DATE,
    emergency_contact_name VARCHAR(100),
    emergency_contact_phone VARCHAR(20),
    emergency_contact_relation VARCHAR(50),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    INDEX idx_username (username),
    INDEX idx_email (email)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Airlines table
CREATE TABLE IF NOT EXISTS airlines (
    id INT PRIMARY KEY AUTO_INCREMENT,
    name VARCHAR(100) NOT NULL,
    code VARCHAR(10) UNIQUE NOT NULL,
    logo_url VARCHAR(255),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Cities/Airports table
CREATE TABLE IF NOT EXISTS cities (
    id INT PRIMARY KEY AUTO_INCREMENT,
    name VARCHAR(100) NOT NULL,
    code VARCHAR(10) UNIQUE NOT NULL,
    country VARCHAR(100),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Flights table
CREATE TABLE IF NOT EXISTS flights (
    id INT PRIMARY KEY AUTO_INCREMENT,
    flight_number VARCHAR(20) NOT NULL,
    airline_id INT NOT NULL,
    departure_city_id INT NOT NULL,
    arrival_city_id INT NOT NULL,
    departure_time DATETIME NOT NULL,
    arrival_time DATETIME NOT NULL,
    duration_minutes INT NOT NULL,
    economy_price DECIMAL(10,2) NOT NULL,
    premium_price DECIMAL(10,2),
    business_price DECIMAL(10,2),
    first_class_price DECIMAL(10,2),
    economy_seats INT DEFAULT 100,
    premium_seats INT DEFAULT 20,
    business_seats INT DEFAULT 10,
    first_class_seats INT DEFAULT 5,
    economy_available INT DEFAULT 100,
    premium_available INT DEFAULT 20,
    business_available INT DEFAULT 10,
    first_class_available INT DEFAULT 5,
    stops INT DEFAULT 0,
    stop_city_id INT,
    baggage_allowance_kg INT DEFAULT 20,
    cabin_baggage_kg INT DEFAULT 7,
    status ENUM('scheduled', 'delayed', 'cancelled', 'completed') DEFAULT 'scheduled',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (airline_id) REFERENCES airlines(id) ON DELETE CASCADE,
    FOREIGN KEY (departure_city_id) REFERENCES cities(id) ON DELETE CASCADE,
    FOREIGN KEY (arrival_city_id) REFERENCES cities(id) ON DELETE CASCADE,
    FOREIGN KEY (stop_city_id) REFERENCES cities(id) ON DELETE SET NULL,
    INDEX idx_departure (departure_city_id, departure_time),
    INDEX idx_arrival (arrival_city_id, arrival_time),
    INDEX idx_flight_number (flight_number)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Bookings table
CREATE TABLE IF NOT EXISTS bookings (
    id INT PRIMARY KEY AUTO_INCREMENT,
    user_id INT NOT NULL,
    flight_id INT NOT NULL,
    booking_reference VARCHAR(20) UNIQUE NOT NULL,
    passengers_count INT DEFAULT 1,
    class_type ENUM('economy', 'premium', 'business', 'first') DEFAULT 'economy',
    trip_type ENUM('one_way', 'round_trip') NOT NULL DEFAULT 'one_way',
    departure_date DATE NULL,
    return_date DATE NULL,
    return_flight_id INT NULL,
    total_price DECIMAL(10,2) NOT NULL,
    booking_date TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    status ENUM('pending', 'confirmed', 'cancelled', 'completed') DEFAULT 'pending',
    payment_status ENUM('pending', 'paid', 'refunded') DEFAULT 'pending',
    payment_method VARCHAR(50),
    notes TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
    FOREIGN KEY (flight_id) REFERENCES flights(id) ON DELETE CASCADE,
    FOREIGN KEY (return_flight_id) REFERENCES flights(id) ON DELETE SET NULL,
    INDEX idx_user (user_id),
    INDEX idx_departure_date (departure_date),
    INDEX idx_return_date (return_date),
    INDEX idx_booking_ref (booking_reference),
    INDEX idx_status (status)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Passengers table (for booking details)
CREATE TABLE IF NOT EXISTS passengers (
    id INT PRIMARY KEY AUTO_INCREMENT,
    booking_id INT NOT NULL,
    first_name VARCHAR(50) NOT NULL,
    last_name VARCHAR(50) NOT NULL,
    date_of_birth DATE,
    passport_number VARCHAR(50),
    seat_number VARCHAR(10),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (booking_id) REFERENCES bookings(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Flight seats inventory/state table
CREATE TABLE IF NOT EXISTS flight_seats (
    id INT PRIMARY KEY AUTO_INCREMENT,
    flight_id INT NOT NULL,
    class_type ENUM('economy', 'premium', 'business', 'first') NOT NULL,
    seat_number VARCHAR(10) NOT NULL,
    seat_row INT NOT NULL,
    seat_column CHAR(1) NOT NULL,
    state ENUM('available', 'booked') DEFAULT 'available',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (flight_id) REFERENCES flights(id) ON DELETE CASCADE,
    UNIQUE KEY uniq_flight_class_seat (flight_id, class_type, seat_number),
    INDEX idx_flight_class_state (flight_id, class_type, state)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Active seat locks for checkout phase
CREATE TABLE IF NOT EXISTS seat_locks (
    id INT PRIMARY KEY AUTO_INCREMENT,
    flight_id INT NOT NULL,
    class_type ENUM('economy', 'premium', 'business', 'first') NOT NULL,
    seat_number VARCHAR(10) NOT NULL,
    user_id INT NOT NULL,
    status ENUM('locked', 'released') DEFAULT 'locked',
    expires_at DATETIME NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (flight_id) REFERENCES flights(id) ON DELETE CASCADE,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
    UNIQUE KEY uniq_lock_seat (flight_id, class_type, seat_number),
    INDEX idx_lock_expiry (expires_at),
    INDEX idx_lock_user (user_id, flight_id, class_type)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- User preferences table
CREATE TABLE IF NOT EXISTS user_preferences (
    id INT PRIMARY KEY AUTO_INCREMENT,
    user_id INT NOT NULL UNIQUE,
    seating_preference ENUM('aisle', 'window', 'extra_legroom', 'family') DEFAULT 'aisle',
    meal_preference ENUM('vegetarian', 'non_veg', 'vegan', 'gluten_free') DEFAULT 'vegetarian',
    notifications_flight_status BOOLEAN DEFAULT TRUE,
    notifications_price_drop BOOLEAN DEFAULT TRUE,
    notifications_promotions BOOLEAN DEFAULT FALSE,
    notifications_confirmations BOOLEAN DEFAULT TRUE,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- User activity table
CREATE TABLE IF NOT EXISTS user_activity (
    id INT PRIMARY KEY AUTO_INCREMENT,
    user_id INT NOT NULL,
    event_type VARCHAR(50) NOT NULL,
    event_name VARCHAR(100),
    page_url VARCHAR(255),
    element_name VARCHAR(150),
    metadata_json JSON,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
    INDEX idx_user_created (user_id, created_at),
    INDEX idx_event_type (event_type)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Notifications table
CREATE TABLE IF NOT EXISTS notifications (
    id INT PRIMARY KEY AUTO_INCREMENT,
    recipient_user_id INT NULL,
    target_role ENUM('user', 'admin') NOT NULL DEFAULT 'user',
    notification_type VARCHAR(50) NOT NULL,
    title VARCHAR(150) NOT NULL,
    message VARCHAR(255) NOT NULL,
    payload_json JSON NULL,
    is_read BOOLEAN DEFAULT FALSE,
    read_at TIMESTAMP NULL DEFAULT NULL,
    priority ENUM('low', 'normal', 'high') DEFAULT 'normal',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (recipient_user_id) REFERENCES users(id) ON DELETE CASCADE,
    INDEX idx_notif_user_created (recipient_user_id, created_at),
    INDEX idx_notif_role_created (target_role, created_at),
    INDEX idx_notif_unread (is_read, created_at)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Insert sample airlines
INSERT INTO airlines (name, code) VALUES
('SkyJet Airways', 'SJ'),
('Global Airlines', 'GA'),
('Express Air', 'EA'),
('Premium Airways', 'PA'),
('Fast Fly', 'FF');

-- Insert sample cities
INSERT INTO cities (name, code, country) VALUES
('Mahesana', 'MAH', 'India'),
('Surat', 'STV', 'India'),
('Mumbai', 'BOM', 'India'),
('Delhi', 'DEL', 'India'),
('Bangalore', 'BLR', 'India'),
('Chennai', 'MAA', 'India'),
('Kolkata', 'CCU', 'India'),
('Hyderabad', 'HYD', 'India'),
('Pune', 'PNQ', 'India'),
('Ahmedabad', 'AMD', 'India'),
('New York', 'JFK', 'USA'),
('Los Angeles', 'LAX', 'USA'),
('London', 'LHR', 'UK'),
('Paris', 'CDG', 'France'),
('Dubai', 'DXB', 'UAE'),
('Singapore', 'SIN', 'Singapore'),
('Tokyo', 'NRT', 'Japan'),
('Sydney', 'SYD', 'Australia');

-- Insert sample flights
INSERT INTO flights (flight_number, airline_id, departure_city_id, arrival_city_id, departure_time, arrival_time, duration_minutes, economy_price, premium_price, business_price, first_class_price, stops, baggage_allowance_kg, cabin_baggage_kg) VALUES
('SJ-204', 1, 1, 2, '2024-03-15 06:30:00', '2024-03-15 07:45:00', 75, 245.00, 350.00, 550.00, 850.00, 0, 20, 7),
('GA-308', 2, 1, 2, '2024-03-15 10:15:00', '2024-03-15 12:45:00', 150, 189.00, 280.00, 450.00, 700.00, 1, 15, 7),
('EA-412', 3, 1, 2, '2024-03-15 14:00:00', '2024-03-15 15:45:00', 105, 320.00, 420.00, 600.00, 950.00, 0, 25, 10),
('SJ-205', 1, 2, 4, '2024-04-10 14:00:00', '2024-04-10 16:30:00', 150, 450.00, 600.00, 850.00, 1200.00, 0, 20, 7),
('GA-512', 2, 2, 4, '2024-04-10 14:00:00', '2024-04-10 16:30:00', 150, 425.00, 575.00, 800.00, 1150.00, 0, 15, 7),
('EA-789', 3, 3, 15, '2024-05-05 08:00:00', '2024-05-05 11:30:00', 210, 1200.00, 1500.00, 2200.00, 3500.00, 0, 25, 10);

-- Update stop_city_id for flights with stops
UPDATE flights SET stop_city_id = 3 WHERE flight_number = 'GA-308';

-- Help / AI chat FAQ tables
CREATE TABLE IF NOT EXISTS help_questions (
    id INT PRIMARY KEY AUTO_INCREMENT,
    question VARCHAR(500) NOT NULL,
    answer TEXT NOT NULL,
    keywords VARCHAR(500) DEFAULT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    INDEX idx_question (question(191))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS help_chat_history (
    id INT PRIMARY KEY AUTO_INCREMENT,
    session_id VARCHAR(64) NOT NULL,
    user_id INT NULL,
    user_message TEXT NOT NULL,
    bot_answer TEXT NOT NULL,
    matched_question_id INT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    INDEX idx_session (session_id),
    INDEX idx_created (created_at),
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE SET NULL,
    FOREIGN KEY (matched_question_id) REFERENCES help_questions(id) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
