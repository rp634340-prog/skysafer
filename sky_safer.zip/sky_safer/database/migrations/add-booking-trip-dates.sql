-- Add trip type and travel dates to bookings (run once on existing databases)
USE skysafer_db;

ALTER TABLE bookings
    ADD COLUMN IF NOT EXISTS trip_type ENUM('one_way', 'round_trip') NOT NULL DEFAULT 'one_way' AFTER class_type,
    ADD COLUMN IF NOT EXISTS departure_date DATE NULL AFTER trip_type,
    ADD COLUMN IF NOT EXISTS return_date DATE NULL AFTER departure_date,
    ADD COLUMN IF NOT EXISTS return_flight_id INT NULL AFTER return_date,
    ADD INDEX IF NOT EXISTS idx_departure_date (departure_date),
    ADD INDEX IF NOT EXISTS idx_return_date (return_date);

-- MariaDB before 10.5 may not support IF NOT EXISTS on columns; use bookings.php ensureBookingsColumns() instead.
