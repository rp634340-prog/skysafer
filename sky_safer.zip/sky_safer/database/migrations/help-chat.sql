-- SkySafer AI Help / Support Chat
USE skysafer_db;

CREATE TABLE IF NOT EXISTS help_questions (
    id INT PRIMARY KEY AUTO_INCREMENT,
    question VARCHAR(500) NOT NULL,
    answer TEXT NOT NULL,
    keywords VARCHAR(500) DEFAULT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    INDEX idx_question (question(191)),
    FULLTEXT INDEX ft_help (question, answer, keywords)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS help_chat_history (
    id INT PRIMARY KEY AUTO_INCREMENT,
    session_id VARCHAR(64) NOT NULL,
    user_id INT NULL,
    user_message TEXT NOT NULL,
    bot_answer TEXT NOT NULL,
    matched_question_id INT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    INDEX idx_session (session_id),
    INDEX idx_created (created_at),
    CONSTRAINT fk_help_history_user FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE SET NULL,
    CONSTRAINT fk_help_history_question FOREIGN KEY (matched_question_id) REFERENCES help_questions(id) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

INSERT INTO help_questions (question, answer, keywords) VALUES
('How to book a ticket?', 'To book a ticket on SkySafer: 1) Search flights from the home page (From, To, dates, passengers). 2) Choose a flight and click Book Now. 3) Log in or sign up if prompted. 4) Enter passenger details, select seats, and confirm. 5) Complete payment to receive your booking reference.', 'book,booking,ticket,reserve,reservation,flight'),
('How to cancel a ticket?', 'Go to My Bookings, open the booking you want to cancel, and click Cancel. Confirmed bookings may be refundable depending on fare rules. Cancelled bookings release your seats. If you need help, contact support with your booking reference (starts with SKY).', 'cancel,cancellation,void,remove booking'),
('How to login?', 'Click Login in the top menu. Enter your username or email and password. If you do not have an account, use Sign Up to create one. After login you can access My Bookings, profile, and complete flight bookings.', 'login,sign in,log in,account access'),
('How to sign up?', 'Click Sign Up, fill in your name, email, username, and password (minimum 6 characters), then submit. You will be logged in automatically and can start booking flights.', 'register,signup,sign up,create account,new user'),
('Payment failed — what should I do?', 'If payment failed: 1) Check your card balance and billing details. 2) Try another payment method if available. 3) Open My Bookings — if status is pending, use Complete Payment. 4) Wait a few minutes and retry (do not pay twice). 5) Contact your bank if the amount was debited but booking shows pending. Keep your booking reference for support.', 'payment failed,card declined,transaction error,pay'),
('What is the refund policy?', 'Refunds depend on your fare type and how close you are to departure. Cancel eligible bookings from My Bookings. Paid amounts for refundable fares are processed within 5–10 business days to the original payment method. Non-refundable fares may only receive taxes or fees back per airline rules.', 'refund,money back,cancellation refund,policy'),
('How to view my bookings?', 'After logging in, open My Bookings from the menu. You will see upcoming, completed, and cancelled trips with flight details, dates, and booking reference. Use View Details for more information or to pay or cancel.', 'my bookings,view booking,history,trips'),
('How to change passenger details?', 'Passenger names on a confirmed ticket usually cannot be changed online. Update your profile under Account for future bookings. For an existing booking, contact support with your booking reference as soon as possible.', 'change name,passenger details,edit passenger'),
('Round trip vs one way?', 'On the search form, choose Trip type: One Way shows only a departure date; Round Trip shows departure and return dates (return must be after departure). Search results include return flights when applicable.', 'round trip,one way,return date,trip type'),
('How does seat selection work?', 'During booking, after entering passenger info, the seat map shows available seats. Select one seat per passenger, then confirm. Seats are held briefly while you complete the form.', 'seat,seat map,select seat,assignment'),
('Forgot password?', 'Password reset via email may be added soon. For now, contact support from the email used on your account. Admins can verify your identity and assist.', 'forgot password,reset password,password help'),
('Is my payment secure?', 'SkySafer uses secure connections for login and booking. Do not share your password or OTP. We never ask for your full card PIN. Always check that the site URL is correct before paying.', 'secure,safe,payment security,privacy'),
('Contact customer support', 'Email: support@skysafer.com | Phone: +1 (555) 123-4567 (9 AM–9 PM IST). Have your booking reference ready. You can also use this help chat for common questions.', 'contact,support,help,email,phone,customer service');
