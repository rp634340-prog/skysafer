<?php
/**
 * Flights API
 * Handles flight search and listing
 */

require_once __DIR__ . '/../config/config.php';

header('Content-Type: application/json');

$method = $_SERVER['REQUEST_METHOD'];
$action = $_GET['action'] ?? '';
$clientIp = $_SERVER['REMOTE_ADDR'] ?? 'unknown';
enforceRateLimit('flights_' . $clientIp . '_' . $action, 180, 60);

try {
    $pdo = getDBConnection();
    
    switch ($action) {
        case 'search':
            if ($method !== 'GET' && $method !== 'POST') {
                sendJSONResponse(['error' => 'Method not allowed'], 405);
            }
            handleSearchFlights($pdo, $method);
            break;
            
        case 'get':
            if ($method !== 'GET') {
                sendJSONResponse(['error' => 'Method not allowed'], 405);
            }
            handleGetFlight($pdo);
            break;
            
        case 'list':
            if ($method !== 'GET') {
                sendJSONResponse(['error' => 'Method not allowed'], 405);
            }
            handleListFlights($pdo);
            break;
            
        default:
            sendJSONResponse(['error' => 'Invalid action'], 400);
    }
} catch (Exception $e) {
    logError("Flights API Error: " . $e->getMessage());
    sendJSONResponse(['error' => 'Server error'], 500);
}

/**
 * Handle flight search
 */
function handleSearchFlights($pdo, $method = 'GET') {
    // Get parameters from GET or POST
    if ($method === 'GET') {
        $from = $_GET['from'] ?? '';
        $to = $_GET['to'] ?? '';
        $departDate = $_GET['departDate'] ?? '';
        $returnDate = $_GET['returnDate'] ?? '';
        $passengers = intval($_GET['passengers'] ?? 1);
        $classType = sanitizeInput($_GET['class'] ?? 'economy');
        $keyword = sanitizeInput($_GET['keyword'] ?? '');
        $maxPrice = floatval($_GET['maxPrice'] ?? 0);
        $minPrice = floatval($_GET['minPrice'] ?? 0);
        $stops = sanitizeInput($_GET['stops'] ?? 'any');
        $airlinesRaw = $_GET['airlines'] ?? '';
        $departStartTime = sanitizeInput($_GET['departStartTime'] ?? '');
        $departEndTime = sanitizeInput($_GET['departEndTime'] ?? '');
        $sortBy = sanitizeInput($_GET['sortBy'] ?? 'departure_time_asc');
        $tripType = normalizeFlightTripType($_GET['tripType'] ?? $_GET['trip_type'] ?? '');
    } else {
        $data = json_decode(file_get_contents('php://input'), true);
        $from = $data['from'] ?? '';
        $to = $data['to'] ?? '';
        $departDate = $data['departDate'] ?? '';
        $returnDate = $data['returnDate'] ?? '';
        $passengers = intval($data['passengers'] ?? 1);
        $classType = sanitizeInput($data['class'] ?? 'economy');
        $keyword = sanitizeInput($data['keyword'] ?? '');
        $maxPrice = floatval($data['maxPrice'] ?? 0);
        $minPrice = floatval($data['minPrice'] ?? 0);
        $stops = sanitizeInput($data['stops'] ?? 'any');
        $airlinesRaw = $data['airlines'] ?? '';
        $departStartTime = sanitizeInput($data['departStartTime'] ?? '');
        $departEndTime = sanitizeInput($data['departEndTime'] ?? '');
        $sortBy = sanitizeInput($data['sortBy'] ?? 'departure_time_asc');
        $tripType = normalizeFlightTripType($data['tripType'] ?? $data['trip_type'] ?? '');
    }

    if (empty($from) || empty($to) || empty($departDate)) {
        sendJSONResponse(['error' => 'From, To, and Departure date are required'], 400);
    }

    if ($tripType === '') {
        $tripType = !empty($returnDate) ? 'round_trip' : 'one_way';
    }
    if ($tripType === 'round_trip' && empty($returnDate)) {
        sendJSONResponse(['error' => 'Return date is required for round trip'], 400);
    }
    if ($tripType === 'one_way') {
        $returnDate = '';
    }

    $dateError = validateTravelDates($tripType ?: ($returnDate ? 'round_trip' : 'one_way'), $departDate, $returnDate ?: null);
    if ($dateError !== null) {
        sendJSONResponse(['error' => $dateError], 400);
    }
    
    // Find city IDs
    $fromCity = findCityByNameOrCode($pdo, $from);
    $toCity = findCityByNameOrCode($pdo, $to);
    
    if (!$fromCity || !$toCity) {
        sendJSONResponse(['error' => 'Invalid city names'], 400);
    }
    
    $validClasses = ['economy', 'premium', 'business', 'first'];
    if (!in_array($classType, $validClasses, true)) {
        $classType = 'economy';
    }
    $passengers = max(1, min($passengers, 9));

    $allowedSort = [
        'price_asc' => 'price ASC',
        'price_desc' => 'price DESC',
        'duration_asc' => 'f.duration_minutes ASC',
        'duration_desc' => 'f.duration_minutes DESC',
        'departure_time_desc' => 'f.departure_time DESC',
        'departure_time_asc' => 'f.departure_time ASC'
    ];
    if (!isset($allowedSort[$sortBy])) {
        $sortBy = 'departure_time_asc';
    }

    $airlineCodes = [];
    if (is_string($airlinesRaw) && $airlinesRaw !== '') {
        $airlineCodes = array_values(array_filter(array_map(function($code) {
            return strtoupper(trim(sanitizeInput($code)));
        }, explode(',', $airlinesRaw))));
    } elseif (is_array($airlinesRaw)) {
        $airlineCodes = array_values(array_filter(array_map(function($code) {
            return strtoupper(trim(sanitizeInput($code)));
        }, $airlinesRaw)));
    }

    $filters = [
        'keyword' => $keyword,
        'minPrice' => $minPrice,
        'maxPrice' => $maxPrice,
        'stops' => $stops,
        'airlineCodes' => $airlineCodes,
        'departStartTime' => $departStartTime,
        'departEndTime' => $departEndTime,
        'sortBy' => $sortBy
    ];

    // Build query for departure flights
    $departDateStart = $departDate . ' 00:00:00';
    $departDateEnd = $departDate . ' 23:59:59';
    $departureFlights = fetchFlightsForRoute($pdo, $classType, $fromCity['id'], $toCity['id'], $departDateStart, $departDateEnd, $passengers, $filters);
    
    $result = [
        'departureFlights' => array_values($departureFlights),
        'returnFlights' => []
    ];
    
    // If return date is provided (round trip), search return flights
    if (!empty($returnDate) && ($tripType === 'round_trip' || $tripType === '')) {
        $returnDateStart = $returnDate . ' 00:00:00';
        $returnDateEnd = $returnDate . ' 23:59:59';
        $result['returnFlights'] = fetchFlightsForRoute($pdo, $classType, $toCity['id'], $fromCity['id'], $returnDateStart, $returnDateEnd, $passengers, $filters);
    }
    
    sendJSONResponse($result);
}

/**
 * Normalize trip type for flight search.
 */
function normalizeFlightTripType($value) {
    $v = strtolower(trim((string) $value));
    if (in_array($v, ['round_trip', 'round-trip', 'roundtrip'], true)) {
        return 'round_trip';
    }
    if (in_array($v, ['one_way', 'one-way', 'oneway'], true)) {
        return 'one_way';
    }
    return $v;
}

function fetchFlightsForRoute($pdo, $classType, $fromCityId, $toCityId, $dateStart, $dateEnd, $passengers, $filters = []) {
    $sql = "
        SELECT
            f.id,
            f.flight_number,
            f.departure_time,
            f.arrival_time,
            f.duration_minutes,
            f.stops,
            f.baggage_allowance_kg,
            f.cabin_baggage_kg,
            a.name as airline_name,
            a.code as airline_code,
            dc.name as departure_city,
            dc.code as departure_code,
            ac.name as arrival_city,
            ac.code as arrival_code,
            sc.name as stop_city,
            CASE
                WHEN ? = 'economy' THEN f.economy_price
                WHEN ? = 'premium' THEN f.premium_price
                WHEN ? = 'business' THEN f.business_price
                WHEN ? = 'first' THEN f.first_class_price
                ELSE f.economy_price
            END as price,
            CASE
                WHEN ? = 'economy' THEN f.economy_available
                WHEN ? = 'premium' THEN f.premium_available
                WHEN ? = 'business' THEN f.business_available
                WHEN ? = 'first' THEN f.first_class_available
                ELSE f.economy_available
            END as available_seats
        FROM flights f
        INNER JOIN airlines a ON f.airline_id = a.id
        INNER JOIN cities dc ON f.departure_city_id = dc.id
        INNER JOIN cities ac ON f.arrival_city_id = ac.id
        LEFT JOIN cities sc ON f.stop_city_id = sc.id
        WHERE f.departure_city_id = ?
            AND f.arrival_city_id = ?
            AND f.departure_time >= ?
            AND f.departure_time <= ?
            AND f.status = 'scheduled'
            AND CASE
                WHEN ? = 'economy' THEN f.economy_available
                WHEN ? = 'premium' THEN f.premium_available
                WHEN ? = 'business' THEN f.business_available
                WHEN ? = 'first' THEN f.first_class_available
                ELSE f.economy_available
            END >= ?
    ";

    $params = [
        $classType, $classType, $classType, $classType,
        $classType, $classType, $classType, $classType,
        $fromCityId, $toCityId, $dateStart, $dateEnd,
        $classType, $classType, $classType, $classType,
        $passengers
    ];

    $keyword = trim((string)($filters['keyword'] ?? ''));
    if ($keyword !== '') {
        $sql .= " AND (f.flight_number LIKE ? OR a.name LIKE ? OR dc.name LIKE ? OR ac.name LIKE ? OR dc.code LIKE ? OR ac.code LIKE ?)";
        $keywordLike = '%' . $keyword . '%';
        $params[] = $keywordLike;
        $params[] = $keywordLike;
        $params[] = $keywordLike;
        $params[] = $keywordLike;
        $params[] = $keywordLike;
        $params[] = $keywordLike;
    }

    $minPrice = floatval($filters['minPrice'] ?? 0);
    if ($minPrice > 0) {
        $sql .= " AND CASE
            WHEN ? = 'economy' THEN f.economy_price
            WHEN ? = 'premium' THEN f.premium_price
            WHEN ? = 'business' THEN f.business_price
            WHEN ? = 'first' THEN f.first_class_price
            ELSE f.economy_price
        END >= ?";
        $params[] = $classType;
        $params[] = $classType;
        $params[] = $classType;
        $params[] = $classType;
        $params[] = $minPrice;
    }

    $maxPrice = floatval($filters['maxPrice'] ?? 0);
    if ($maxPrice > 0) {
        $sql .= " AND CASE
            WHEN ? = 'economy' THEN f.economy_price
            WHEN ? = 'premium' THEN f.premium_price
            WHEN ? = 'business' THEN f.business_price
            WHEN ? = 'first' THEN f.first_class_price
            ELSE f.economy_price
        END <= ?";
        $params[] = $classType;
        $params[] = $classType;
        $params[] = $classType;
        $params[] = $classType;
        $params[] = $maxPrice;
    }

    $stops = $filters['stops'] ?? 'any';
    if ($stops === 'direct') {
        $sql .= " AND f.stops = 0";
    } elseif ($stops === '1') {
        $sql .= " AND f.stops = 1";
    } elseif ($stops === '2+') {
        $sql .= " AND f.stops >= 2";
    }

    $airlineCodes = $filters['airlineCodes'] ?? [];
    if (is_array($airlineCodes) && count($airlineCodes) > 0) {
        $placeholders = implode(',', array_fill(0, count($airlineCodes), '?'));
        $sql .= " AND a.code IN ($placeholders)";
        foreach ($airlineCodes as $code) {
            $params[] = strtoupper($code);
        }
    }

    $departStartTime = $filters['departStartTime'] ?? '';
    if (preg_match('/^\d{2}:\d{2}$/', $departStartTime)) {
        $sql .= " AND TIME(f.departure_time) >= ?";
        $params[] = $departStartTime . ':00';
    }

    $departEndTime = $filters['departEndTime'] ?? '';
    if (preg_match('/^\d{2}:\d{2}$/', $departEndTime)) {
        $sql .= " AND TIME(f.departure_time) <= ?";
        $params[] = $departEndTime . ':00';
    }

    $sortMap = [
        'price_asc' => 'price ASC',
        'price_desc' => 'price DESC',
        'duration_asc' => 'f.duration_minutes ASC',
        'duration_desc' => 'f.duration_minutes DESC',
        'departure_time_desc' => 'f.departure_time DESC',
        'departure_time_asc' => 'f.departure_time ASC'
    ];
    $sortBy = $filters['sortBy'] ?? 'departure_time_asc';
    $sql .= " ORDER BY " . ($sortMap[$sortBy] ?? $sortMap['departure_time_asc']) . " LIMIT 200";

    $stmt = $pdo->prepare($sql);
    $stmt->execute($params);
    return $stmt->fetchAll();
}

/**
 * Handle get single flight
 */
function handleGetFlight($pdo) {
    $flightId = $_GET['id'] ?? 0;
    
    if (empty($flightId)) {
        sendJSONResponse(['error' => 'Flight ID is required'], 400);
    }
    
    $stmt = $pdo->prepare("
        SELECT 
            f.*,
            a.name as airline_name,
            a.code as airline_code,
            dc.name as departure_city,
            dc.code as departure_code,
            ac.name as arrival_city,
            ac.code as arrival_code,
            sc.name as stop_city,
            sc.code as stop_code
        FROM flights f
        INNER JOIN airlines a ON f.airline_id = a.id
        INNER JOIN cities dc ON f.departure_city_id = dc.id
        INNER JOIN cities ac ON f.arrival_city_id = ac.id
        LEFT JOIN cities sc ON f.stop_city_id = sc.id
        WHERE f.id = ?
    ");
    
    $stmt->execute([$flightId]);
    $flight = $stmt->fetch();
    
    if (!$flight) {
        sendJSONResponse(['error' => 'Flight not found'], 404);
    }
    
    sendJSONResponse($flight);
}

/**
 * Handle list all flights
 */
function handleListFlights($pdo) {
    $limit = intval($_GET['limit'] ?? 50);
    $offset = intval($_GET['offset'] ?? 0);
    
    $stmt = $pdo->prepare("
        SELECT 
            f.id,
            f.flight_number,
            f.departure_time,
            f.arrival_time,
            f.duration_minutes,
            f.economy_price,
            a.name as airline_name,
            dc.name as departure_city,
            dc.code as departure_code,
            ac.name as arrival_city,
            ac.code as arrival_code
        FROM flights f
        INNER JOIN airlines a ON f.airline_id = a.id
        INNER JOIN cities dc ON f.departure_city_id = dc.id
        INNER JOIN cities ac ON f.arrival_city_id = ac.id
        WHERE f.status = 'scheduled'
        ORDER BY f.departure_time ASC
        LIMIT ? OFFSET ?
    ");
    
    $stmt->execute([$limit, $offset]);
    $flights = $stmt->fetchAll();
    
    sendJSONResponse(['flights' => $flights]);
}

/**
 * Find city by name or code
 * Handles airport codes, city names, and variations
 */
function findCityByNameOrCode($pdo, $search) {
    // Clean search term
    $search = trim($search);
    
    // Extract airport code if in format "City (CODE)"
    $codeMatch = [];
    if (preg_match('/\(([A-Z]{3})\)/', strtoupper($search), $codeMatch)) {
        $code = $codeMatch[1];
        $stmt = $pdo->prepare("
            SELECT id, name, code, country 
            FROM cities 
            WHERE UPPER(code) = ?
            LIMIT 1
        ");
        $stmt->execute([$code]);
        $result = $stmt->fetch();
        if ($result) return $result;
    }
    
    // Remove parentheses and codes if present
    $search = preg_replace('/\s*\([^)]*\)\s*/', '', $search);
    $search = strtolower($search);
    
    // Try multiple search strategies
    $stmt = $pdo->prepare("
        SELECT id, name, code, country 
        FROM cities 
        WHERE 
            LOWER(name) LIKE ? OR 
            UPPER(code) = ? OR
            LOWER(REPLACE(name, ' ', '')) LIKE ? OR
            LOWER(name) LIKE ?
        ORDER BY 
            CASE 
                WHEN UPPER(code) = ? THEN 1
                WHEN LOWER(name) = ? THEN 2
                WHEN LOWER(name) LIKE ? THEN 3
                ELSE 4
            END
        LIMIT 1
    ");
    
    $exactMatch = strtoupper($search);
    $startsWith = $search . '%';
    $contains = '%' . $search . '%';
    $noSpaces = '%' . str_replace(' ', '', $search) . '%';
    
    $stmt->execute([
        $contains,           // LOWER(name) LIKE '%search%'
        $exactMatch,         // UPPER(code) = 'SEARCH'
        $noSpaces,           // LOWER(REPLACE(name, ' ', '')) LIKE '%search%'
        $startsWith,         // LOWER(name) LIKE 'search%'
        $exactMatch,         // Code match priority
        $search,             // Exact name match priority
        $startsWith          // Starts with priority
    ]);
    
    $result = $stmt->fetch();
    
    // Handle common misspellings/variations
    if (!$result) {
        $variations = [
            'mehsana' => 'mahesana',
            'mahesana' => 'mehsana',
            'ahmedabad' => 'ahmedabad',
            'surat' => 'surat',
            'mumbai' => 'bombay',
            'bombay' => 'mumbai',
            'delhi' => 'new delhi',
            'new delhi' => 'delhi',
            'bangalore' => 'bengaluru',
            'bengaluru' => 'bangalore'
        ];
        
        if (isset($variations[$search])) {
            $stmt = $pdo->prepare("
                SELECT id, name, code, country 
                FROM cities 
                WHERE LOWER(name) LIKE ? OR UPPER(code) = ?
                LIMIT 1
            ");
            $variationSearch = '%' . $variations[$search] . '%';
            $stmt->execute([$variationSearch, strtoupper($variations[$search])]);
            $result = $stmt->fetch();
        }
    }
    
    return $result;
}
