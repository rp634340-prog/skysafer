<?php
/**
 * User Activity API
 * Handles user event tracking and history search
 */

require_once __DIR__ . '/../config/config.php';

header('Content-Type: application/json');
requireAuth();
requireRole(['user', 'admin']);
$clientIp = $_SERVER['REMOTE_ADDR'] ?? 'unknown';
enforceRateLimit('activity_' . $clientIp . '_' . (getCurrentUserId() ?? 'guest'), 240, 60);
requireCSRFToken();

$method = $_SERVER['REQUEST_METHOD'];
$action = $_GET['action'] ?? '';

try {
    $pdo = getDBConnection();
    $userId = getCurrentUserId();

    switch ($action) {
        case 'track':
            if ($method !== 'POST') {
                sendJSONResponse(['error' => 'Method not allowed'], 405);
            }
            handleTrack($pdo, $userId);
            break;

        case 'batch':
            if ($method !== 'POST') {
                sendJSONResponse(['error' => 'Method not allowed'], 405);
            }
            handleBatch($pdo, $userId);
            break;

        case 'searchHistory':
            if ($method !== 'GET') {
                sendJSONResponse(['error' => 'Method not allowed'], 405);
            }
            handleSearchHistory($pdo, $userId);
            break;

        default:
            sendJSONResponse(['error' => 'Invalid action'], 400);
    }
} catch (Exception $e) {
    logError("User Activity API Error: " . $e->getMessage());
    sendJSONResponse(['error' => 'Server error'], 500);
}

function handleTrack($pdo, $userId) {
    $data = json_decode(file_get_contents('php://input'), true);
    if (!is_array($data)) {
        sendJSONResponse(['error' => 'Invalid payload'], 400);
    }

    $event = normalizeActivityEvent($data);
    if (empty($event['event_type'])) {
        sendJSONResponse(['error' => 'event_type is required'], 400);
    }

    insertActivityEvent($pdo, $userId, $event);
    sendJSONResponse(['success' => true], 201);
}

function handleBatch($pdo, $userId) {
    $data = json_decode(file_get_contents('php://input'), true);
    if (!is_array($data)) {
        sendJSONResponse(['error' => 'Invalid payload'], 400);
    }
    $events = $data['events'] ?? null;

    if (!is_array($events) || count($events) === 0) {
        sendJSONResponse(['error' => 'events array is required'], 400);
    }

    $events = array_slice($events, 0, 10);

    $pdo->beginTransaction();
    try {
        foreach ($events as $rawEvent) {
            if (!is_array($rawEvent)) {
                continue;
            }
            $event = normalizeActivityEvent($rawEvent);
            if (empty($event['event_type'])) {
                continue;
            }
            insertActivityEvent($pdo, $userId, $event);
        }
        $pdo->commit();
    } catch (Exception $e) {
        $pdo->rollBack();
        throw $e;
    }

    sendJSONResponse(['success' => true, 'processed' => count($events)]);
}

function handleSearchHistory($pdo, $userId) {
    $eventType = sanitizeInput($_GET['eventType'] ?? '');
    $query = sanitizeInput($_GET['query'] ?? '');
    $limit = intval($_GET['limit'] ?? 50);
    $offset = intval($_GET['offset'] ?? 0);

    if ($limit < 1) {
        $limit = 1;
    }
    if ($limit > 100) {
        $limit = 100;
    }
    if ($offset < 0) {
        $offset = 0;
    }

    $sql = "
        SELECT id, event_type, event_name, page_url, element_name, metadata_json, created_at
        FROM user_activity
        WHERE user_id = ?
    ";
    $params = [$userId];

    if (!empty($eventType)) {
        $sql .= " AND event_type = ?";
        $params[] = $eventType;
    }

    if (!empty($query)) {
        $sql .= " AND (event_name LIKE ? OR page_url LIKE ? OR element_name LIKE ? OR metadata_json LIKE ?)";
        $search = '%' . $query . '%';
        $params[] = $search;
        $params[] = $search;
        $params[] = $search;
        $params[] = $search;
    }

    $sql .= " ORDER BY created_at DESC LIMIT ? OFFSET ?";
    $params[] = $limit;
    $params[] = $offset;

    $stmt = $pdo->prepare($sql);
    $stmt->execute($params);
    $history = $stmt->fetchAll();

    sendJSONResponse(['history' => $history]);
}

function normalizeActivityEvent($event) {
    return [
        'event_type' => sanitizeInput($event['event_type'] ?? ''),
        'event_name' => sanitizeInput($event['event_name'] ?? ''),
        'page_url' => sanitizeInput($event['page_url'] ?? ''),
        'element_name' => sanitizeInput($event['element_name'] ?? ''),
        'metadata_json' => json_encode($event['metadata'] ?? new stdClass())
    ];
}

function insertActivityEvent($pdo, $userId, $event) {
    $stmt = $pdo->prepare("
        INSERT INTO user_activity (user_id, event_type, event_name, page_url, element_name, metadata_json)
        VALUES (?, ?, ?, ?, ?, ?)
    ");
    $stmt->execute([
        $userId,
        $event['event_type'],
        $event['event_name'],
        $event['page_url'],
        $event['element_name'],
        $event['metadata_json']
    ]);
}
