<?php
/**
 * Lightweight recommendation service using bookings + activity history.
 */

function getPersonalizedFlightRecommendations($pdo, $userId, $limit = 6) {
    $limit = max(1, min(intval($limit), 12));

    $userRouteScores = [];
    $preferredClass = getPreferredClassType($pdo, $userId);

    // Strong signal: user's booking history.
    $bookingStmt = $pdo->prepare("
        SELECT f.departure_city_id, f.arrival_city_id, COUNT(*) as cnt
        FROM bookings b
        INNER JOIN flights f ON f.id = b.flight_id
        WHERE b.user_id = ?
            AND b.status <> 'cancelled'
            AND b.booking_date >= DATE_SUB(NOW(), INTERVAL 365 DAY)
        GROUP BY f.departure_city_id, f.arrival_city_id
        ORDER BY cnt DESC
        LIMIT 10
    ");
    $bookingStmt->execute([$userId]);
    $bookingRoutes = $bookingStmt->fetchAll();
    foreach ($bookingRoutes as $route) {
        $key = $route['departure_city_id'] . ':' . $route['arrival_city_id'];
        $userRouteScores[$key] = ($userRouteScores[$key] ?? 0) + (intval($route['cnt']) * 6);
    }

    // Medium signal: recent searches from activity tracker.
    $searchStmt = $pdo->prepare("
        SELECT metadata_json
        FROM user_activity
        WHERE user_id = ?
            AND event_type = 'search'
            AND created_at >= DATE_SUB(NOW(), INTERVAL 90 DAY)
        ORDER BY created_at DESC
        LIMIT 100
    ");
    $searchStmt->execute([$userId]);
    $searchEvents = $searchStmt->fetchAll(PDO::FETCH_COLUMN);
    foreach ($searchEvents as $rawJson) {
        $meta = json_decode($rawJson, true);
        if (!is_array($meta)) {
            continue;
        }

        $fromId = resolveCityIdByCodeOrName($pdo, $meta['from'] ?? '');
        $toId = resolveCityIdByCodeOrName($pdo, $meta['to'] ?? '');
        if (!$fromId || !$toId || intval($fromId) === intval($toId)) {
            continue;
        }
        $key = $fromId . ':' . $toId;
        $userRouteScores[$key] = ($userRouteScores[$key] ?? 0) + 2;
    }

    // Fallback to popular routes if user has sparse history.
    if (count($userRouteScores) < 3) {
        $popularStmt = $pdo->query("
            SELECT f.departure_city_id, f.arrival_city_id, COUNT(*) as cnt
            FROM bookings b
            INNER JOIN flights f ON f.id = b.flight_id
            WHERE b.status <> 'cancelled'
                AND b.booking_date >= DATE_SUB(NOW(), INTERVAL 60 DAY)
            GROUP BY f.departure_city_id, f.arrival_city_id
            ORDER BY cnt DESC
            LIMIT 8
        ");
        $popularRoutes = $popularStmt->fetchAll();
        foreach ($popularRoutes as $route) {
            $key = $route['departure_city_id'] . ':' . $route['arrival_city_id'];
            $userRouteScores[$key] = max($userRouteScores[$key] ?? 0, intval($route['cnt']));
        }
    }

    arsort($userRouteScores);
    $topRouteKeys = array_slice(array_keys($userRouteScores), 0, 6);
    if (empty($topRouteKeys)) {
        return [
            'recommendedFlights' => [],
            'preferredClassType' => $preferredClass
        ];
    }

    $routeConditions = [];
    $routeParams = [];
    foreach ($topRouteKeys as $key) {
        [$depId, $arrId] = explode(':', $key);
        $routeConditions[] = "(f.departure_city_id = ? AND f.arrival_city_id = ?)";
        $routeParams[] = intval($depId);
        $routeParams[] = intval($arrId);
    }

    $sql = "
        SELECT
            f.id,
            f.flight_number,
            f.departure_city_id,
            f.arrival_city_id,
            f.departure_time,
            f.arrival_time,
            f.duration_minutes,
            f.stops,
            f.baggage_allowance_kg,
            f.cabin_baggage_kg,
            a.name as airline_name,
            dc.name as departure_city,
            dc.code as departure_code,
            ac.name as arrival_city,
            ac.code as arrival_code,
            sc.name as stop_city,
            CASE
                WHEN ? = 'economy' THEN f.economy_price
                WHEN ? = 'premium' THEN f.premium_price
                WHEN ? = 'business' THEN f.business_price
                WHEN ? = 'first' THEN f.first_class_price
                ELSE f.economy_price
            END as price,
            CASE
                WHEN ? = 'economy' THEN f.economy_available
                WHEN ? = 'premium' THEN f.premium_available
                WHEN ? = 'business' THEN f.business_available
                WHEN ? = 'first' THEN f.first_class_available
                ELSE f.economy_available
            END as available_seats
        FROM flights f
        INNER JOIN airlines a ON f.airline_id = a.id
        INNER JOIN cities dc ON f.departure_city_id = dc.id
        INNER JOIN cities ac ON f.arrival_city_id = ac.id
        LEFT JOIN cities sc ON f.stop_city_id = sc.id
        WHERE f.status = 'scheduled'
            AND f.departure_time >= NOW()
            AND (" . implode(' OR ', $routeConditions) . ")
        ORDER BY f.departure_time ASC
        LIMIT 100
    ";

    $params = [
        $preferredClass, $preferredClass, $preferredClass, $preferredClass,
        $preferredClass, $preferredClass, $preferredClass, $preferredClass
    ];
    $params = array_merge($params, $routeParams);

    $stmt = $pdo->prepare($sql);
    $stmt->execute($params);
    $flights = $stmt->fetchAll();

    $ranked = [];
    foreach ($flights as $flight) {
        if (intval($flight['available_seats']) <= 0) {
            continue;
        }
        $routeKey = intval($flight['departure_city_id']) . ':' . intval($flight['arrival_city_id']);
        $routeScore = intval($userRouteScores[$routeKey] ?? 1);
        $daysToDeparture = max((strtotime($flight['departure_time']) - time()) / 86400, 0);
        $recencyBoost = $daysToDeparture <= 14 ? 3 : 1;
        $pricePenalty = max(floatval($flight['price']) / 1000, 0.5);
        $flight['recommendation_score'] = round(($routeScore * $recencyBoost) / $pricePenalty, 2);
        $flight['recommendation_reason'] = 'Based on your recent searches and booking history';
        $ranked[] = $flight;
    }

    usort($ranked, function($a, $b) {
        return $b['recommendation_score'] <=> $a['recommendation_score'];
    });

    return [
        'recommendedFlights' => array_slice($ranked, 0, $limit),
        'preferredClassType' => $preferredClass
    ];
}

function getPreferredClassType($pdo, $userId) {
    $stmt = $pdo->prepare("
        SELECT class_type, COUNT(*) as cnt
        FROM bookings
        WHERE user_id = ? AND status <> 'cancelled'
        GROUP BY class_type
        ORDER BY cnt DESC
        LIMIT 1
    ");
    $stmt->execute([$userId]);
    $row = $stmt->fetch();
    if (!empty($row['class_type'])) {
        return $row['class_type'];
    }

    $searchStmt = $pdo->prepare("
        SELECT metadata_json
        FROM user_activity
        WHERE user_id = ? AND event_type = 'search'
        ORDER BY created_at DESC
        LIMIT 20
    ");
    $searchStmt->execute([$userId]);
    $events = $searchStmt->fetchAll(PDO::FETCH_COLUMN);
    $classCounts = [];
    foreach ($events as $rawJson) {
        $meta = json_decode($rawJson, true);
        $classType = strtolower(trim($meta['classType'] ?? $meta['class'] ?? ''));
        if (!in_array($classType, ['economy', 'premium', 'business', 'first'], true)) {
            continue;
        }
        $classCounts[$classType] = ($classCounts[$classType] ?? 0) + 1;
    }
    if (!empty($classCounts)) {
        arsort($classCounts);
        return array_key_first($classCounts);
    }

    return 'economy';
}

function resolveCityIdByCodeOrName($pdo, $value) {
    $raw = trim((string)$value);
    if ($raw === '') {
        return null;
    }

    if (preg_match('/\(([A-Z]{3})\)/', strtoupper($raw), $match)) {
        $raw = $match[1];
    }
    $clean = trim(preg_replace('/\s*\([^)]*\)\s*/', '', $raw));

    $stmt = $pdo->prepare("
        SELECT id
        FROM cities
        WHERE UPPER(code) = UPPER(?)
            OR LOWER(name) = LOWER(?)
            OR LOWER(name) LIKE LOWER(?)
        ORDER BY CASE WHEN UPPER(code) = UPPER(?) THEN 1 ELSE 2 END
        LIMIT 1
    ");
    $like = '%' . $clean . '%';
    $stmt->execute([$clean, $clean, $like, $clean]);
    $row = $stmt->fetch();
    return $row ? intval($row['id']) : null;
}
