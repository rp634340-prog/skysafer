<?php
/**
 * Profile API
 * Handles user profile management
 */

require_once __DIR__ . '/../config/config.php';

header('Content-Type: application/json');

// Require authentication
requireAuth();
requireRole(['user', 'admin']);
$clientIp = $_SERVER['REMOTE_ADDR'] ?? 'unknown';
enforceRateLimit('profile_' . $clientIp . '_' . (getCurrentUserId() ?? 'guest'), 120, 60);
requireCSRFToken();

$method = $_SERVER['REQUEST_METHOD'];
$action = $_GET['action'] ?? '';

try {
    $pdo = getDBConnection();
    $userId = getCurrentUserId();
    
    switch ($action) {
        case 'get':
            if ($method !== 'GET') {
                sendJSONResponse(['error' => 'Method not allowed'], 405);
            }
            handleGetProfile($pdo, $userId);
            break;
            
        case 'update':
            if ($method !== 'POST') {
                sendJSONResponse(['error' => 'Method not allowed'], 405);
            }
            handleUpdateProfile($pdo, $userId);
            break;
            
        case 'updatePassword':
            if ($method !== 'POST') {
                sendJSONResponse(['error' => 'Method not allowed'], 405);
            }
            handleUpdatePassword($pdo, $userId);
            break;
            
        case 'getPreferences':
            if ($method !== 'GET') {
                sendJSONResponse(['error' => 'Method not allowed'], 405);
            }
            handleGetPreferences($pdo, $userId);
            break;
            
        case 'updatePreferences':
            if ($method !== 'POST') {
                sendJSONResponse(['error' => 'Method not allowed'], 405);
            }
            handleUpdatePreferences($pdo, $userId);
            break;
            
        default:
            sendJSONResponse(['error' => 'Invalid action'], 400);
    }
} catch (Exception $e) {
    logError("Profile API Error: " . $e->getMessage());
    sendJSONResponse(['error' => 'Server error'], 500);
}

/**
 * Handle get profile
 */
function handleGetProfile($pdo, $userId) {
    $stmt = $pdo->prepare("
        SELECT 
            id, username, email, first_name, last_name, phone, 
            date_of_birth, address, passport_number, passport_expiry,
            emergency_contact_name, emergency_contact_phone, emergency_contact_relation,
            created_at
        FROM users 
        WHERE id = ?
    ");
    
    $stmt->execute([$userId]);
    $user = $stmt->fetch();
    
    if (!$user) {
        sendJSONResponse(['error' => 'User not found'], 404);
    }
    
    // Get booking statistics
    $statsStmt = $pdo->prepare("
        SELECT 
            COUNT(*) as total_bookings,
            SUM(total_price) as total_spent,
            SUM(CASE WHEN status = 'confirmed' THEN 1 ELSE 0 END) as confirmed_bookings
        FROM bookings 
        WHERE user_id = ?
    ");
    $statsStmt->execute([$userId]);
    $stats = $statsStmt->fetch();
    
    $user['stats'] = [
        'totalBookings' => intval($stats['total_bookings'] ?? 0),
        'totalSpent' => floatval($stats['total_spent'] ?? 0),
        'confirmedBookings' => intval($stats['confirmed_bookings'] ?? 0)
    ];
    
    sendJSONResponse($user);
}

/**
 * Handle update profile
 */
function handleUpdateProfile($pdo, $userId) {
    $data = json_decode(file_get_contents('php://input'), true);
    
    $updateFields = [];
    $params = [];
    
    $allowedFields = [
        'first_name' => 'firstName',
        'last_name' => 'lastName',
        'phone' => 'phone',
        'date_of_birth' => 'dateOfBirth',
        'address' => 'address',
        'passport_number' => 'passportNumber',
        'passport_expiry' => 'passportExpiry',
        'emergency_contact_name' => 'emergencyContactName',
        'emergency_contact_phone' => 'emergencyContactPhone',
        'emergency_contact_relation' => 'emergencyContactRelation'
    ];
    
    foreach ($allowedFields as $dbField => $jsonField) {
        if (isset($data[$jsonField])) {
            $updateFields[] = "$dbField = ?";
            $params[] = sanitizeInput($data[$jsonField]);
        }
    }
    
    if (empty($updateFields)) {
        sendJSONResponse(['error' => 'No fields to update'], 400);
    }
    
    $params[] = $userId;
    
    $sql = "UPDATE users SET " . implode(', ', $updateFields) . " WHERE id = ?";
    $stmt = $pdo->prepare($sql);
    
    if ($stmt->execute($params)) {
        sendJSONResponse(['success' => true, 'message' => 'Profile updated successfully']);
    } else {
        sendJSONResponse(['error' => 'Failed to update profile'], 500);
    }
}

/**
 * Handle update password
 */
function handleUpdatePassword($pdo, $userId) {
    $data = json_decode(file_get_contents('php://input'), true);
    
    if (empty($data['currentPassword']) || empty($data['newPassword']) || empty($data['confirmPassword'])) {
        sendJSONResponse(['error' => 'All password fields are required'], 400);
    }
    
    if ($data['newPassword'] !== $data['confirmPassword']) {
        sendJSONResponse(['error' => 'New passwords do not match'], 400);
    }
    
    if (strlen($data['newPassword']) < PASSWORD_MIN_LENGTH) {
        sendJSONResponse(['error' => 'Password must be at least ' . PASSWORD_MIN_LENGTH . ' characters'], 400);
    }
    
    // Get current password hash
    $stmt = $pdo->prepare("SELECT password_hash FROM users WHERE id = ?");
    $stmt->execute([$userId]);
    $user = $stmt->fetch();
    
    if (!$user || !password_verify($data['currentPassword'], $user['password_hash'])) {
        sendJSONResponse(['error' => 'Current password is incorrect'], 401);
    }
    
    // Update password
    $newPasswordHash = password_hash($data['newPassword'], PASSWORD_DEFAULT);
    $stmt = $pdo->prepare("UPDATE users SET password_hash = ? WHERE id = ?");
    
    if ($stmt->execute([$newPasswordHash, $userId])) {
        sendJSONResponse(['success' => true, 'message' => 'Password updated successfully']);
    } else {
        sendJSONResponse(['error' => 'Failed to update password'], 500);
    }
}

/**
 * Handle get preferences
 */
function handleGetPreferences($pdo, $userId) {
    $stmt = $pdo->prepare("SELECT * FROM user_preferences WHERE user_id = ?");
    $stmt->execute([$userId]);
    $preferences = $stmt->fetch();
    
    if (!$preferences) {
        // Create default preferences
        $stmt = $pdo->prepare("INSERT INTO user_preferences (user_id) VALUES (?)");
        $stmt->execute([$userId]);
        
        $stmt = $pdo->prepare("SELECT * FROM user_preferences WHERE user_id = ?");
        $stmt->execute([$userId]);
        $preferences = $stmt->fetch();
    }
    
    sendJSONResponse($preferences);
}

/**
 * Handle update preferences
 */
function handleUpdatePreferences($pdo, $userId) {
    $data = json_decode(file_get_contents('php://input'), true);
    
    $updateFields = [];
    $params = [];
    
    $allowedFields = [
        'seating_preference' => 'seatingPreference',
        'meal_preference' => 'mealPreference',
        'notifications_flight_status' => 'notificationsFlightStatus',
        'notifications_price_drop' => 'notificationsPriceDrop',
        'notifications_promotions' => 'notificationsPromotions',
        'notifications_confirmations' => 'notificationsConfirmations'
    ];
    
    foreach ($allowedFields as $dbField => $jsonField) {
        if (isset($data[$jsonField])) {
            $updateFields[] = "$dbField = ?";
            $params[] = is_bool($data[$jsonField]) ? ($data[$jsonField] ? 1 : 0) : sanitizeInput($data[$jsonField]);
        }
    }
    
    if (empty($updateFields)) {
        sendJSONResponse(['error' => 'No preferences to update'], 400);
    }
    
    // Check if preferences exist
    $checkStmt = $pdo->prepare("SELECT id FROM user_preferences WHERE user_id = ?");
    $checkStmt->execute([$userId]);
    
    if ($checkStmt->fetch()) {
        $params[] = $userId;
        $sql = "UPDATE user_preferences SET " . implode(', ', $updateFields) . " WHERE user_id = ?";
    } else {
        $params[] = $userId;
        $sql = "INSERT INTO user_preferences (" . implode(', ', array_map(function($f) {
            return explode(' = ', $f)[0];
        }, $updateFields)) . ", user_id) VALUES (" . str_repeat('?, ', count($updateFields)) . "?)";
    }
    
    $stmt = $pdo->prepare($sql);
    
    if ($stmt->execute($params)) {
        sendJSONResponse(['success' => true, 'message' => 'Preferences updated successfully']);
    } else {
        sendJSONResponse(['error' => 'Failed to update preferences'], 500);
    }
}
