<?php
/**
 * Bookings API
 * Handles flight bookings, listing, and management
 */

require_once __DIR__ . '/../config/config.php';

header('Content-Type: application/json');

// Require authentication
requireAuth();
requireRole(['user', 'admin']);
$clientIp = $_SERVER['REMOTE_ADDR'] ?? 'unknown';
enforceRateLimit('bookings_' . $clientIp . '_' . (getCurrentUserId() ?? 'guest'), 120, 60);
requireCSRFToken();

$method = $_SERVER['REQUEST_METHOD'];
$action = $_GET['action'] ?? '';

try {
    $pdo = getDBConnection();
    ensureBookingsDateColumns($pdo);
    $userId = getCurrentUserId();
    
    switch ($action) {
        case 'create':
            if ($method !== 'POST') {
                sendJSONResponse(['error' => 'Method not allowed'], 405);
            }
            handleCreateBooking($pdo, $userId);
            break;

        case 'seatLayout':
            if ($method !== 'GET') {
                sendJSONResponse(['error' => 'Method not allowed'], 405);
            }
            handleSeatLayout($pdo, $userId);
            break;

        case 'lockSeat':
            if ($method !== 'POST') {
                sendJSONResponse(['error' => 'Method not allowed'], 405);
            }
            handleLockSeat($pdo, $userId);
            break;

        case 'unlockSeat':
            if ($method !== 'POST') {
                sendJSONResponse(['error' => 'Method not allowed'], 405);
            }
            handleUnlockSeat($pdo, $userId);
            break;
            
        case 'list':
            if ($method !== 'GET') {
                sendJSONResponse(['error' => 'Method not allowed'], 405);
            }
            handleListBookings($pdo, $userId);
            break;
            
        case 'get':
            if ($method !== 'GET') {
                sendJSONResponse(['error' => 'Method not allowed'], 405);
            }
            handleGetBooking($pdo, $userId);
            break;
            
        case 'cancel':
            if ($method !== 'POST') {
                sendJSONResponse(['error' => 'Method not allowed'], 405);
            }
            handleCancelBooking($pdo, $userId);
            break;
            
        case 'pay':
            if ($method !== 'POST') {
                sendJSONResponse(['error' => 'Method not allowed'], 405);
            }
            handlePayment($pdo, $userId);
            break;
            
        default:
            sendJSONResponse(['error' => 'Invalid action'], 400);
    }
} catch (Exception $e) {
    logError("Bookings API Error: " . $e->getMessage());
    sendJSONResponse(['error' => 'Server error'], 500);
}

/**
 * Add trip/date columns to bookings when missing (existing databases).
 */
function ensureBookingsDateColumns($pdo) {
    static $checked = false;
    if ($checked) {
        return;
    }
    $checked = true;

    $existing = [];
    $stmt = $pdo->query('SHOW COLUMNS FROM bookings');
    while ($row = $stmt->fetch(PDO::FETCH_ASSOC)) {
        $existing[$row['Field']] = true;
    }

    $alters = [];
    if (!isset($existing['trip_type'])) {
        $alters[] = "ADD COLUMN trip_type ENUM('one_way', 'round_trip') NOT NULL DEFAULT 'one_way' AFTER class_type";
    }
    if (!isset($existing['departure_date'])) {
        $alters[] = 'ADD COLUMN departure_date DATE NULL AFTER trip_type';
    }
    if (!isset($existing['return_date'])) {
        $alters[] = 'ADD COLUMN return_date DATE NULL AFTER departure_date';
    }
    if (!isset($existing['return_flight_id'])) {
        $alters[] = 'ADD COLUMN return_flight_id INT NULL AFTER return_date';
    }

    if (!empty($alters)) {
        $pdo->exec('ALTER TABLE bookings ' . implode(', ', $alters));
    }
}

/**
 * Normalize trip type from client payload.
 */
function normalizeTripType($value) {
    $v = strtolower(trim((string) $value));
    if (in_array($v, ['round_trip', 'round-trip', 'roundtrip'], true)) {
        return 'round_trip';
    }
    return 'one_way';
}

/**
 * Fetch flight row with class price and availability.
 */
function fetchFlightForBooking($pdo, $flightId, $classType) {
    $stmt = $pdo->prepare("
        SELECT
            f.*,
            CASE
                WHEN ? = 'economy' THEN f.economy_price
                WHEN ? = 'premium' THEN f.premium_price
                WHEN ? = 'business' THEN f.business_price
                WHEN ? = 'first' THEN f.first_class_price
            END as price,
            CASE
                WHEN ? = 'economy' THEN f.economy_available
                WHEN ? = 'premium' THEN f.premium_available
                WHEN ? = 'business' THEN f.business_available
                WHEN ? = 'first' THEN f.first_class_available
            END as available_seats
        FROM flights f
        WHERE f.id = ? AND f.status = 'scheduled'
    ");
    $stmt->execute([
        $classType, $classType, $classType, $classType,
        $classType, $classType, $classType, $classType,
        $flightId,
    ]);
    return $stmt->fetch();
}

/**
 * Handle create booking
 */
function handleCreateBooking($pdo, $userId) {
    $data = json_decode(file_get_contents('php://input'), true);
    if (!is_array($data)) {
        sendJSONResponse(['success' => false, 'message' => 'Invalid request body'], 400);
    }

    $required = ['flightId', 'passengersCount', 'classType'];
    foreach ($required as $field) {
        if (empty($data[$field])) {
            sendJSONResponse(['success' => false, 'message' => ucfirst($field) . ' is required'], 400);
        }
    }

    $flightId = intval($data['flightId']);
    $passengersCount = intval($data['passengersCount']);
    $classType = sanitizeInput($data['classType']);
    $tripType = normalizeTripType($data['tripType'] ?? $data['trip_type'] ?? 'one_way');
    $departureDate = trim((string) ($data['departure_date'] ?? $data['departDate'] ?? ''));
    $returnDate = trim((string) ($data['return_date'] ?? $data['returnDate'] ?? ''));
    $returnFlightId = intval($data['returnFlightId'] ?? $data['return_flight_id'] ?? 0);

    $dateError = validateTravelDates($tripType, $departureDate, $returnDate ?: null);
    if ($dateError !== null) {
        sendJSONResponse(['success' => false, 'message' => $dateError], 400);
    }

    if ($tripType === 'round_trip' && $returnFlightId <= 0) {
        sendJSONResponse(['success' => false, 'message' => 'Return flight is required for a round trip booking'], 400);
    }
    if ($tripType === 'one_way') {
        $returnDate = null;
        $returnFlightId = null;
    }
    $selectedSeats = [];

    if (!empty($data['selectedSeats']) && is_array($data['selectedSeats'])) {
        $selectedSeats = array_values(array_unique(array_map(function($seatNumber) {
            return strtoupper(sanitizeInput($seatNumber));
        }, $data['selectedSeats'])));
    }

    if (!empty($selectedSeats) && count($selectedSeats) !== $passengersCount) {
        sendJSONResponse(['error' => 'Please select seats for all passengers'], 400);
    }
    
    // Validate class type
    $validClasses = ['economy', 'premium', 'business', 'first'];
    if (!in_array($classType, $validClasses)) {
        sendJSONResponse(['error' => 'Invalid class type'], 400);
    }
    
    $flight = fetchFlightForBooking($pdo, $flightId, $classType);

    if (!$flight) {
        sendJSONResponse(['success' => false, 'message' => 'Outbound flight not found or not available'], 404);
    }

    if ($flight['available_seats'] < $passengersCount) {
        sendJSONResponse(['success' => false, 'message' => 'Not enough seats available on outbound flight'], 400);
    }

    $returnFlight = null;
    if ($tripType === 'round_trip') {
        $returnFlight = fetchFlightForBooking($pdo, $returnFlightId, $classType);
        if (!$returnFlight) {
            sendJSONResponse(['success' => false, 'message' => 'Return flight not found or not available'], 404);
        }
        if ($returnFlight['available_seats'] < $passengersCount) {
            sendJSONResponse(['success' => false, 'message' => 'Not enough seats available on return flight'], 400);
        }
    }

    $totalPrice = floatval($flight['price']) * $passengersCount;
    if ($returnFlight) {
        $totalPrice += floatval($returnFlight['price']) * $passengersCount;
    }
    
    // Generate booking reference
    $bookingReference = generateBookingReference();
    
    // Start transaction
    $pdo->beginTransaction();
    
    try {
        // Create booking
        $stmt = $pdo->prepare("
            INSERT INTO bookings
            (user_id, flight_id, booking_reference, passengers_count, class_type, trip_type, departure_date, return_date, return_flight_id, total_price, status)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 'pending')
        ");

        $stmt->execute([
            $userId,
            $flightId,
            $bookingReference,
            $passengersCount,
            $classType,
            $tripType,
            $departureDate,
            $returnDate ?: null,
            $returnFlightId ?: null,
            $totalPrice,
        ]);
        
        $bookingId = $pdo->lastInsertId();

        if (!empty($selectedSeats)) {
            cleanupExpiredSeatLocks($pdo);
            ensureFlightSeatInventory($pdo, $flightId, $classType);
            validateSeatLocksForBooking($pdo, $flightId, $classType, $userId, $selectedSeats);
        }
        
        // Update available seats (outbound + return)
        $seatField = $classType . '_available';
        $seatStmt = $pdo->prepare("
            UPDATE flights
            SET {$seatField} = {$seatField} - ?
            WHERE id = ?
        ");
        $seatStmt->execute([$passengersCount, $flightId]);
        if ($returnFlightId) {
            $seatStmt->execute([$passengersCount, $returnFlightId]);
        }
        
        // Add passengers if provided
        if (!empty($data['passengers']) && is_array($data['passengers'])) {
            $passengerStmt = $pdo->prepare("
                INSERT INTO passengers (booking_id, first_name, last_name, date_of_birth, passport_number, seat_number)
                VALUES (?, ?, ?, ?, ?, ?)
            ");

            $passengerIndex = 0;
            foreach ($data['passengers'] as $passenger) {
                $seatNumber = null;
                if (!empty($selectedSeats)) {
                    $seatNumber = $selectedSeats[$passengerIndex] ?? null;
                }

                $passengerStmt->execute([
                    $bookingId,
                    sanitizeInput($passenger['firstName'] ?? ''),
                    sanitizeInput($passenger['lastName'] ?? ''),
                    $passenger['dateOfBirth'] ?? null,
                    sanitizeInput($passenger['passportNumber'] ?? ''),
                    $seatNumber
                ]);
                $passengerIndex++;
            }
        }

        if (!empty($selectedSeats)) {
            markSeatsAsBooked($pdo, $flightId, $classType, $selectedSeats);
            releaseSeatLocks($pdo, $flightId, $classType, $selectedSeats, $userId);
            broadcastSeatUpdate($flightId, $classType, $selectedSeats, 'booked', $userId);
        }
        
        $pdo->commit();
        
        // Get full booking details
        $booking = getBookingDetails($pdo, $bookingId, $userId);

        $userNotificationId = createNotification(
            $pdo,
            $userId,
            'user',
            'booking_created',
            'Booking Created',
            'Your booking has been created successfully.',
            [
                'bookingId' => $bookingId,
                'bookingReference' => $booking['booking_reference'] ?? '',
                'status' => $booking['status'] ?? 'pending'
            ],
            'normal'
        );
        pushRealtimeNotification([
            'id' => $userNotificationId,
            'type' => 'booking_created',
            'title' => 'Booking Created',
            'message' => 'Your booking has been created successfully.',
            'targetRole' => 'user',
            'recipientUserId' => $userId,
            'payload' => [
                'bookingId' => $bookingId,
                'bookingReference' => $booking['booking_reference'] ?? ''
            ],
            'priority' => 'normal',
            'createdAt' => date('c')
        ]);

        $adminNotificationId = createNotification(
            $pdo,
            null,
            'admin',
            'admin_booking_created',
            'New Booking Alert',
            'A new booking has been placed by a user.',
            [
                'bookingId' => $bookingId,
                'userId' => $userId
            ],
            'high'
        );
        pushRealtimeNotification([
            'id' => $adminNotificationId,
            'type' => 'admin_booking_created',
            'title' => 'New Booking Alert',
            'message' => 'A new booking has been placed by a user.',
            'targetRole' => 'admin',
            'recipientUserId' => null,
            'payload' => [
                'bookingId' => $bookingId,
                'userId' => $userId
            ],
            'priority' => 'high',
            'createdAt' => date('c')
        ]);
        
        sendJSONResponse([
            'success' => true,
            'message' => 'Booking created successfully',
            'booking' => $booking
        ], 201);
        
    } catch (Exception $e) {
        $pdo->rollBack();
        logError("Booking creation failed: " . $e->getMessage());
        sendJSONResponse(['error' => 'Failed to create booking'], 500);
    }
}

/**
 * Handle list bookings
 */
function handleListBookings($pdo, $userId) {
    $status = $_GET['status'] ?? '';
    $limit = intval($_GET['limit'] ?? 50);
    $offset = intval($_GET['offset'] ?? 0);
    
    $sql = "
        SELECT
            b.id,
            b.booking_reference,
            b.passengers_count,
            b.class_type,
            b.trip_type,
            b.departure_date,
            b.return_date,
            b.return_flight_id,
            b.total_price,
            b.booking_date,
            b.status,
            b.payment_status,
            f.flight_number,
            f.departure_time,
            f.arrival_time,
            a.name as airline_name,
            dc.name as departure_city,
            dc.code as departure_code,
            ac.name as arrival_city,
            ac.code as arrival_code,
            rf.flight_number as return_flight_number,
            rf.departure_time as return_departure_time,
            rf.arrival_time as return_arrival_time
        FROM bookings b
        INNER JOIN flights f ON b.flight_id = f.id
        INNER JOIN airlines a ON f.airline_id = a.id
        INNER JOIN cities dc ON f.departure_city_id = dc.id
        INNER JOIN cities ac ON f.arrival_city_id = ac.id
        LEFT JOIN flights rf ON b.return_flight_id = rf.id
        WHERE b.user_id = ?
    ";
    
    $params = [$userId];
    
    if (!empty($status)) {
        $sql .= " AND b.status = ?";
        $params[] = $status;
    }
    
    $sql .= " ORDER BY b.booking_date DESC LIMIT ? OFFSET ?";
    $params[] = $limit;
    $params[] = $offset;
    
    $stmt = $pdo->prepare($sql);
    $stmt->execute($params);
    $bookings = $stmt->fetchAll();
    
    sendJSONResponse(['bookings' => $bookings]);
}

/**
 * Handle get single booking
 */
function handleGetBooking($pdo, $userId) {
    $bookingId = intval($_GET['id'] ?? 0);
    $bookingRef = $_GET['ref'] ?? '';
    
    if (empty($bookingId) && empty($bookingRef)) {
        sendJSONResponse(['error' => 'Booking ID or reference is required'], 400);
    }
    
    $booking = getBookingDetails($pdo, $bookingId, $userId, $bookingRef);
    
    if (!$booking) {
        sendJSONResponse(['error' => 'Booking not found'], 404);
    }
    
    sendJSONResponse($booking);
}

/**
 * Handle cancel booking
 */
function handleCancelBooking($pdo, $userId) {
    $data = json_decode(file_get_contents('php://input'), true);
    $bookingId = intval($data['bookingId'] ?? 0);
    
    if (empty($bookingId)) {
        sendJSONResponse(['error' => 'Booking ID is required'], 400);
    }
    
    // Get booking
    $stmt = $pdo->prepare("
        SELECT b.*
        FROM bookings b
        INNER JOIN flights f ON b.flight_id = f.id
        WHERE b.id = ? AND b.user_id = ?
    ");
    $stmt->execute([$bookingId, $userId]);
    $booking = $stmt->fetch();
    
    if (!$booking) {
        sendJSONResponse(['error' => 'Booking not found'], 404);
    }
    
    if ($booking['status'] === 'cancelled') {
        sendJSONResponse(['error' => 'Booking is already cancelled'], 400);
    }
    
    // Start transaction
    $pdo->beginTransaction();
    
    try {
        // Update booking status
        $stmt = $pdo->prepare("
            UPDATE bookings 
            SET status = 'cancelled' 
            WHERE id = ? AND user_id = ?
        ");
        $stmt->execute([$bookingId, $userId]);
        
        // Restore seats
        $seatField = $booking['class_type'] . '_available';
        $stmt = $pdo->prepare("
            UPDATE flights 
            SET {$seatField} = {$seatField} + ? 
            WHERE id = ?
        ");
        $stmt->execute([$booking['passengers_count'], $booking['flight_id']]);
        if (!empty($booking['return_flight_id'])) {
            $stmt->execute([$booking['passengers_count'], intval($booking['return_flight_id'])]);
        }

        $seatStmt = $pdo->prepare("
            SELECT seat_number
            FROM passengers
            WHERE booking_id = ? AND seat_number IS NOT NULL AND seat_number <> ''
        ");
        $seatStmt->execute([$bookingId]);
        $seatNumbers = array_map('strtoupper', $seatStmt->fetchAll(PDO::FETCH_COLUMN));
        if (!empty($seatNumbers)) {
            setSeatsAsAvailable($pdo, intval($booking['flight_id']), $booking['class_type'], $seatNumbers);
            releaseSeatLocks($pdo, intval($booking['flight_id']), $booking['class_type'], $seatNumbers, $userId);
            broadcastSeatUpdate(intval($booking['flight_id']), $booking['class_type'], $seatNumbers, 'unlocked', $userId);
        }
        
        $pdo->commit();

        $notifId = createNotification(
            $pdo,
            $userId,
            'user',
            'booking_cancelled',
            'Booking Cancelled',
            'Your booking has been cancelled.',
            [
                'bookingId' => $bookingId,
                'flightId' => $booking['flight_id']
            ],
            'normal'
        );
        pushRealtimeNotification([
            'id' => $notifId,
            'type' => 'booking_cancelled',
            'title' => 'Booking Cancelled',
            'message' => 'Your booking has been cancelled.',
            'targetRole' => 'user',
            'recipientUserId' => $userId,
            'payload' => [
                'bookingId' => $bookingId
            ],
            'priority' => 'normal',
            'createdAt' => date('c')
        ]);
        
        sendJSONResponse([
            'success' => true,
            'message' => 'Booking cancelled successfully'
        ]);
        
    } catch (Exception $e) {
        $pdo->rollBack();
        logError("Booking cancellation failed: " . $e->getMessage());
        sendJSONResponse(['error' => 'Failed to cancel booking'], 500);
    }
}

/**
 * Handle payment
 */
function handlePayment($pdo, $userId) {
    $data = json_decode(file_get_contents('php://input'), true);
    $bookingId = intval($data['bookingId'] ?? 0);
    $bookingRef = $data['bookingReference'] ?? '';
    $paymentMethod = sanitizeInput($data['paymentMethod'] ?? 'card');
    
    if (empty($bookingId) && empty($bookingRef)) {
        sendJSONResponse(['error' => 'Booking ID or reference is required'], 400);
    }
    
    // Get booking
    $sql = "SELECT * FROM bookings WHERE user_id = ?";
    $params = [$userId];
    
    if (!empty($bookingId)) {
        $sql .= " AND id = ?";
        $params[] = $bookingId;
    } else {
        $sql .= " AND booking_reference = ?";
        $params[] = $bookingRef;
    }
    
    $stmt = $pdo->prepare($sql);
    $stmt->execute($params);
    $booking = $stmt->fetch();
    
    if (!$booking) {
        sendJSONResponse(['error' => 'Booking not found'], 404);
    }
    
    if ($booking['status'] === 'cancelled') {
        sendJSONResponse(['error' => 'Cannot pay for cancelled booking'], 400);
    }
    
    if ($booking['payment_status'] === 'paid') {
        sendJSONResponse(['error' => 'Booking is already paid'], 400);
    }
    
    // Start transaction
    $pdo->beginTransaction();
    
    try {
        // Generate payment transaction ID (simulated)
        $transactionId = 'TXN' . strtoupper(uniqid());
        
        // Update booking status and payment
        // Store transaction ID in notes field if payment_transaction_id column doesn't exist
        $notes = $booking['notes'] ?? '';
        $notesWithTxn = $notes ? $notes . "\nTransaction ID: " . $transactionId : "Transaction ID: " . $transactionId;
        
        $stmt = $pdo->prepare("
            UPDATE bookings 
            SET status = 'confirmed',
                payment_status = 'paid',
                payment_method = ?,
                notes = ?
            WHERE id = ?
        ");
        $stmt->execute([$paymentMethod, $notesWithTxn, $booking['id']]);
        
        $pdo->commit();
        
        // Get updated booking details
        $updatedBooking = getBookingDetails($pdo, $booking['id'], $userId);

        $notifId = createNotification(
            $pdo,
            $userId,
            'user',
            'payment_confirmed',
            'Payment Confirmed',
            'Payment completed and booking confirmed.',
            [
                'bookingId' => $booking['id'],
                'transactionId' => $transactionId
            ],
            'high'
        );
        pushRealtimeNotification([
            'id' => $notifId,
            'type' => 'payment_confirmed',
            'title' => 'Payment Confirmed',
            'message' => 'Payment completed and booking confirmed.',
            'targetRole' => 'user',
            'recipientUserId' => $userId,
            'payload' => [
                'bookingId' => $booking['id'],
                'transactionId' => $transactionId
            ],
            'priority' => 'high',
            'createdAt' => date('c')
        ]);
        
        sendJSONResponse([
            'success' => true,
            'message' => 'Payment processed successfully',
            'booking' => $updatedBooking,
            'transactionId' => $transactionId
        ]);
        
    } catch (Exception $e) {
        $pdo->rollBack();
        logError("Payment processing failed: " . $e->getMessage());
        sendJSONResponse(['error' => 'Failed to process payment'], 500);
    }
}

/**
 * Get booking details
 */
function getBookingDetails($pdo, $bookingId, $userId, $bookingRef = '') {
    $sql = "
        SELECT 
            b.*,
            f.flight_number,
            f.departure_time,
            f.arrival_time,
            f.duration_minutes,
            f.stops,
            a.name as airline_name,
            a.code as airline_code,
            dc.name as departure_city,
            dc.code as departure_code,
            ac.name as arrival_city,
            ac.code as arrival_code,
            sc.name as stop_city,
            sc.code as stop_code
        FROM bookings b
        INNER JOIN flights f ON b.flight_id = f.id
        INNER JOIN airlines a ON f.airline_id = a.id
        INNER JOIN cities dc ON f.departure_city_id = dc.id
        INNER JOIN cities ac ON f.arrival_city_id = ac.id
        LEFT JOIN cities sc ON f.stop_city_id = sc.id
        WHERE b.user_id = ?
    ";
    
    $params = [$userId];
    
    if (!empty($bookingId)) {
        $sql .= " AND b.id = ?";
        $params[] = $bookingId;
    } elseif (!empty($bookingRef)) {
        $sql .= " AND b.booking_reference = ?";
        $params[] = $bookingRef;
    }
    
    $stmt = $pdo->prepare($sql);
    $stmt->execute($params);
    $booking = $stmt->fetch();
    
    if ($booking) {
        // Get passengers
        $stmt = $pdo->prepare("SELECT * FROM passengers WHERE booking_id = ?");
        $stmt->execute([$booking['id']]);
        $booking['passengers'] = $stmt->fetchAll();
    }
    
    return $booking;
}

function handleSeatLayout($pdo, $userId) {
    $flightId = intval($_GET['flightId'] ?? 0);
    $classType = sanitizeInput($_GET['classType'] ?? '');

    validateSeatRequestInputs($flightId, $classType);
    cleanupExpiredSeatLocks($pdo);
    ensureFlightSeatInventory($pdo, $flightId, $classType);

    $stmt = $pdo->prepare("
        SELECT
            fs.seat_number,
            fs.seat_row,
            fs.seat_column,
            fs.state,
            fs.updated_at,
            sl.user_id as locked_by_user_id,
            sl.expires_at as lock_expires_at
        FROM flight_seats fs
        LEFT JOIN seat_locks sl
            ON sl.flight_id = fs.flight_id
            AND sl.class_type = fs.class_type
            AND sl.seat_number = fs.seat_number
            AND sl.status = 'locked'
            AND sl.expires_at > NOW()
        WHERE fs.flight_id = ? AND fs.class_type = ?
        ORDER BY fs.seat_row ASC, fs.seat_column ASC
    ");
    $stmt->execute([$flightId, $classType]);
    $seats = $stmt->fetchAll();

    $lockedCount = 0;
    $bookedCount = 0;
    foreach ($seats as &$seat) {
        if ($seat['state'] === 'booked') {
            $bookedCount++;
        }
        if (!empty($seat['locked_by_user_id']) && intval($seat['locked_by_user_id']) !== intval($userId)) {
            $seat['state'] = 'locked';
            $lockedCount++;
        } elseif (!empty($seat['locked_by_user_id']) && intval($seat['locked_by_user_id']) === intval($userId)) {
            $seat['state'] = 'locked-by-me';
        }
    }

    sendJSONResponse([
        'flightId' => $flightId,
        'classType' => $classType,
        'seats' => $seats,
        'stats' => [
            'total' => count($seats),
            'available' => max(count($seats) - $bookedCount - $lockedCount, 0),
            'locked' => $lockedCount,
            'booked' => $bookedCount
        ]
    ]);
}

function handleLockSeat($pdo, $userId) {
    $data = json_decode(file_get_contents('php://input'), true);
    $flightId = intval($data['flightId'] ?? 0);
    $classType = sanitizeInput($data['classType'] ?? '');
    $seatNumber = strtoupper(sanitizeInput($data['seatNumber'] ?? ''));

    validateSeatRequestInputs($flightId, $classType, $seatNumber);
    cleanupExpiredSeatLocks($pdo);
    ensureFlightSeatInventory($pdo, $flightId, $classType);

    $pdo->beginTransaction();
    try {
        $seat = getSeatRowForUpdate($pdo, $flightId, $classType, $seatNumber);
        if (!$seat) {
            $pdo->rollBack();
            sendJSONResponse(['error' => 'Seat not found'], 404);
        }
        if ($seat['state'] === 'booked') {
            $pdo->rollBack();
            sendJSONResponse(['error' => 'Seat is already booked'], 409);
        }

        $lockStmt = $pdo->prepare("
            SELECT * FROM seat_locks
            WHERE flight_id = ? AND class_type = ? AND seat_number = ?
            AND status = 'locked' AND expires_at > NOW()
            FOR UPDATE
        ");
        $lockStmt->execute([$flightId, $classType, $seatNumber]);
        $existingLock = $lockStmt->fetch();

        if ($existingLock && intval($existingLock['user_id']) !== intval($userId)) {
            $pdo->rollBack();
            sendJSONResponse(['error' => 'Seat is locked by another user'], 409);
        }

        if ($existingLock) {
            $updateLockStmt = $pdo->prepare("
                UPDATE seat_locks
                SET expires_at = DATE_ADD(NOW(), INTERVAL 5 MINUTE), updated_at = NOW()
                WHERE id = ?
            ");
            $updateLockStmt->execute([$existingLock['id']]);
        } else {
            $insertLockStmt = $pdo->prepare("
                INSERT INTO seat_locks (flight_id, class_type, seat_number, user_id, status, expires_at)
                VALUES (?, ?, ?, ?, 'locked', DATE_ADD(NOW(), INTERVAL 5 MINUTE))
            ");
            $insertLockStmt->execute([$flightId, $classType, $seatNumber, $userId]);
        }

        $pdo->commit();
        broadcastSeatUpdate($flightId, $classType, [$seatNumber], 'locked', $userId);
        sendJSONResponse([
            'success' => true,
            'message' => 'Seat locked',
            'seatNumber' => $seatNumber,
            'lockExpiresAt' => date('c', strtotime('+5 minutes'))
        ]);
    } catch (Exception $e) {
        if ($pdo->inTransaction()) {
            $pdo->rollBack();
        }
        throw $e;
    }
}

function handleUnlockSeat($pdo, $userId) {
    $data = json_decode(file_get_contents('php://input'), true);
    $flightId = intval($data['flightId'] ?? 0);
    $classType = sanitizeInput($data['classType'] ?? '');
    $seatNumber = strtoupper(sanitizeInput($data['seatNumber'] ?? ''));

    validateSeatRequestInputs($flightId, $classType, $seatNumber);
    cleanupExpiredSeatLocks($pdo);

    $stmt = $pdo->prepare("
        DELETE FROM seat_locks
        WHERE flight_id = ? AND class_type = ? AND seat_number = ? AND user_id = ?
    ");
    $stmt->execute([$flightId, $classType, $seatNumber, $userId]);

    broadcastSeatUpdate($flightId, $classType, [$seatNumber], 'unlocked', $userId);
    sendJSONResponse([
        'success' => true,
        'message' => 'Seat unlocked',
        'seatNumber' => $seatNumber
    ]);
}

function validateSeatRequestInputs($flightId, $classType, $seatNumber = '') {
    if (empty($flightId)) {
        sendJSONResponse(['error' => 'Flight ID is required'], 400);
    }
    if (empty($classType)) {
        sendJSONResponse(['error' => 'Class type is required'], 400);
    }
    if (!in_array($classType, ['economy', 'premium', 'business', 'first'], true)) {
        sendJSONResponse(['error' => 'Invalid class type'], 400);
    }
    if ($seatNumber !== '' && !preg_match('/^[0-9]{1,3}[A-F]$/', $seatNumber)) {
        sendJSONResponse(['error' => 'Invalid seat number'], 400);
    }
}

function cleanupExpiredSeatLocks($pdo) {
    $stmt = $pdo->prepare("
        DELETE FROM seat_locks
        WHERE status = 'locked' AND expires_at <= NOW()
    ");
    $stmt->execute();
}

function getClassSeatConfig($classType) {
    $seatCountField = $classType . '_seats';
    return [
        'seatCountField' => $seatCountField,
        'columns' => ['A', 'B', 'C', 'D', 'E', 'F']
    ];
}

function ensureFlightSeatInventory($pdo, $flightId, $classType) {
    $countStmt = $pdo->prepare("
        SELECT COUNT(*) as total FROM flight_seats WHERE flight_id = ? AND class_type = ?
    ");
    $countStmt->execute([$flightId, $classType]);
    $row = $countStmt->fetch();
    if ($row && intval($row['total']) > 0) {
        return;
    }

    $config = getClassSeatConfig($classType);
    $seatField = $config['seatCountField'];
    $flightStmt = $pdo->prepare("SELECT {$seatField} as total_seats FROM flights WHERE id = ?");
    $flightStmt->execute([$flightId]);
    $flight = $flightStmt->fetch();
    if (!$flight) {
        sendJSONResponse(['error' => 'Flight not found'], 404);
    }

    $totalSeats = max(intval($flight['total_seats'] ?? 0), 0);
    if ($totalSeats <= 0) {
        return;
    }

    $insertStmt = $pdo->prepare("
        INSERT INTO flight_seats (flight_id, class_type, seat_number, seat_row, seat_column, state)
        VALUES (?, ?, ?, ?, ?, 'available')
    ");
    $columns = $config['columns'];
    for ($i = 0; $i < $totalSeats; $i++) {
        $rowNum = intdiv($i, count($columns)) + 1;
        $col = $columns[$i % count($columns)];
        $seatNumber = $rowNum . $col;
        $insertStmt->execute([$flightId, $classType, $seatNumber, $rowNum, $col]);
    }

    $bookedStmt = $pdo->prepare("
        SELECT p.seat_number
        FROM passengers p
        INNER JOIN bookings b ON b.id = p.booking_id
        WHERE b.flight_id = ? AND b.class_type = ? AND b.status <> 'cancelled' AND p.seat_number IS NOT NULL AND p.seat_number <> ''
    ");
    $bookedStmt->execute([$flightId, $classType]);
    $bookedSeats = $bookedStmt->fetchAll(PDO::FETCH_COLUMN);

    if (!empty($bookedSeats)) {
        markSeatsAsBooked($pdo, $flightId, $classType, $bookedSeats);
    }
}

function getSeatRowForUpdate($pdo, $flightId, $classType, $seatNumber) {
    $stmt = $pdo->prepare("
        SELECT * FROM flight_seats
        WHERE flight_id = ? AND class_type = ? AND seat_number = ?
        FOR UPDATE
    ");
    $stmt->execute([$flightId, $classType, $seatNumber]);
    return $stmt->fetch();
}

function validateSeatLocksForBooking($pdo, $flightId, $classType, $userId, $seatNumbers) {
    if (empty($seatNumbers)) {
        return;
    }

    $placeholders = implode(',', array_fill(0, count($seatNumbers), '?'));
    $params = array_merge([$flightId, $classType], $seatNumbers, [$userId]);

    $stmt = $pdo->prepare("
        SELECT seat_number
        FROM seat_locks
        WHERE flight_id = ?
            AND class_type = ?
            AND seat_number IN ($placeholders)
            AND user_id = ?
            AND status = 'locked'
            AND expires_at > NOW()
    ");
    $stmt->execute($params);
    $rows = $stmt->fetchAll(PDO::FETCH_COLUMN);
    $ownedLocks = array_flip($rows);
    foreach ($seatNumbers as $seatNumber) {
        if (!isset($ownedLocks[$seatNumber])) {
            sendJSONResponse(['error' => 'Seat lock expired or invalid for seat ' . $seatNumber], 409);
        }
    }
}

function markSeatsAsBooked($pdo, $flightId, $classType, $seatNumbers) {
    if (empty($seatNumbers)) {
        return;
    }
    $placeholders = implode(',', array_fill(0, count($seatNumbers), '?'));
    $params = array_merge([$flightId, $classType], $seatNumbers);
    $stmt = $pdo->prepare("
        UPDATE flight_seats
        SET state = 'booked', updated_at = NOW()
        WHERE flight_id = ? AND class_type = ? AND seat_number IN ($placeholders)
    ");
    $stmt->execute($params);
}

function setSeatsAsAvailable($pdo, $flightId, $classType, $seatNumbers) {
    if (empty($seatNumbers)) {
        return;
    }
    $placeholders = implode(',', array_fill(0, count($seatNumbers), '?'));
    $params = array_merge([$flightId, $classType], $seatNumbers);
    $stmt = $pdo->prepare("
        UPDATE flight_seats
        SET state = 'available', updated_at = NOW()
        WHERE flight_id = ? AND class_type = ? AND seat_number IN ($placeholders)
    ");
    $stmt->execute($params);
}

function releaseSeatLocks($pdo, $flightId, $classType, $seatNumbers, $userId) {
    if (empty($seatNumbers)) {
        return;
    }
    $placeholders = implode(',', array_fill(0, count($seatNumbers), '?'));
    $params = array_merge([$flightId, $classType], $seatNumbers, [$userId]);
    $stmt = $pdo->prepare("
        DELETE FROM seat_locks
        WHERE flight_id = ? AND class_type = ? AND seat_number IN ($placeholders) AND user_id = ?
    ");
    $stmt->execute($params);
}

function broadcastSeatUpdate($flightId, $classType, $seatNumbers, $status, $userId = null) {
    pushRealtimeNotification([
        'type' => 'seat_update',
        'targetRole' => 'user',
        'recipientUserId' => null,
        'payload' => [
            'flightId' => intval($flightId),
            'classType' => $classType,
            'seats' => array_values($seatNumbers),
            'status' => $status,
            'updatedBy' => $userId ? intval($userId) : null
        ],
        'createdAt' => date('c')
    ]);
}
