<?php
/**
 * Authentication API
 * Handles user login, signup, and logout
 */

error_reporting(E_ALL);
ini_set('display_errors', '0');
ini_set('log_errors', '1');

while (ob_get_level() > 0) {
    ob_end_clean();
}
ob_start();

require_once __DIR__ . '/../config/config.php';

error_reporting(E_ALL);
ini_set('display_errors', '0');
ini_set('log_errors', '1');

header('Content-Type: application/json');

/**
 * Unified JSON responses for this endpoint (success + message).
 */
function authRespond($success, $message, $statusCode = 200, array $extra = []) {
    $payload = array_merge(
        [
            'success' => (bool) $success,
            'message' => (string) $message,
        ],
        $extra
    );
    sendJSONResponse($payload, $statusCode);
}

$method = $_SERVER['REQUEST_METHOD'] ?? 'GET';
$action = $_GET['action'] ?? '';
$clientIp = $_SERVER['REMOTE_ADDR'] ?? 'unknown';

enforceRateLimit('auth_' . $clientIp . '_' . $action, 30, 60);

try {
    $pdo = getDBConnection();
    ensureAuthTables($pdo);

    switch ($action) {
        case 'signup':
            if ($method !== 'POST') {
                authRespond(false, 'Method not allowed', 405);
            }
            handleSignup($pdo);
            break;

        case 'login':
            if ($method !== 'POST') {
                authRespond(false, 'Method not allowed', 405);
            }
            handleLogin($pdo);
            break;

        case 'logout':
            if ($method !== 'POST') {
                authRespond(false, 'Method not allowed', 405);
            }
            handleLogout();
            break;

        case 'check':
            handleCheckAuth($pdo);
            break;

        default:
            authRespond(false, 'Invalid action', 400);
    }
} catch (Throwable $e) {
    logError('Auth API Error: ' . $e->getMessage());
    authRespond(false, 'A server error occurred. Please try again later.', 500);
}

/**
 * Ensure core auth tables exist (self-heal on fresh DBs).
 */
function ensureAuthTables($pdo) {
    $pdo->exec("
        CREATE TABLE IF NOT EXISTS users (
            id INT PRIMARY KEY AUTO_INCREMENT,
            username VARCHAR(50) UNIQUE NOT NULL,
            email VARCHAR(100) UNIQUE NOT NULL,
            password_hash VARCHAR(255) NOT NULL,
            first_name VARCHAR(50) NOT NULL,
            last_name VARCHAR(50) NOT NULL,
            phone VARCHAR(20),
            date_of_birth DATE,
            address TEXT,
            passport_number VARCHAR(50),
            passport_expiry DATE,
            emergency_contact_name VARCHAR(100),
            emergency_contact_phone VARCHAR(20),
            emergency_contact_relation VARCHAR(50),
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
            INDEX idx_username (username),
            INDEX idx_email (email)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
    ");

    $pdo->exec("
        CREATE TABLE IF NOT EXISTS user_preferences (
            id INT PRIMARY KEY AUTO_INCREMENT,
            user_id INT NOT NULL UNIQUE,
            seating_preference ENUM('aisle', 'window', 'extra_legroom', 'family') DEFAULT 'aisle',
            meal_preference ENUM('vegetarian', 'non_veg', 'vegan', 'gluten_free') DEFAULT 'vegetarian',
            notifications_flight_status BOOLEAN DEFAULT TRUE,
            notifications_price_drop BOOLEAN DEFAULT TRUE,
            notifications_promotions BOOLEAN DEFAULT FALSE,
            notifications_confirmations BOOLEAN DEFAULT TRUE,
            updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
            CONSTRAINT fk_user_pref_user FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
    ");
}

/**
 * Handle user signup
 */
function handleSignup($pdo) {
    $rawInput = file_get_contents('php://input');
    $data = json_decode($rawInput, true);
    if (!is_array($data)) {
        authRespond(false, 'Invalid request body. Expected JSON.', 400);
    }

    $required = ['firstName', 'lastName', 'email', 'username', 'password', 'confirmPassword'];
    $requiredLabels = [
        'firstName' => 'First name',
        'lastName' => 'Last name',
        'email' => 'Email',
        'username' => 'Username',
        'password' => 'Password',
        'confirmPassword' => 'Confirm password',
    ];
    foreach ($required as $field) {
        if (!isset($data[$field]) || trim((string) $data[$field]) === '') {
            $label = $requiredLabels[$field] ?? ucfirst($field);
            authRespond(false, $label . ' is required.', 400);
        }
    }

    $firstName = trim((string) $data['firstName']);
    $lastName = trim((string) $data['lastName']);
    $email = strtolower(trim((string) $data['email']));
    $username = trim((string) $data['username']);
    $password = (string) $data['password'];
    $confirmPassword = (string) $data['confirmPassword'];

    if (strlen($firstName) > 50 || strlen($lastName) > 50) {
        authRespond(false, 'First name and last name must be at most 50 characters.', 400);
    }
    if (!preg_match("/^[\p{L}\s'\-.]+$/u", $firstName) || !preg_match("/^[\p{L}\s'\-.]+$/u", $lastName)) {
        authRespond(false, 'Names may only contain letters, spaces, hyphens, apostrophes, and periods.', 400);
    }

    if (strlen($username) < 3 || strlen($username) > 50) {
        authRespond(false, 'Username must be between 3 and 50 characters.', 400);
    }
    if (!preg_match('/^[a-zA-Z0-9_]+$/', $username)) {
        authRespond(false, 'Username may only contain letters, numbers, and underscores.', 400);
    }

    if (strlen($email) > 100) {
        authRespond(false, 'Email address is too long.', 400);
    }
    if (!validateEmail($email)) {
        authRespond(false, 'Invalid email address.', 400);
    }

    if (strlen($password) < PASSWORD_MIN_LENGTH) {
        authRespond(false, 'Password must be at least ' . PASSWORD_MIN_LENGTH . ' characters.', 400);
    }
    if (strlen($password) > 72) {
        authRespond(false, 'Password must be at most 72 characters.', 400);
    }
    if (!hash_equals($password, $confirmPassword)) {
        authRespond(false, 'Passwords do not match.', 400);
    }

    $firstNameDb = sanitizeInput($firstName);
    $lastNameDb = sanitizeInput($lastName);
    $usernameDb = sanitizeInput($username);

    try {
        $stmt = $pdo->prepare('SELECT id FROM users WHERE username = ? OR email = ?');
        $stmt->execute([$usernameDb, $email]);
        if ($stmt->fetch()) {
            authRespond(false, 'Username or email already exists.', 409);
        }
    } catch (PDOException $e) {
        logError('Signup lookup failed: ' . $e->getMessage());
        authRespond(false, 'Unable to verify account details. Please try again.', 500);
    }

    $passwordHash = password_hash($password, PASSWORD_DEFAULT);

    try {
        $pdo->beginTransaction();

        $stmt = $pdo->prepare('
            INSERT INTO users (username, email, password_hash, first_name, last_name)
            VALUES (?, ?, ?, ?, ?)
        ');
        $stmt->execute([$usernameDb, $email, $passwordHash, $firstNameDb, $lastNameDb]);

        $userId = (int) $pdo->lastInsertId();

        $prefStmt = $pdo->prepare('INSERT INTO user_preferences (user_id) VALUES (?)');
        $prefStmt->execute([$userId]);

        $pdo->commit();
    } catch (PDOException $e) {
        if ($pdo->inTransaction()) {
            $pdo->rollBack();
        }
        logError('Signup database error: ' . $e->getMessage());
        authRespond(false, 'Unable to create account. Please try again later.', 500);
    }

    session_regenerate_id(true);
    $_SESSION['user_id'] = $userId;
    $_SESSION['username'] = $usernameDb;
    $role = deriveRoleFromIdentity($usernameDb, $email);
    $_SESSION['role'] = $role;
    $_SESSION['email'] = $email;

    authRespond(true, 'Account created successfully', 201, [
        'user' => [
            'id' => $userId,
            'username' => $usernameDb,
            'email' => $email,
            'firstName' => $firstNameDb,
            'lastName' => $lastNameDb,
            'role' => $role,
        ],
        'csrfToken' => generateCSRFToken(),
    ]);
}

/**
 * Handle user login
 */
function handleLogin($pdo) {
    $data = json_decode(file_get_contents('php://input'), true);
    if (!is_array($data)) {
        authRespond(false, 'Invalid request body. Expected JSON.', 400);
    }

    if (!isset($data['username'], $data['password']) || trim((string) $data['username']) === '' || (string) $data['password'] === '') {
        authRespond(false, 'Username and password are required.', 400);
    }

    $username = sanitizeInput(trim((string) $data['username']));
    $password = (string) $data['password'];

    try {
        $stmt = $pdo->prepare('
            SELECT id, username, email, password_hash, first_name, last_name
            FROM users
            WHERE username = ? OR email = ?
        ');
        $stmt->execute([$username, $username]);
        $user = $stmt->fetch();
    } catch (PDOException $e) {
        logError('Login query failed: ' . $e->getMessage());
        authRespond(false, 'Unable to sign in. Please try again later.', 500);
    }

    if (!$user || !password_verify($password, $user['password_hash'])) {
        authRespond(false, 'Invalid username or password.', 401);
    }

    session_regenerate_id(true);
    $_SESSION['user_id'] = $user['id'];
    $_SESSION['username'] = $user['username'];
    $role = deriveRoleFromIdentity($user['username'], $user['email']);
    $_SESSION['role'] = $role;
    $_SESSION['email'] = $user['email'];

    authRespond(true, 'Login successful', 200, [
        'user' => [
            'id' => $user['id'],
            'username' => $user['username'],
            'email' => $user['email'],
            'firstName' => $user['first_name'],
            'lastName' => $user['last_name'],
            'role' => $role,
        ],
        'csrfToken' => generateCSRFToken(),
    ]);
}

/**
 * Handle user logout
 */
function handleLogout() {
    session_regenerate_id(true);
    $_SESSION = [];
    session_destroy();
    authRespond(true, 'Logged out successfully');
}

/**
 * Check authentication status
 */
function handleCheckAuth($pdo) {
    if (isLoggedIn()) {
        $userId = getCurrentUserId();

        try {
            $stmt = $pdo->prepare('
                SELECT id, username, email, first_name, last_name, phone, date_of_birth, address
                FROM users
                WHERE id = ?
            ');
            $stmt->execute([$userId]);
            $user = $stmt->fetch();
        } catch (PDOException $e) {
            logError('Auth check failed: ' . $e->getMessage());
            authRespond(false, 'Unable to verify session. Please try again later.', 500);
        }

        if ($user) {
            sendJSONResponse([
                'success' => true,
                'message' => 'Authenticated',
                'authenticated' => true,
                'user' => [
                    'id' => $user['id'],
                    'username' => $user['username'],
                    'email' => $user['email'],
                    'firstName' => $user['first_name'],
                    'lastName' => $user['last_name'],
                    'role' => getCurrentUserRole(),
                    'phone' => $user['phone'],
                    'dateOfBirth' => $user['date_of_birth'],
                    'address' => $user['address'],
                ],
                'csrfToken' => generateCSRFToken(),
            ]);
        }
    }

    sendJSONResponse([
        'success' => true,
        'message' => 'Not authenticated',
        'authenticated' => false,
    ]);
}
