<?php
/**
 * Admin Dashboard API
 */
require_once __DIR__ . '/../config/config.php';

header('Content-Type: application/json');
requireAuth();
requireRole(['admin']);

$clientIp = $_SERVER['REMOTE_ADDR'] ?? 'unknown';
enforceRateLimit('admin_' . $clientIp . '_' . (getCurrentUserId() ?? 'guest'), 120, 60);
requireCSRFToken();

$method = $_SERVER['REQUEST_METHOD'];
$action = $_GET['action'] ?? 'dashboard';

try {
    $pdo = getDBConnection();

    switch ($action) {
        case 'dashboard':
            if ($method !== 'GET') {
                sendJSONResponse(['error' => 'Method not allowed'], 405);
            }
            handleDashboard($pdo);
            break;
        default:
            sendJSONResponse(['error' => 'Invalid action'], 400);
    }
} catch (Exception $e) {
    logError("Admin API Error: " . $e->getMessage());
    sendJSONResponse(['error' => 'Server error'], 500);
}

function handleDashboard($pdo) {
    $userStats = $pdo->query("
        SELECT
            COUNT(*) AS total_users,
            SUM(CASE WHEN created_at >= DATE_SUB(NOW(), INTERVAL 7 DAY) THEN 1 ELSE 0 END) AS new_users_7d
        FROM users
    ")->fetch();

    $bookingStats = $pdo->query("
        SELECT
            COUNT(*) AS total_bookings,
            SUM(CASE WHEN status = 'confirmed' THEN 1 ELSE 0 END) AS confirmed_bookings,
            SUM(CASE WHEN status = 'cancelled' THEN 1 ELSE 0 END) AS cancelled_bookings,
            COALESCE(SUM(total_price), 0) AS revenue
        FROM bookings
    ")->fetch();

    $activityStats = $pdo->query("
        SELECT
            COUNT(*) AS total_events,
            COUNT(DISTINCT user_id) AS active_users
        FROM user_activity
        WHERE created_at >= DATE_SUB(NOW(), INTERVAL 7 DAY)
    ")->fetch();

    $activityLogsStmt = $pdo->prepare("
        SELECT
            ua.id,
            ua.event_type,
            ua.event_name,
            ua.page_url,
            ua.created_at,
            u.username
        FROM user_activity ua
        INNER JOIN users u ON u.id = ua.user_id
        ORDER BY ua.created_at DESC
        LIMIT 40
    ");
    $activityLogsStmt->execute();
    $activityLogs = $activityLogsStmt->fetchAll();

    $topUsersStmt = $pdo->prepare("
        SELECT
            u.id,
            u.username,
            COUNT(b.id) AS bookings_count,
            COALESCE(SUM(b.total_price), 0) AS total_spent
        FROM users u
        LEFT JOIN bookings b ON b.user_id = u.id
        GROUP BY u.id, u.username
        ORDER BY bookings_count DESC, total_spent DESC
        LIMIT 10
    ");
    $topUsersStmt->execute();
    $topUsers = $topUsersStmt->fetchAll();

    $systemStats = [
        'notificationsTotal' => intval($pdo->query("SELECT COUNT(*) FROM notifications")->fetchColumn()),
        'notificationsUnread' => intval($pdo->query("SELECT COUNT(*) FROM notifications WHERE is_read = 0")->fetchColumn()),
        'flightsTotal' => intval($pdo->query("SELECT COUNT(*) FROM flights")->fetchColumn())
    ];

    sendJSONResponse([
        'userAnalytics' => [
            'totalUsers' => intval($userStats['total_users'] ?? 0),
            'newUsersLast7Days' => intval($userStats['new_users_7d'] ?? 0),
            'topUsers' => $topUsers
        ],
        'activityLogs' => $activityLogs,
        'systemStats' => [
            'totalBookings' => intval($bookingStats['total_bookings'] ?? 0),
            'confirmedBookings' => intval($bookingStats['confirmed_bookings'] ?? 0),
            'cancelledBookings' => intval($bookingStats['cancelled_bookings'] ?? 0),
            'totalRevenue' => floatval($bookingStats['revenue'] ?? 0),
            'weeklyActivityEvents' => intval($activityStats['total_events'] ?? 0),
            'weeklyActiveUsers' => intval($activityStats['active_users'] ?? 0),
            'notificationsTotal' => $systemStats['notificationsTotal'],
            'notificationsUnread' => $systemStats['notificationsUnread'],
            'flightsTotal' => $systemStats['flightsTotal']
        ]
    ]);
}
