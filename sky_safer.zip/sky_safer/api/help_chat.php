<?php
/**
 * AI Help / Support Chat API
 * FAQ matching, chat history, admin FAQ management
 */

error_reporting(E_ALL);
ini_set('display_errors', '0');
ini_set('log_errors', '1');

while (ob_get_level() > 0) {
    ob_end_clean();
}
ob_start();

require_once __DIR__ . '/../config/config.php';

error_reporting(E_ALL);
ini_set('display_errors', '0');
ini_set('log_errors', '1');

header('Content-Type: application/json');

$method = $_SERVER['REQUEST_METHOD'] ?? 'GET';
$action = $_GET['action'] ?? 'chat';
$clientIp = $_SERVER['REMOTE_ADDR'] ?? 'unknown';

enforceRateLimit('help_chat_' . $clientIp . '_' . $action, 60, 60);

/**
 * JSON response helper for this API.
 */
function helpRespond($success, $data = [], $statusCode = 200) {
    $payload = array_merge(['success' => (bool) $success], $data);
    sendJSONResponse($payload, $statusCode);
}

try {
    $pdo = getDBConnection();
    ensureHelpChatTables($pdo);

    switch ($action) {
        case 'chat':
            if ($method !== 'POST') {
                helpRespond(false, ['message' => 'Method not allowed'], 405);
            }
            handleHelpChat($pdo);
            break;

        case 'welcome':
            helpRespond(true, [
                'message' => getWelcomeMessage(),
            ]);
            break;

        case 'history':
            if ($method !== 'GET') {
                helpRespond(false, ['message' => 'Method not allowed'], 405);
            }
            handleChatHistory($pdo);
            break;

        case 'list':
            requireHelpAdmin();
            if ($method !== 'GET') {
                helpRespond(false, ['message' => 'Method not allowed'], 405);
            }
            handleListFaqs($pdo);
            break;

        case 'create':
            requireHelpAdmin();
            requireCSRFToken();
            if ($method !== 'POST') {
                helpRespond(false, ['message' => 'Method not allowed'], 405);
            }
            handleCreateFaq($pdo);
            break;

        case 'update':
            requireHelpAdmin();
            requireCSRFToken();
            if ($method !== 'POST') {
                helpRespond(false, ['message' => 'Method not allowed'], 405);
            }
            handleUpdateFaq($pdo);
            break;

        case 'delete':
            requireHelpAdmin();
            requireCSRFToken();
            if ($method !== 'POST') {
                helpRespond(false, ['message' => 'Method not allowed'], 405);
            }
            handleDeleteFaq($pdo);
            break;

        default:
            helpRespond(false, ['message' => 'Invalid action'], 400);
    }
} catch (Throwable $e) {
    logError('Help chat API error: ' . $e->getMessage());
    helpRespond(false, [
        'message' => 'A server error occurred. Please try again.',
        'answer' => 'Sorry, something went wrong. Please try again in a moment.',
    ], 500);
}

function requireHelpAdmin() {
    requireAuth();
    requireRole(['admin']);
}

function getWelcomeMessage() {
    return 'Hello! I am the SkySafer Help Assistant. Ask me about bookings, payments, cancellations, refunds, or your account — I am here to help.';
}

function ensureHelpChatTables($pdo) {
    static $ready = false;
    if ($ready) {
        return;
    }
    $ready = true;

    $pdo->exec("
        CREATE TABLE IF NOT EXISTS help_questions (
            id INT PRIMARY KEY AUTO_INCREMENT,
            question VARCHAR(500) NOT NULL,
            answer TEXT NOT NULL,
            keywords VARCHAR(500) DEFAULT NULL,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
            INDEX idx_question (question(191))
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4
    ");

    $pdo->exec("
        CREATE TABLE IF NOT EXISTS help_chat_history (
            id INT PRIMARY KEY AUTO_INCREMENT,
            session_id VARCHAR(64) NOT NULL,
            user_id INT NULL,
            user_message TEXT NOT NULL,
            bot_answer TEXT NOT NULL,
            matched_question_id INT NULL,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            INDEX idx_session (session_id),
            INDEX idx_created (created_at)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4
    ");

    $count = (int) $pdo->query('SELECT COUNT(*) FROM help_questions')->fetchColumn();
    if ($count === 0) {
        seedDefaultHelpFaqs($pdo);
    }
}

function seedDefaultHelpFaqs($pdo) {
    $rows = [
        ['How to book a ticket?', 'To book a ticket on SkySafer: search flights on the home page, select a flight, log in, enter passenger details, choose seats, and confirm payment.', 'book,booking,ticket,reserve'],
        ['How to cancel a ticket?', 'Open My Bookings, select your trip, and click Cancel. Refunds depend on your fare rules.', 'cancel,cancellation'],
        ['How to login?', 'Click Login and enter your username or email and password.', 'login,sign in'],
        ['Payment failed solution', 'Check card details, retry from My Bookings with Complete Payment, or contact your bank if charged without confirmation.', 'payment failed,card,declined'],
        ['Refund policy', 'Eligible cancellations are refunded in 5–10 business days for refundable fares.', 'refund,policy,money back'],
    ];
    $stmt = $pdo->prepare('INSERT INTO help_questions (question, answer, keywords) VALUES (?, ?, ?)');
    foreach ($rows as $row) {
        $stmt->execute($row);
    }
}

function handleHelpChat($pdo) {
    $data = json_decode(file_get_contents('php://input'), true);
    if (!is_array($data)) {
        helpRespond(false, ['message' => 'Invalid JSON body', 'answer' => 'Sorry, I could not understand your question.'], 400);
    }

    $message = trim((string) ($data['message'] ?? ''));
    $sessionId = trim((string) ($data['sessionId'] ?? ''));

    if ($message === '') {
        helpRespond(false, ['message' => 'Message is required', 'answer' => 'Please type a question.'], 400);
    }

    if (strlen($message) > 2000) {
        helpRespond(false, ['message' => 'Message too long', 'answer' => 'Please shorten your question.'], 400);
    }

    if ($sessionId === '' || !preg_match('/^[a-zA-Z0-9_-]{8,64}$/', $sessionId)) {
        $sessionId = bin2hex(random_bytes(16));
    }

    $match = findBestHelpAnswer($pdo, $message);
    $answer = $match['answer'];
    $matchedId = $match['id'];
    $confidence = $match['score'];

    $userId = isLoggedIn() ? getCurrentUserId() : null;

    try {
        $stmt = $pdo->prepare('
            INSERT INTO help_chat_history (session_id, user_id, user_message, bot_answer, matched_question_id)
            VALUES (?, ?, ?, ?, ?)
        ');
        $stmt->execute([
            $sessionId,
            $userId,
            $message,
            $answer,
            $matchedId,
        ]);
    } catch (PDOException $e) {
        logError('Help chat history save failed: ' . $e->getMessage());
    }

    helpRespond(true, [
        'answer' => $answer,
        'sessionId' => $sessionId,
        'matched' => $matchedId !== null,
        'confidence' => $confidence,
        'questionId' => $matchedId,
        'timestamp' => date('c'),
    ]);
}

function handleChatHistory($pdo) {
    $sessionId = trim((string) ($_GET['sessionId'] ?? ''));
    if ($sessionId === '' || !preg_match('/^[a-zA-Z0-9_-]{8,64}$/', $sessionId)) {
        helpRespond(false, ['message' => 'Valid sessionId is required'], 400);
    }

    $limit = max(1, min((int) ($_GET['limit'] ?? 50), 100));

    $stmt = $pdo->prepare('
        SELECT id, user_message, bot_answer, matched_question_id, created_at
        FROM help_chat_history
        WHERE session_id = ?
        ORDER BY created_at ASC
        LIMIT ?
    ');
    $stmt->bindValue(1, $sessionId, PDO::PARAM_STR);
    $stmt->bindValue(2, $limit, PDO::PARAM_INT);
    $stmt->execute();
    $rows = $stmt->fetchAll();

    helpRespond(true, ['history' => $rows]);
}

/**
 * Find best FAQ match using LIKE and keyword scoring.
 */
function findBestHelpAnswer($pdo, $userMessage) {
    $fallback = 'Sorry, I could not understand your question. Try asking about booking, cancellation, login, payment, or refunds.';

    $normalized = strtolower(trim($userMessage));
    $normalized = preg_replace('/\s+/', ' ', $normalized);
    if ($normalized === '') {
        return ['id' => null, 'answer' => $fallback, 'score' => 0];
    }

    $like = '%' . $normalized . '%';
    $stmt = $pdo->prepare('
        SELECT id, question, answer, keywords
        FROM help_questions
        WHERE LOWER(question) LIKE ?
           OR LOWER(answer) LIKE ?
           OR LOWER(keywords) LIKE ?
        LIMIT 80
    ');
    $stmt->execute([$like, $like, $like]);

    $candidates = $stmt->fetchAll();
    if (empty($candidates)) {
        $candidates = $pdo->query('SELECT id, question, answer, keywords FROM help_questions LIMIT 100')->fetchAll();
    }

    $words = array_values(array_filter(preg_split('/[^a-z0-9]+/i', $normalized), function ($w) {
        return strlen($w) >= 2;
    }));

    $best = null;
    $bestScore = 0;

    foreach ($candidates as $row) {
        $score = scoreHelpRow($row, $normalized, $words);
        if ($score > $bestScore) {
            $bestScore = $score;
            $best = $row;
        }
    }

    if ($best === null || $bestScore < 8) {
        return ['id' => null, 'answer' => $fallback, 'score' => $bestScore];
    }

    return [
        'id' => (int) $best['id'],
        'answer' => $best['answer'],
        'score' => $bestScore,
    ];
}

function scoreHelpRow(array $row, $normalizedQuery, array $words) {
    $q = strtolower($row['question']);
    $a = strtolower($row['answer']);
    $k = strtolower((string) ($row['keywords'] ?? ''));

    $score = 0;

    if ($q === $normalizedQuery) {
        $score += 120;
    }
    if (strpos($q, $normalizedQuery) !== false) {
        $score += 55;
    }
    if (strpos($normalizedQuery, $q) !== false && strlen($q) > 10) {
        $score += 40;
    }
    if (strpos($a, $normalizedQuery) !== false) {
        $score += 20;
    }
    if (strpos($k, $normalizedQuery) !== false) {
        $score += 35;
    }

    foreach ($words as $word) {
        if (strlen($word) < 3) {
            continue;
        }
        $likeWord = '%' . $word . '%';
        if (strpos($q, $word) !== false) {
            $score += 15;
        }
        if (strpos($k, $word) !== false) {
            $score += 18;
        }
        if (strpos($a, $word) !== false) {
            $score += 5;
        }
    }

    similar_text($normalizedQuery, $q, $pct);
    $score += (int) round($pct / 4);

    return $score;
}

function handleListFaqs($pdo) {
    $stmt = $pdo->query('
        SELECT id, question, answer, keywords, created_at, updated_at
        FROM help_questions
        ORDER BY id DESC
    ');
    helpRespond(true, ['faqs' => $stmt->fetchAll()]);
}

function handleCreateFaq($pdo) {
    $data = json_decode(file_get_contents('php://input'), true);
    if (!is_array($data)) {
        helpRespond(false, ['message' => 'Invalid JSON'], 400);
    }

    $question = trim((string) ($data['question'] ?? ''));
    $answer = trim((string) ($data['answer'] ?? ''));
    $keywords = trim((string) ($data['keywords'] ?? ''));

    if ($question === '' || $answer === '') {
        helpRespond(false, ['message' => 'Question and answer are required'], 400);
    }

    $stmt = $pdo->prepare('INSERT INTO help_questions (question, answer, keywords) VALUES (?, ?, ?)');
    $stmt->execute([
        sanitizeInput($question),
        sanitizeInput($answer),
        $keywords !== '' ? sanitizeInput($keywords) : null,
    ]);

    helpRespond(true, [
        'message' => 'FAQ created',
        'id' => (int) $pdo->lastInsertId(),
    ], 201);
}

function handleUpdateFaq($pdo) {
    $data = json_decode(file_get_contents('php://input'), true);
    if (!is_array($data)) {
        helpRespond(false, ['message' => 'Invalid JSON'], 400);
    }

    $id = (int) ($data['id'] ?? 0);
    $question = trim((string) ($data['question'] ?? ''));
    $answer = trim((string) ($data['answer'] ?? ''));
    $keywords = trim((string) ($data['keywords'] ?? ''));

    if ($id <= 0 || $question === '' || $answer === '') {
        helpRespond(false, ['message' => 'Valid id, question, and answer are required'], 400);
    }

    $stmt = $pdo->prepare('
        UPDATE help_questions
        SET question = ?, answer = ?, keywords = ?
        WHERE id = ?
    ');
    $stmt->execute([
        sanitizeInput($question),
        sanitizeInput($answer),
        $keywords !== '' ? sanitizeInput($keywords) : null,
        $id,
    ]);

    if ($stmt->rowCount() === 0) {
        helpRespond(false, ['message' => 'FAQ not found'], 404);
    }

    helpRespond(true, ['message' => 'FAQ updated']);
}

function handleDeleteFaq($pdo) {
    $data = json_decode(file_get_contents('php://input'), true);
    $id = (int) ($data['id'] ?? $_GET['id'] ?? 0);

    if ($id <= 0) {
        helpRespond(false, ['message' => 'Valid id is required'], 400);
    }

    $stmt = $pdo->prepare('DELETE FROM help_questions WHERE id = ?');
    $stmt->execute([$id]);

    if ($stmt->rowCount() === 0) {
        helpRespond(false, ['message' => 'FAQ not found'], 404);
    }

    helpRespond(true, ['message' => 'FAQ deleted']);
}
