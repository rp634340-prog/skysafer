<?php
/**
 * Notifications API
 * list, create, markRead, markAllRead
 */
require_once __DIR__ . '/../config/config.php';

header('Content-Type: application/json');
requireAuth();
requireRole(['user', 'admin']);

$clientIp = $_SERVER['REMOTE_ADDR'] ?? 'unknown';
enforceRateLimit('notifications_' . $clientIp . '_' . (getCurrentUserId() ?? 'guest'), 180, 60);
requireCSRFToken();

$method = $_SERVER['REQUEST_METHOD'];
$action = $_GET['action'] ?? 'list';

try {
    $pdo = getDBConnection();
    $userId = getCurrentUserId();
    $role = getCurrentUserRole();

    switch ($action) {
        case 'list':
            if ($method !== 'GET') {
                sendJSONResponse(['error' => 'Method not allowed'], 405);
            }
            handleList($pdo, $userId, $role);
            break;

        case 'create':
            if ($method !== 'POST') {
                sendJSONResponse(['error' => 'Method not allowed'], 405);
            }
            requireRole(['admin']);
            handleCreate($pdo, $userId);
            break;

        case 'markRead':
            if ($method !== 'POST') {
                sendJSONResponse(['error' => 'Method not allowed'], 405);
            }
            handleMarkRead($pdo, $userId);
            break;

        case 'markAllRead':
            if ($method !== 'POST') {
                sendJSONResponse(['error' => 'Method not allowed'], 405);
            }
            handleMarkAllRead($pdo, $userId, $role);
            break;

        default:
            sendJSONResponse(['error' => 'Invalid action'], 400);
    }
} catch (Exception $e) {
    logError("Notifications API Error: " . $e->getMessage());
    sendJSONResponse(['error' => 'Server error'], 500);
}

function handleList($pdo, $userId, $role) {
    $limit = intval($_GET['limit'] ?? 30);
    $offset = intval($_GET['offset'] ?? 0);
    $onlyUnread = intval($_GET['unreadOnly'] ?? 0) === 1;

    if ($limit < 1) $limit = 1;
    if ($limit > 100) $limit = 100;
    if ($offset < 0) $offset = 0;

    $sql = "
        SELECT id, recipient_user_id, target_role, notification_type, title, message, payload_json, is_read, priority, created_at
        FROM notifications
        WHERE (recipient_user_id = ? OR target_role = ?)
    ";
    $params = [$userId, $role];

    if ($onlyUnread) {
        $sql .= " AND is_read = 0";
    }

    $sql .= " ORDER BY created_at DESC LIMIT ? OFFSET ?";
    $params[] = $limit;
    $params[] = $offset;

    $stmt = $pdo->prepare($sql);
    $stmt->execute($params);
    $notifications = $stmt->fetchAll();

    $countStmt = $pdo->prepare("
        SELECT COUNT(*) AS unread_count
        FROM notifications
        WHERE (recipient_user_id = ? OR target_role = ?) AND is_read = 0
    ");
    $countStmt->execute([$userId, $role]);
    $unread = intval($countStmt->fetch()['unread_count'] ?? 0);

    sendJSONResponse(['notifications' => $notifications, 'unreadCount' => $unread]);
}

function handleCreate($pdo, $actorUserId) {
    $data = json_decode(file_get_contents('php://input'), true);
    if (!is_array($data)) {
        sendJSONResponse(['error' => 'Invalid payload'], 400);
    }

    $targetRole = sanitizeInput($data['targetRole'] ?? 'user');
    $recipientUserId = intval($data['recipientUserId'] ?? 0);
    $title = sanitizeInput($data['title'] ?? '');
    $message = sanitizeInput($data['message'] ?? '');
    $type = sanitizeInput($data['type'] ?? 'system');
    $priority = sanitizeInput($data['priority'] ?? 'normal');
    $payload = is_array($data['payload'] ?? null) ? $data['payload'] : [];

    if ($title === '' || $message === '') {
        sendJSONResponse(['error' => 'title and message are required'], 400);
    }
    if (!in_array($targetRole, ['user', 'admin'], true)) {
        sendJSONResponse(['error' => 'Invalid targetRole'], 400);
    }

    $notificationId = createNotification(
        $pdo,
        $recipientUserId > 0 ? $recipientUserId : null,
        $targetRole,
        $type,
        $title,
        $message,
        $payload,
        $priority
    );

    $eventPayload = [
        'id' => $notificationId,
        'type' => $type,
        'title' => $title,
        'message' => $message,
        'targetRole' => $targetRole,
        'recipientUserId' => $recipientUserId > 0 ? $recipientUserId : null,
        'payload' => $payload,
        'priority' => $priority,
        'createdAt' => date('c'),
        'emittedBy' => intval($actorUserId)
    ];
    pushRealtimeNotification($eventPayload);

    sendJSONResponse(['success' => true, 'notificationId' => $notificationId], 201);
}

function handleMarkRead($pdo, $userId) {
    $data = json_decode(file_get_contents('php://input'), true);
    $notificationId = intval($data['notificationId'] ?? 0);
    if ($notificationId <= 0) {
        sendJSONResponse(['error' => 'notificationId is required'], 400);
    }

    $stmt = $pdo->prepare("
        UPDATE notifications
        SET is_read = 1, read_at = CURRENT_TIMESTAMP
        WHERE id = ? AND recipient_user_id = ?
    ");
    $stmt->execute([$notificationId, $userId]);

    sendJSONResponse(['success' => true]);
}

function handleMarkAllRead($pdo, $userId, $role) {
    $stmt = $pdo->prepare("
        UPDATE notifications
        SET is_read = 1, read_at = CURRENT_TIMESTAMP
        WHERE (recipient_user_id = ? OR target_role = ?) AND is_read = 0
    ");
    $stmt->execute([$userId, $role]);
    sendJSONResponse(['success' => true]);
}
