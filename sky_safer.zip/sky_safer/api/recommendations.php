<?php
/**
 * Recommendations API
 * Lightweight personalized recommendations from user behavior.
 */

require_once __DIR__ . '/../config/config.php';
require_once __DIR__ . '/services/recommendation-service.php';

header('Content-Type: application/json');
requireAuth();
requireRole(['user', 'admin']);
requireCSRFToken();

$method = $_SERVER['REQUEST_METHOD'];
$action = $_GET['action'] ?? 'flights';

try {
    $pdo = getDBConnection();
    $userId = getCurrentUserId();

    switch ($action) {
        case 'flights':
            if ($method !== 'GET') {
                sendJSONResponse(['error' => 'Method not allowed'], 405);
            }
            $limit = intval($_GET['limit'] ?? 6);
            $result = getPersonalizedFlightRecommendations($pdo, $userId, $limit);
            sendJSONResponse([
                'success' => true,
                'preferredClassType' => $result['preferredClassType'],
                'recommendedFlights' => $result['recommendedFlights']
            ]);
            break;

        default:
            sendJSONResponse(['error' => 'Invalid action'], 400);
    }
} catch (Exception $e) {
    logError("Recommendations API Error: " . $e->getMessage());
    sendJSONResponse(['error' => 'Server error'], 500);
}
